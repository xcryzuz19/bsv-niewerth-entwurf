<?php
/**
 * BSV Niewerth – Theme-Funktionen
 * Seitentitel, Beschreibungen und strukturierte Daten kommen aus inc/routes.json.
 */
defined('ABSPATH') || exit;
define('BSV_VERSION', '1.0.2611191114');

function bsv_data() {
	static $d = null;
	if ($d === null) $d = json_decode(file_get_contents(__DIR__ . '/inc/routes.json'), true);
	return $d;
}
/* SEO-Daten aus dem Seiteninhalt (Kommentar <!-- bsv:seo … -->); so brauchen neue Seiten kein Theme-Update */
function bsv_marker() {
	static $m = false;
	if ($m !== false) return $m;
	$m = null;
	if (is_singular()) {
		$c = get_post_field('post_content', get_queried_object_id());
		if ($c && preg_match('/<!-- bsv:seo ([A-Za-z0-9+\/=]+) -->/', $c, $x)) {
			$d = json_decode(base64_decode($x[1]), true);
			if (is_array($d) && !empty($d['key'])) $m = $d;
		}
	}
	return $m;
}
function bsv_route_key() {
	static $k = false;
	if ($k !== false) return $k;
	$k = null;
	if (bsv_marker()) return $k = bsv_marker()['key'];
	if (is_front_page()) {
		$k = 'start';
	} elseif (is_page()) {
		$p = get_queried_object();
		$parent = $p->post_parent ? get_post_field('post_name', $p->post_parent) : '';
		$cand = $parent === 'ratgeber' ? 'ratgeber-' . $p->post_name : $p->post_name;
		if (isset(bsv_data()['routes'][$cand])) $k = $cand;
	}
	return $k;
}
function bsv_route() {
	if (bsv_marker()) return bsv_marker();
	$k = bsv_route_key();
	return ($k && isset(bsv_data()['routes'][$k])) ? bsv_data()['routes'][$k] : null;
}

add_action('after_setup_theme', function () {
	add_theme_support('title-tag');
	add_theme_support('post-thumbnails');
	add_theme_support('responsive-embeds');
	add_theme_support('html5', ['search-form', 'gallery', 'caption', 'style', 'script']);
});

/* Aufräumen im Kopfbereich */
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'wp_shortlink_wp_head');
remove_action('wp_head', 'feed_links_extra', 3);
add_filter('comments_open', '__return_false');
add_filter('pings_open', '__return_false');

/* Seitentitel */
add_filter('pre_get_document_title', function ($t) {
	$r = bsv_route();
	return $r ? $r['title'] : $t;
});

/* Beschreibung, Social-Media-Vorschau, strukturierte Daten */
add_action('wp_head', function () {
	$r = bsv_route();
	$desc = $r ? $r['desc'] : (is_singular() ? wp_strip_all_tags(get_the_excerpt()) : get_bloginfo('description'));
	$title = $r ? $r['title'] : wp_get_document_title();
	$url = is_front_page() ? home_url('/') : (is_singular() ? get_permalink() : '');
	$img = bsv_og_image();
	if ($desc) echo '<meta name="description" content="' . esc_attr($desc) . "\">\n";
	echo '<meta property="og:type" content="website">' . "\n";
	echo '<meta property="og:locale" content="de_DE">' . "\n";
	echo '<meta property="og:site_name" content="BSV Niewerth">' . "\n";
	echo '<meta property="og:title" content="' . esc_attr($title) . "\">\n";
	if ($desc) echo '<meta property="og:description" content="' . esc_attr($desc) . "\">\n";
	if ($url) echo '<meta property="og:url" content="' . esc_url($url) . "\">\n";
	echo '<meta property="og:image" content="' . esc_url($img) . '"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630"><meta property="og:image:alt" content="' . esc_attr($title) . '">' . "\n";
	echo '<meta property="og:image:secure_url" content="' . esc_url($img) . '"><meta property="og:image:type" content="image/jpeg"><meta name="twitter:image" content="' . esc_url($img) . '"><meta name="twitter:title" content="' . esc_attr($title) . '">' . "\n";
	echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
	echo '<script type="application/ld+json">' . bsv_data()['ld'] . "</script>\n";
	if ($r && $r['ld'] && $r['ld'] !== '{}') echo '<script type="application/ld+json">' . $r['ld'] . "</script>\n";
	if (bsv_route_key() === 'start' && !empty(bsv_data()['hero'])) echo '<link rel="preload" as="image" href="' . esc_url(bsv_data()['hero']) . '" fetchpriority="high">' . "\n";
}, 1);

/* Gestaltung und Skript */
add_action('wp_enqueue_scripts', function () {
	$u = get_template_directory_uri() . '/assets/';
	wp_enqueue_style('bsv', $u . 'site.css', [], BSV_VERSION);
	wp_enqueue_script('bsv', $u . 'site.js', [], BSV_VERSION, true);
	$r = bsv_route();
	wp_add_inline_script('bsv', 'window.BSV=' . wp_json_encode([
		'route' => bsv_route_key() ?: 'seite',
		'nav' => $r ? $r['nav'] : '',
		'urls' => array_map('home_url', bsv_data()['urls']),
		'rest' => rest_url('bsv/v1/anfrage'),
	]) . ';', 'before');
	if ($r) {
		foreach (['wp-block-library', 'wp-block-library-theme', 'global-styles', 'classic-theme-styles'] as $h) wp_dequeue_style($h);
	}
}, 20);

/* Seiteninhalt ausgeben: eigene Seiten roh (HTML-Block), andere Seiten im normalen Layout */
function bsv_render_page() {
	$r = bsv_route();
	$post = get_post();
	if ($r && $post && strpos(ltrim($post->post_content), '<!-- wp:html -->') === 0) {
		$html = preg_replace(['/^\s*<!-- wp:html -->\s*/', '/\s*<!-- \/wp:html -->\s*$/', '/<!-- bsv:seo [A-Za-z0-9+\/=]+ -->\s*/'], '', $post->post_content);
		echo '<div data-page="' . esc_attr($r['page']) . '" class="is-active">' . $html . '</div>';
		return;
	}
	?>
	<div data-page="seite" class="is-active">
		<section class="page-hero page-hero--plain"><div class="wrap"><div class="page-hero-copy">
			<div class="crumbs"><a href="<?php echo esc_url(home_url('/')); ?>">Start</a><span>/</span><span><?php the_title(); ?></span></div>
			<h1><?php the_title(); ?></h1>
		</div></div></section>
		<section class="section"><div class="wrap wp-prose"><?php the_content(); ?></div></section>
	</div>
	<?php
}

/* Kontaktband vor der Fußzeile (auf der Kontaktseite ausgeblendet) */
function bsv_kontaktband() {
	if (bsv_route_key() === 'kontakt') return null;
	$r = bsv_route();
	if ($r && !empty($r['kb'])) return $r['kb'];
	return ['h' => 'Klarheit beginnt mit einem Gespräch.', 'p' => 'Schildern Sie mir Ihr Anliegen. Ich freue mich auf Ihre Anfrage.', 'b' => 'Anfrage senden', 's' => 'info@bsv-niewerth.de', 'thema' => ''];
}

/* Kontaktformular: Anfrage per E-Mail an das Büro (mit Fotos als Anhang) */
add_action('rest_api_init', function () {
	register_rest_route('bsv/v1', '/anfrage', [
		'methods' => 'POST',
		'permission_callback' => '__return_true',
		'callback' => 'bsv_anfrage',
	]);
});
function bsv_anfrage(WP_REST_Request $req) {
	$p = $req->get_body_params();
	$ok = new WP_REST_Response(['ok' => true], 200);
	if (!empty($p['website'])) return $ok;                                   // Spam-Falle
	$ts = isset($p['ts']) ? (int) $p['ts'] : 0;
	if ($ts && time() - $ts < 3) return $ok;                                 // zu schnell ausgefüllt
	$ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
	$key = 'bsv_rl_' . md5($ip);
	$n = (int) get_transient($key);
	if ($n >= 6) return new WP_Error('bsv_limit', 'Es wurden in kurzer Zeit zu viele Anfragen gesendet.', ['status' => 429]);

	$name = sanitize_text_field(isset($p['name']) ? $p['name'] : '');
	$email = sanitize_email(isset($p['email']) ? $p['email'] : '');
	$msg = sanitize_textarea_field(isset($p['nachricht']) ? $p['nachricht'] : '');
	$tel = sanitize_text_field(isset($p['telefon']) ? $p['telefon'] : '');
	$ort = sanitize_text_field(isset($p['ort']) ? $p['ort'] : '');
	$thema = sanitize_text_field(isset($p['thema']) ? $p['thema'] : 'Allgemein');
	if (!$name || !is_email($email) || !$msg) return new WP_Error('bsv_fields', 'Bitte füllen Sie Name, E-Mail und Nachricht aus.', ['status' => 400]);
	if (empty($p['einwilligung'])) return new WP_Error('bsv_consent', 'Bitte bestätigen Sie die Datenschutzerklärung.', ['status' => 400]);

	$att = [];
	$files = $req->get_file_params();
	if (!empty($files['fotos']['name']) && is_array($files['fotos']['name'])) {
		$total = 0;
		$tmpdir = trailingslashit(get_temp_dir());
		$types = ['jpg|jpeg|jpe' => 'image/jpeg', 'png' => 'image/png', 'gif' => 'image/gif', 'webp' => 'image/webp', 'heic' => 'image/heic', 'heif' => 'image/heif'];
		foreach ($files['fotos']['name'] as $i => $fn) {
			if ($files['fotos']['error'][$i] !== UPLOAD_ERR_OK || count($att) >= 10) continue;
			$size = (int) $files['fotos']['size'][$i];
			$total += $size;
			if ($size > 12 * MB_IN_BYTES || $total > 30 * MB_IN_BYTES) {
				foreach ($att as $f) @unlink($f);
				return new WP_Error('bsv_size', 'Die Fotos sind zusammen zu groß (höchstens 30 MB).', ['status' => 413]);
			}
			$chk = wp_check_filetype_and_ext($files['fotos']['tmp_name'][$i], $fn, $types);
			if (empty($chk['type'])) continue;
			$dest = $tmpdir . wp_unique_filename($tmpdir, sanitize_file_name($fn));
			if (move_uploaded_file($files['fotos']['tmp_name'][$i], $dest)) $att[] = $dest;
		}
	}

	$to = get_option('bsv_mail_to', 'info@bsv-niewerth.de');
	$subject = 'Website-Anfrage: ' . $thema . ' – ' . $name;
	$body = "Neue Anfrage über bsv-niewerth.de\n\n"
		. "Thema:    $thema\nName:     $name\nE-Mail:   $email\nTelefon:  " . ($tel ?: '–') . "\nObjekt:   " . ($ort ?: '–') . "\n"
		. 'Fotos:    ' . count($att) . "\n\nNachricht:\n$msg\n\n"
		. "Einwilligung Datenschutz: ja\nGesendet: " . wp_date('d.m.Y H:i') . " Uhr\n";
	$headers = ['Content-Type: text/plain; charset=UTF-8', 'Reply-To: ' . str_replace(['<', '>', '"', ',', "\n", "\r"], '', $name) . ' <' . $email . '>'];
	$sent = wp_mail($to, $subject, $body, $headers, $att);
	foreach ($att as $f) @unlink($f);
	set_transient($key, $n + 1, HOUR_IN_SECONDS);
	if (!$sent) return new WP_Error('bsv_mail', 'Die Anfrage konnte gerade nicht versendet werden.', ['status' => 500]);
	return $ok;
}

/* Beim Aktivieren: sprechende Adressen (/leistungen/…) und bis zur Freigabe für Suchmaschinen gesperrt */
add_action('after_switch_theme', function () {
	update_option('permalink_structure', '/%postname%/');
	if (!get_option('bsv_freigegeben')) update_option('blog_public', 0);
	flush_rewrite_rules();
});

/* Icons für Browser-Tab, Handy-Startbildschirm und Web-App (eigene Ausgabe statt WordPress-Website-Icon) */
remove_action('wp_head', 'wp_site_icon', 99);
add_action('wp_head', function () {
	$i = get_template_directory_uri() . '/assets/icons/';
	echo '<link rel="icon" href="' . esc_url($i . 'favicon.ico') . '" sizes="48x48">' . "\n";
	echo '<link rel="icon" href="' . esc_url($i . 'favicon.svg') . '" type="image/svg+xml">' . "\n";
	echo '<link rel="apple-touch-icon" href="' . esc_url($i . 'apple-touch-icon.png') . '">' . "\n";
	echo '<link rel="manifest" href="' . esc_url($i . 'site.webmanifest') . '">' . "\n";
	echo '<meta name="apple-mobile-web-app-title" content="BSV Niewerth">' . "\n";
}, 2);

/* Vorschaubild je Seite für WhatsApp, Facebook, LinkedIn … */
function bsv_og_image() {
	$k = bsv_route_key();
	if ($k && file_exists(__DIR__ . '/assets/og/' . $k . '.jpg')) return get_template_directory_uri() . '/assets/og/' . $k . '.jpg';
	return get_template_directory_uri() . '/assets/og/start.jpg';
}

/* Theme-Aktualisierung aus dem GitHub-Repository des Projekts (nur für Administratoren, mit Prüfsumme) */
add_action('rest_api_init', function () {
	register_rest_route('bsv/v1', '/update', [
		'methods' => 'POST',
		'permission_callback' => function () { return current_user_can('update_themes') && current_user_can('install_themes'); },
		'callback' => 'bsv_self_update',
	]);
});
function bsv_self_update(WP_REST_Request $req) {
	$sha = strtolower((string) $req->get_param('sha256'));
	if (!preg_match('/^[a-f0-9]{64}$/', $sha)) return new WP_Error('bsv_sha', 'Prüfsumme fehlt.', ['status' => 400]);
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/misc.php';
	require_once ABSPATH . 'wp-admin/includes/theme.php';
	require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
	$tmp = download_url('https://raw.githubusercontent.com/xcryzuz19/bsv-niewerth-entwurf/main/wp/bsv-niewerth.zip', 120);
	if (is_wp_error($tmp)) return $tmp;
	if (!hash_equals($sha, hash_file('sha256', $tmp))) { @unlink($tmp); return new WP_Error('bsv_sha', 'Prüfsumme stimmt nicht, Update abgebrochen.', ['status' => 409]); }
	$skin = new WP_Ajax_Upgrader_Skin();
	$up = new Theme_Upgrader($skin);
	$res = $up->install($tmp, ['overwrite_package' => true]);
	@unlink($tmp);
	if (is_wp_error($res)) return $res;
	if (!$res) return new WP_Error('bsv_update', implode(' ', $skin->get_error_messages()) ?: 'Update fehlgeschlagen.', ['status' => 500]);
	wp_clean_themes_cache();
	if (function_exists('wp_cache_clear_cache')) wp_cache_clear_cache();
	return ['ok' => true, 'version' => wp_get_theme('bsv-niewerth')->get('Version')];
}

/* ---------- Zugangsschutz „Im Aufbau“ ----------
   Ein-/ausschalten und Passwort ändern: Einstellungen → Lesen. Angemeldete Nutzer sehen die Seite immer. */
function bsv_zugang_hash($v) {
	$v = trim((string) $v);
	if ($v === '') return get_option('bsv_zugang_passwort', '');           // leer = unverändert
	if (strpos($v, '$2y$') === 0 || strpos($v, '$argon') === 0) return $v; // schon verschlüsselt
	return password_hash($v, PASSWORD_DEFAULT);
}
add_action('init', function () {
	register_setting('reading', 'bsv_zugang_aktiv', ['type' => 'boolean', 'default' => false, 'show_in_rest' => true, 'sanitize_callback' => 'rest_sanitize_boolean']);
	register_setting('reading', 'bsv_zugang_passwort', ['type' => 'string', 'default' => '', 'show_in_rest' => true, 'sanitize_callback' => 'bsv_zugang_hash']);
});
add_action('admin_init', function () {
	add_settings_section('bsv_zugang', 'Website im Aufbau', function () {
		echo '<p>Solange der Schutz aktiv ist, sehen Besucher nur die Seite „Im Aufbau“ mit Logo und Kontaktdaten. Mit dem Passwort ist die ganze Website sichtbar. Angemeldete Nutzer sehen sie immer.</p>';
	}, 'reading');
	add_settings_field('bsv_zugang_aktiv', 'Zugangsschutz', function () {
		echo '<label><input type="checkbox" name="bsv_zugang_aktiv" value="1" ' . checked(get_option('bsv_zugang_aktiv'), true, false) . '> Website ist im Aufbau und nur mit Passwort sichtbar</label>';
	}, 'reading', 'bsv_zugang');
	add_settings_field('bsv_zugang_passwort', 'Neues Passwort', function () {
		echo '<input type="text" name="bsv_zugang_passwort" value="" autocomplete="new-password" class="regular-text"><p class="description">Leer lassen, um das bisherige Passwort zu behalten.</p>';
	}, 'reading', 'bsv_zugang');
});
add_action('update_option_bsv_zugang_aktiv', function () { if (function_exists('wp_cache_clear_cache')) wp_cache_clear_cache(); });
add_action('update_option_bsv_zugang_passwort', function () { if (function_exists('wp_cache_clear_cache')) wp_cache_clear_cache(); });

function bsv_zugang_token() {
	return hash_hmac('sha256', (string) get_option('bsv_zugang_passwort', ''), wp_salt('auth'));
}
function bsv_zugang_ok() {
	if (!get_option('bsv_zugang_aktiv') || !get_option('bsv_zugang_passwort')) return true;
	if (is_user_logged_in()) return true;
	return isset($_COOKIE['bsv_zugang']) && hash_equals(bsv_zugang_token(), (string) $_COOKIE['bsv_zugang']);
}
add_action('template_redirect', function () {
	if (!get_option('bsv_zugang_aktiv') || !get_option('bsv_zugang_passwort')) return;
	if (!defined('DONOTCACHEPAGE')) define('DONOTCACHEPAGE', true);   // nichts zwischenspeichern, solange der Schutz aktiv ist
	nocache_headers();
	$fehler = '';
	if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bsv_zugang_pw'])) {
		$ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
		$key = 'bsv_zg_' . md5($ip);
		$n = (int) get_transient($key);
		if ($n >= 10) {
			$fehler = 'Zu viele Versuche. Bitte versuchen Sie es später noch einmal.';
		} elseif (password_verify(wp_unslash($_POST['bsv_zugang_pw']), get_option('bsv_zugang_passwort'))) {
			setcookie('bsv_zugang', bsv_zugang_token(), ['expires' => time() + 30 * DAY_IN_SECONDS, 'path' => COOKIEPATH ?: '/', 'domain' => COOKIE_DOMAIN, 'secure' => is_ssl(), 'httponly' => true, 'samesite' => 'Lax']);
			wp_safe_redirect(remove_query_arg('zugang'));
			exit;
		} else {
			set_transient($key, $n + 1, HOUR_IN_SECONDS);
			$fehler = 'Das Passwort stimmt nicht.';
		}
	}
	if (bsv_zugang_ok()) return;
	header('X-Robots-Tag: noindex, nofollow');
	include __DIR__ . '/zugang.php';
	exit;
}, 0);
