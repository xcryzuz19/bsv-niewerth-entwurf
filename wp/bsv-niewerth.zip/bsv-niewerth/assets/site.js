const $id = id => document.getElementById(id) || document.createElement("div");

document.documentElement.lang = "de";
const ICONS = {
  schaden: '<path class="a" d="M5 28V14L18 4l13 10v14z"/><path class="b" d="M17 9l-3 6 5 3-4 7"/>',
  kauf: '<path class="a" d="M3 28V15L15 6l12 9v3"/><path class="a" d="M9 28V19h6v9"/><circle class="b" cx="25" cy="23" r="5"/><path class="b" d="M28.5 26.5L32 30"/>',
  gutachten: '<path class="a" d="M8 3h13l7 7v20H8z"/><path class="a" d="M21 3v7h7"/><path class="b" d="M12 19l3 3 6-6"/>',
  bau: '<path class="a" d="M3 30h28M7 30V14h20v16"/><path class="a" d="M7 14L17 6l10 8"/><path class="b" d="M12 21h10M12 25h6"/>',
  wert: '<path class="a" d="M3 28V14L14 5l11 9"/><path class="a" d="M8 28V19h6v9"/><circle class="b" cx="25" cy="23" r="6"/><path class="b" d="M27 20.5a3 3 0 100 5M22 22.2h4M22 24h4"/>',
  streit: '<path class="a" d="M17 4v24M10 30h14M5 10h24"/><path class="b" d="M5 10l-3.5 8h7zM29 10l-3.5 8h7z"/>',
  energie: '<path class="a" d="M4 28V14L17 4l13 10v14z"/><path class="b" d="M18 10l-5 8h4l-1 6 5-8h-4z"/>',
  leck: '<path class="a" d="M2 12h12v6H2M32 12H20v6h12"/><path class="b" d="M17 18c2.5 3.5 4 5.5 4 7.5a4 4 0 01-8 0c0-2 1.5-4 4-7.5z"/>',
  thermo: '<rect class="a" x="3" y="8" width="20" height="15" rx="2"/><path class="a" d="M23 12l7-3v13l-7-3M10 23v5h6v-5"/><circle class="b" cx="13" cy="15.5" r="3.5"/>'
};
const ic = k => `<svg class="ico" viewBox="0 0 34 34" aria-hidden="true">${ICONS[k]}</svg>`;
const use = id => `<svg aria-hidden="true"><use href="#${id}"/></svg>`;
const ph = t => `<span class="ph">${t}</span>`;
const ROOF = '<svg class="roofline" viewBox="0 0 100 18" preserveAspectRatio="none" aria-hidden="true"><path d="M0 17 L50 2 L100 17"/></svg>';

/* Situationsbezogene Anfragen je Leistung: [Schaltfläche, Überschrift, Text, Beispiel im Nachrichtenfeld] */
const CTA = {
  gebaeudeschaeden: ["Schaden einschätzen lassen", "Riss, Feuchte oder Schimmel entdeckt?", "Schildern Sie mir kurz, was Ihnen aufgefallen ist, gerne mit ein paar Fotos. Ich melde mich mit einer ersten Einschätzung und sage Ihnen, ob ein Ortstermin sinnvoll ist.", "z. B. Feuchter Fleck an der Kellerwand seit dem Frühjahr, Baujahr 1978"],
  hauskaufberatung: ["Hauskauf begleiten lassen", "Haus oder Wohnung im Blick?", "Nennen Sie mir das Objekt und, falls schon bekannt, den Besichtigungstermin. Ich sage Ihnen, ob ich dabei sein kann und was die Begleitung kostet.", "z. B. Einfamilienhaus, Baujahr 1965, Besichtigung nächste Woche in Borken"],
  gutachten: ["Gutachten anfragen", "Sie brauchen eine fundierte Bewertung?", "Beschreiben Sie kurz den Schaden und wofür Sie das Gutachten brauchen. Ich nenne Ihnen den nötigen Umfang und einen klaren Kostenrahmen.", "z. B. Risse nach dem Anbau, Gutachten für das Gespräch mit der Baufirma"],
  bauueberwachung: ["Bau prüfen lassen", "Sie bauen neu oder modernisieren?", "Erzählen Sie mir, was geplant ist und wie weit der Bau ist. Ich schlage Ihnen vor, welche Bauabschnitte ich prüfe, bevor sie hinter Putz und Estrich verschwinden.", "z. B. Neubau Einfamilienhaus, Bodenplatte fertig, Rohbau startet im April"],
  schlichtung: ["Schlichtung anfragen", "Streit über eine Bauleistung?", "Schildern Sie mir kurz, worum es geht. Ich sage Ihnen ehrlich, ob eine Schlichtung in Ihrem Fall Aussicht auf Erfolg hat.", "z. B. Uneinigkeit mit dem Fliesenleger über Gefälle und Fugen im Bad"],
  energieberatung: ["Energieberatung anfragen", "Sanierung geplant oder Energieausweis nötig?", "Nennen Sie mir Baujahr, Heizung und was Sie vorhaben. Ich sage Ihnen, welche Beratung passt und welche Förderung in Frage kommen kann.", "z. B. Haus von 1972, neue Heizung geplant, Frage nach Förderung"],
  leckageortung: ["Leck orten lassen", "Wasserfleck oder Verdacht auf ein Leck?", "Beschreiben Sie, wo das Wasser auftritt und seit wann. Ich orte die Stelle gezielt, damit nur dort geöffnet wird, wo es nötig ist.", "z. B. Wasserfleck an der Wohnzimmerdecke unter dem Bad, Wasserzähler läuft"],
  thermografie: ["Wärmebild anfragen", "Kalte Wände oder hohe Heizkosten?", "Schildern Sie kurz, was Ihnen auffällt. Wärmebilder sind in der Heizperiode am aussagekräftigsten, den Termin stimme ich passend zur Witterung mit Ihnen ab.", "z. B. Kalte Ecken im Schlafzimmer, Wärmebild der ganzen Fassade gewünscht"]
};
/* Einstieg nach Problem auf der Startseite */
const NEEDS = [
  { icon: "schaden", h: "Feuchtigkeit im Keller oder an der Wand?", t: "Finden Sie heraus, woher die Feuchtigkeit kommt und welche Maßnahmen wirklich nötig sind.", cta: "Feuchte einschätzen lassen", to: "gebaeudeschaeden", hint: "z. B. Feuchte Kellerwand mit weißen Ausblühungen, muffiger Geruch, Baujahr 1975" },
  { icon: "schaden", h: "Risse in Wand, Decke oder Fassade?", t: "Ich kläre, ob der Riss nur optisch stört oder auf ein Problem im Bauwerk hinweist.", cta: "Riss beurteilen lassen", to: "gebaeudeschaeden", hint: "z. B. Schräger Riss über dem Fenster, seit einem Jahr breiter geworden" },
  { icon: "thermo", h: "Schimmel in der Wohnung?", t: "Wärmebrücke, Lüftung oder eindringende Feuchte: Erst wenn die Ursache klar ist, hält die Sanierung.", cta: "Schimmel untersuchen lassen", to: "gebaeudeschaeden", hint: "z. B. Schimmel in der Schlafzimmerecke, kommt nach dem Abwischen wieder" },
  { icon: "kauf", h: "Haus oder Wohnung im Blick?", t: "Ich begleite die Besichtigung und zeige Ihnen, welcher Sanierungsbedarf auf Sie zukommt, bevor Sie unterschreiben.", cta: "Hauskauf begleiten lassen", to: "hauskaufberatung", hint: CTA.hauskaufberatung[3] },
  { icon: "bau", h: "Neubau oder Umbau?", t: "Ich prüfe die Bauabschnitte, bevor Mängel hinter Putz und Estrich verschwinden.", cta: "Bau prüfen lassen", to: "bauueberwachung", hint: CTA.bauueberwachung[3] },
  { icon: "leck", h: "Wasserschaden oder Leitung undicht?", t: "Ich orte die Leckage gezielt, damit nur dort geöffnet wird, wo es nötig ist.", cta: "Leck orten lassen", to: "leckageortung", hint: CTA.leckageortung[3] }
];
/* Aus der Praxis: echte, anonymisierte Fälle von André. Solange die Liste leer ist, bleibt der Bereich ausgeblendet.
   Aufbau: { to: "gebaeudeschaeden", ort: "Kreis Borken", h: "Überschrift", aus: "Ausgangslage", unt: "Untersuchung", erg: "Ergebnis", foto: "data:image/jpeg;base64,..." (optional) } */
const PRAXIS = [];

const LEISTUNGEN = [
  { slug: "gebaeudeschaeden", icon: "schaden", title: "Gebäude\u00adschäden", short: "Risse, Feuchtigkeit, Setzungen oder Schimmel: Ursachen klären und den passenden Sanierungsweg aufzeigen.",
    foto: "Foto: Riss im Mauerwerk oder feuchte Kellerwand",
    lead: "Wie ernst ist ein Riss, woher kommt die Feuchtigkeit und was ist jetzt zu tun? Ich gehe Gebäudeschäden auf den Grund, damit Sie die Ursache verstehen und wissen, welche Maßnahmen sinnvoll sind.",
    anlaesse: ["Risse in Mauerwerk, Putz oder Beton", "Feuchte Wände, nasser Keller, Ausblühungen", "Schimmel in Wohnräumen", "Schäden nach Sturm, Leitungswasser oder Brand", "Mängel nach einer Sanierung oder am Neubau"],
    vorgehen: [["Erstgespräch", "Sie schildern den Schaden am Telefon oder schicken Fotos. Ich sage Ihnen, ob ein Ortstermin sinnvoll ist."], ["Ortstermin", "Ich untersuche den Schaden, messe Feuchte und Temperaturen und dokumentiere alles mit Fotos."], ["Ursachenanalyse", "Ich werte die Messungen aus und ermittle, wodurch der Schaden entstanden ist."], ["Empfehlung", "Sie erhalten eine Einschätzung mit Sanierungsweg, auf Wunsch als Bericht oder Gutachten."]],
    ergebnis: [["i-shield", "Ursache geklärt", "Sie wissen, wodurch der Schaden entstanden ist, statt nur die Symptome zu behandeln."], ["i-doc", "Nachvollziehbare Dokumentation", "Befunde mit Fotos und Messwerten, fachlich eingeordnet nach den anerkannten Regeln der Technik."], ["i-euro", "Optional: Sanierungskonzept", "Ein auf den Schaden abgestimmtes Konzept mit Kostenschätzung als Grundlage für Ihre Planung."]],
    faq: [["Was kostet die Begutachtung eines Schadens?", "Das hängt von Art und Umfang des Schadens ab. Nach unserem ersten Gespräch nenne ich Ihnen einen Preis oder einen klaren Kostenrahmen."], ["Übernimmt die Versicherung die Kosten?", "Bei versicherten Schäden werden die Kosten häufig ganz oder teilweise übernommen. Gern helfe ich Ihnen bei der Klärung. Meine Dokumentation können Sie direkt bei Ihrer Versicherung vorlegen."], ["Wie schnell können Sie kommen?", "Kurzfristig, je nach Dringlichkeit. Rufen Sie mich an, dann stimmen wir einen zeitnahen Termin ab."]] },

  { slug: "hauskaufberatung", icon: "kauf", title: "Haus- und Wohnungs\u00adkauf\u00adberatung", short: "Ob Haus oder Eigentumswohnung, Bestand oder Neubau: Ich prüfe den baulichen Zustand und mögliche Mängel, damit Sie Ihre Kaufentscheidung auf einer fundierten Grundlage treffen.",
    foto: "Foto: Besichtigung eines Hauses, Blick auf Dach oder Keller",
    lead: "Ein Immobilienkauf bindet Sie oft über Jahrzehnte. Ich begleite Sie zur Besichtigung, beurteile den erkennbaren baulichen Zustand und zeige mögliche Risiken sowie Sanierungsbedarf auf. So gewinnen Sie Klarheit vor dem Kauf und eine fundierte Grundlage für Ihre Kaufentscheidung und Preisverhandlung.",
    anlaesse: ["Kauf eines Hauses oder einer Wohnung, egal ob neu oder gebraucht", "Altbau mit unklarem Sanierungsstand", "Hinweise auf Feuchte oder Risse bei der Besichtigung", "Übergabe einer neu gebauten Immobilie vom Bauträger", "Sachliche Argumente für die Preisverhandlung"],
    vorgehen: [["Termin abstimmen", "Wir legen den Termin gemeinsam mit Verkäufer, Makler oder Bauträger fest."], ["Gemeinsame Besichtigung", "Wir gehen die Immobilie vom Keller bis zum Dach durch. Sie können jederzeit nachfragen."], ["Einschätzung vor Ort", "Ich erläutere Ihnen den erkennbaren baulichen Zustand und ordne festgestellte Mängel ein."], ["Dokumentation", "Auf Wunsch fasse ich die Ergebnisse übersichtlich mit Fotos und Empfehlungen zusammen."]],
    ergebnis: [["i-doc", "Mängelliste", "Alle Auffälligkeiten, sortiert nach Dringlichkeit."], ["i-shield", "Sanierungsbedarf", "Welche Maßnahmen in den nächsten Jahren anstehen und wie dringend sie sind."], ["i-shield", "Verhandlungsbasis", "Sachliche Argumente für das Gespräch über den Kaufpreis."]],
    faq: [["Wie lange dauert eine Besichtigung?", "Meist 1,5 bis 3 Stunden, abhängig von Größe und Zustand der Immobilie."], ["Kann ich bei der Besichtigung dabei sein?", "Ja, ausdrücklich. Ich erkläre Ihnen vor Ort, was ich sehe und was es für Ihre Entscheidung bedeutet."], ["Begleiten Sie auch beim Neubau?", "Ja. Auch während der Bauphase sowie bei Teilabnahmen und der abschließenden Bauabnahme stehe ich Ihnen fachkundig zur Seite."]] },

  { slug: "gutachten", icon: "gutachten", title: "Gutachten\u00aderstellung", short: "Ursachen klären, Schäden bewerten, Entscheidungen absichern: unabhängig untersucht und verständlich erläutert.",
    foto: "Foto: Gutachten-Deckblatt mit Logo oder Dokumentation am Schreibtisch",
    lead: "Unabhängig untersucht, nachvollziehbar bewertet: Ein Gutachten gibt Ihnen eine sachliche Grundlage für die Sanierung, für Ihre Versicherung, vor dem Kauf oder für das Gespräch mit der Baufirma.",
    anlaesse: ["Vorbereitung einer Sanierung", "Unterschiedliche Auffassungen über eine Bauleistung", "Unterstützung bei Versicherungsfragen", "Entscheidung vor einem Immobilienkauf", "Vermutete Baumängel oder Ausführungsfehler"],
    vorgehen: [["Fragestellung klären", "Wir legen fest, welche Fragen das Gutachten beantworten soll."], ["Ortstermin", "Ich nehme den Befund auf, messe und fotografiere."], ["Auswertung", "Ich bewerte die Ergebnisse nach den anerkannten Regeln der Technik."], ["Gutachten", "Sie erhalten das schriftliche Gutachten und ich erläutere es Ihnen auf Wunsch."]],
    ergebnis: [["i-doc", "Schriftliches Gutachten", "Befund, mögliche Ursachen und fachliche Bewertung, klar voneinander getrennt."], ["i-photo", "Nachvollziehbare Dokumentation", "Aussagekräftige Fotos und gegebenenfalls Messergebnisse."], ["i-shield", "Empfehlungen", "Erforderliche Maßnahmen oder weiterführende Untersuchungen."]],
    faq: [["Was ist der Unterschied zwischen Kurzgutachten und Gutachten?", "Ein Kurzgutachten fasst die wichtigsten Feststellungen kompakt zusammen. Ein ausführliches Gutachten begründet jede Aussage im Detail. Welcher Umfang sinnvoll ist, besprechen wir vorab."], ["Wofür kann ich ein Baugutachten nutzen?", "Zum Beispiel zur Vorbereitung einer Sanierung, zur technischen Klärung bei unterschiedlichen Auffassungen über eine Bauleistung oder zur Unterstützung bei Versicherungsfragen und Kaufentscheidungen. Eine rechtliche Beratung ist damit nicht verbunden."], ["Wie lange dauert die Erstellung?", "Das hängt vom Umfang der Fragestellung ab. Den voraussichtlichen Zeitrahmen nenne ich Ihnen vorab, damit Sie planen können."]] },

  { slug: "bauueberwachung", icon: "bau", title: "Bau\u00adüberwachung & Bau\u00adleitung", short: "Bauausführung zu vereinbarten Bauabschnitten prüfen, Abnahmen begleiten und auf Wunsch die Bauleitung übernehmen.",
    foto: "Foto: Baustelle, Rohbau oder Kontrolle einer Abdichtung",
    lead: "Ich prüfe Ihren Bau zu den entscheidenden Zeitpunkten, solange Abdichtung, Dämmung und Anschlüsse noch sichtbar sind, und begleite Sie bis zur Abnahme.",
    anlaesse: ["Neubau eines Einfamilienhauses", "Bauen mit Bauträger oder Generalunternehmer", "Umfangreiche Sanierung im Bestand", "Kontrolle vor dem Verschließen von Abdichtung und Dämmung", "Bauabnahme"],
    vorgehen: [["Umfang festlegen", "Wir stimmen Art, Umfang und Häufigkeit der Kontrollen auf Ihr Bauvorhaben ab."], ["Kontrolle vor Ort", "Ich prüfe die Ausführung, bevor wichtige Bauteile verdeckt werden."], ["Dokumentation", "Auffälligkeiten halte ich mit Fotos und verständlicher fachlicher Einordnung fest."], ["Abnahme", "Ich unterstütze Sie bei der Prüfung und bei der Aufnahme offener Punkte in das Abnahmeprotokoll."]],
    ergebnis: [["i-doc", "Protokolle", "Nachvollziehbare Dokumentation der kontrollierten Bauabschnitte."], ["i-shield", "Abweichungen früh erkannt", "Korrekturen sind möglich, solange Details noch sichtbar sind."], ["i-euro", "Weniger Folgekosten", "Frühzeitig erkannte Mängel lassen sich mit weniger Aufwand beheben."]],
    faq: [["Welche Kontrolltermine sind wichtig?", "Vor allem Bauteile und Anschlüsse, die später verdeckt werden: zum Beispiel Abdichtung und Bodenplatte, Rohbau, Dach, Fenster und Dämmung vor dem Innenausbau sowie die Abnahme."], ["Was ist der Unterschied zwischen Baubegleitung und Bauleitung?", "Bei der Baubegleitung kontrolliere ich die Ausführung durch gezielte Begehungen. Eine umfassende Bauleitung oder Objektüberwachung, also auch die Koordination von Gewerken und Terminen, wird gesondert vereinbart."], ["Was kostet die Baubegleitung?", "Art, Umfang und Häufigkeit der Kontrollen stimmen wir auf Ihr Bauvorhaben ab. Danach richtet sich auch der Preis, den ich Ihnen vorab nenne."]] },


  { slug: "schlichtung", icon: "streit", title: "Schlichtung bei Bau\u00adstreitigkeiten", short: "Strittige Mängel neutral bewerten und sachlich vermitteln, damit eine außergerichtliche Einigung möglich wird.",
    foto: "Foto: Gespräch auf der Baustelle",
    lead: "Streit über Baumängel kostet Zeit, Geld und Nerven. Ich kläre die technischen Fragen neutral und zeige Wege zu einer Einigung ohne Gericht.",
    anlaesse: ["Streit über die Qualität der Ausführung", "Uneinigkeit über Nachbesserung oder Minderung", "Rechnung wird wegen Mängeln nicht bezahlt", "Abnahme wird verweigert", "Beide Seiten wollen eine schnelle Lösung"],
    vorgehen: [["Strittige Punkte erfassen", "Ich lasse mir die Sicht der Beteiligten schildern und sichte relevante Bauunterlagen."], ["Gemeinsame Ortsbesichtigung", "Wir sehen uns die strittigen Punkte gemeinsam an. Ich dokumentiere den baulichen Zustand."], ["Fachliche Bewertung", "Ich bewerte, ob die beanstandete Ausführung fachlich begründet zu bemängeln ist."], ["Lösungswege", "Ich erläutere die Befunde und zeige technisch geeignete Lösungs- und Nachbesserungsvorschläge auf."]],
    ergebnis: [["i-shield", "Sachliche Grundlage", "Eine fachlich begründete Bewertung, für alle Beteiligten nachvollziehbar."], ["i-doc", "Schriftliche Dokumentation", "Technische Ergebnisse und vereinbarte Maßnahmen."], ["i-euro", "Chance auf Einigung", "Kann helfen, langwierige Auseinandersetzungen und zusätzliche Kosten zu vermeiden."]],
    faq: [["Ist das Ergebnis verbindlich?", "Meine Tätigkeit dient der technischen Klärung und sachverständigen Vermittlung. Eine rechtliche Beratung oder eine verbindliche Entscheidung über Ansprüche ist damit nicht verbunden."], ["Wer trägt die Kosten?", "In der Regel teilen sich beide Seiten die Kosten. Das ist fair und meist deutlich günstiger als ein langer Rechtsstreit. Den Umfang vereinbaren wir vorab schriftlich."], ["Brauche ich einen Anwalt?", "Für eine technische Klärung nicht. Ich kümmere mich um die bautechnischen Fragen. Geht es um rechtliche Ansprüche, ist eine anwaltliche Beratung der richtige Weg."]] },

  { slug: "energieberatung", icon: "energie", title: "Energie\u00adberatung", short: "Energieberatung, Energieausweise, Fördermittelberatung und individueller Sanierungsfahrplan (iSFP).",
    foto: "Foto: Fassade oder Dach mit Dämmarbeiten",
    lead: "Energieausweis, Fördermittel oder Sanierungsfahrplan: Ich zeige Ihnen, welche Maßnahmen sich für Ihr Haus wirklich lohnen und in welcher Reihenfolge sie sinnvoll sind.",
    anlaesse: ["Hohe Heizkosten", "Geplanter Heizungstausch", "Sanierung von Dach, Fassade oder Fenstern", "Kauf eines älteren Hauses", "Fragen zu Fördermitteln"],
    vorgehen: [["Vor-Ort-Termin", "Ich betrachte Gebäudehülle und Anlagentechnik."], ["Analyse", "Auf Wunsch mit Wärmebildern, um Schwachstellen sichtbar zu machen."], ["Empfehlungen", "Maßnahmen in sinnvoller Reihenfolge, mit Investitionen, Einsparpotenzial und möglichen Förderungen."], ["Nachweise", "Auf Wunsch Energieausweis oder individueller Sanierungsfahrplan (iSFP)."]],
    ergebnis: [["i-shield", "Schwachstellen erkannt", "Eine Übersicht, wo Ihr Gebäude Energie verliert."], ["i-doc", "Klare Reihenfolge", "Welche Maßnahmen zuerst sinnvoll sind und welche später folgen können."], ["i-euro", "Fördermöglichkeiten", "Passende Programme mit Voraussetzungen, Fristen und Nachweisen."]],
    faq: [["Ist die Beratung förderfähig?", "Ich unterstütze Sie dabei, passende Fördermöglichkeiten zu erkennen und frühzeitig in Ihre Sanierungsplanung einzubeziehen, inklusive der jeweiligen Voraussetzungen, Fristen und Nachweise."], ["Wann ist eine Thermografie sinnvoll?", "In der Heizperiode, wenn es draußen deutlich kälter ist als drinnen. Dann sind Wärmebrücken am besten zu sehen."], ["Erstellen Sie auch Energieausweise?", "Ja. Ich erstelle Bedarfs- und Verbrauchsausweise und erkläre Ihnen, welche Ausweisart infrage kommt und wie die Kennwerte einzuordnen sind."]] },

  { slug: "leckageortung", icon: "leck", title: "Leckage\u00adortung", short: "Undichtigkeiten an Leitungen und Abdichtungen gezielt eingrenzen, damit nur dort geöffnet wird, wo es nötig ist.",
    foto: "Foto: Feuchtemessung am Boden oder Wasserfleck an der Decke",
    lead: "Wasser sucht sich seinen Weg, und wo der Fleck sichtbar wird, liegt das Leck oft nicht. Ich finde die Ursache mit Messtechnik und dokumentiere sie für Ihre Versicherung.",
    anlaesse: ["Feuchte Stellen an Decke, Wand oder Boden", "Wasserzähler läuft, obwohl nichts verbraucht wird", "Druckverlust in der Heizung", "Feuchter Estrich nach einem Wasserschaden", "Undichte Dusche oder undichtes Flachdach"],
    vorgehen: [["Schadensbild erfassen", "Ich prüfe, welche Leitungen, Anschlüsse oder Bauteile als Ursache infrage kommen."], ["Messung", "Je nach Befund grenzen geeignete Messverfahren die mögliche Leckstelle ein."], ["Eingrenzung", "Ist eine Öffnung nötig, kann sie auf den betroffenen Bereich beschränkt werden."], ["Dokumentation", "Ich erläutere die Befunde und welche weiteren Prüfungen oder Trocknungen sinnvoll sind."]],
    ergebnis: [["i-shield", "Gezielte Öffnung", "Unnötige Bauteilöffnungen werden vermieden."], ["i-doc", "Dokumentation", "Befunde nachvollziehbar festgehalten, zum Beispiel für Ihre Versicherung."], ["i-euro", "Folgeschäden begrenzt", "Je früher die Stelle gefunden wird, desto kleiner bleibt der Schaden."]],
    faq: [["Zahlt die Versicherung die Leckageortung?", "In vielen Fällen übernimmt die Leitungswasserversicherung die Kosten für die Suche. Ein kurzer Anruf bei Ihrer Versicherung schafft Sicherheit, meine Dokumentation können Sie dort direkt vorlegen."], ["Welche Messverfahren setzen Sie ein?", "Je nach Befund setze ich geeignete Messverfahren ein, um die Feuchtigkeitsverteilung zu erfassen und die mögliche Leckstelle einzugrenzen, zum Beispiel Feuchtemessung und Wärmebild."], ["Wie schnell können Sie kommen?", "Kurzfristig, je nach Dringlichkeit. Bei akutem Wasseraustritt rufen Sie mich am besten direkt an."]] },

  { slug: "thermografie", icon: "thermo", title: "Bau-Thermografie", short: "Wärmebrücken, Dämmlücken und Hinweise auf Feuchte sichtbar machen, zerstörungsfrei und fachlich ausgewertet.",
    foto: "Foto: Wärmebild einer Hausfassade",
    lead: "Eine Wärmebildkamera macht sichtbar, was das Auge nicht sieht: Wärmebrücken, fehlende Dämmung, undichte Fenster und versteckte Feuchte.",
    anlaesse: ["Vor dem Hauskauf", "Hohe Heizkosten", "Schimmel in Raumecken", "Kontrolle eines Neubaus", "Planung einer Sanierung"],
    vorgehen: [["Termin planen", "In der Heizperiode, idealerweise früh am Morgen."], ["Aufnahmen", "Wärmebilder von außen und innen."], ["Auswertung", "Ich ordne die Auffälligkeiten ein und unterscheide echte Mängel von Messeffekten."], ["Bericht", "Sie erhalten die Wärmebilder mit Erklärung."]],
    ergebnis: [["i-photo", "Wärmebilder", "Mit verständlicher Erläuterung, was zu erkennen ist."], ["i-shield", "Fachliche Einordnung", "Welche Ursachen infrage kommen und wo sich eine genauere Prüfung lohnt."], ["i-doc", "Entscheidungsgrundlage", "Welche Maßnahmen für Ihr Gebäude sinnvoll sind."]],
    faq: [["Wann ist die beste Zeit für eine Thermografie?", "Etwa von November bis März, wenn es draußen deutlich kälter ist als drinnen, am besten vor Sonnenaufgang."], ["Wie lange dauert die Aufnahme?", "Bei einem Einfamilienhaus meist 1 bis 2 Stunden."], ["Was kostet eine Thermografie?", "Das hängt von Größe und Umfang ab, etwa ob nur außen oder auch innen aufgenommen wird. Den Preis nenne ich Ihnen vorab."]] }
];

/* Zusatzinhalte je Leistung: Einleitung, Prüfpunkte, Kosten, Eckdaten */
const MEHR = {
  gebaeudeschaeden: {
    intro: ["Ein Riss in der Fassade, ein muffiger Keller oder dunkle Flecken in der Zimmerecke: Gebäudeschäden haben fast immer eine Ursache, die nicht sofort sichtbar ist. Wer nur die Oberfläche behandelt, steht oft ein Jahr später wieder vor demselben Problem.", "Als zertifizierter Sachverständiger für Schäden an Gebäuden untersuche ich den Schaden vor Ort, messe Feuchte und Temperaturen und werte die Ergebnisse aus. Sie erfahren, woher der Schaden kommt, wie dringend er ist und welche Sanierung wirklich hilft."],
    pruefe: [["Feuchte im Mauerwerk", "Aufsteigende Feuchte, Kondensat oder eindringendes Wasser"], ["Schimmel", "Ausmaß und Ursache, ob Bauteil oder Lüftung"], ["Risse", "Setzung, Spannungen oder Ausführungsfehler"], ["Abdichtung", "Keller, Sockel, Balkon und Flachdach"], ["Wärmebrücken", "Kalte Stellen, an denen sich Feuchte bildet"], ["Folgeschäden", "Was passiert, wenn nichts getan wird"]],
    kosten: "Die Kosten richten sich nach Art und Umfang des Schadens. Eine Einschätzung vor Ort ist weniger aufwendig als ein ausführliches Gutachten. Nach unserem ersten Gespräch nenne ich Ihnen einen Preis oder einen klaren Kostenrahmen.",
    eck: ["Ortstermin ca. 1–3 Std.", "Einschätzung, Bericht oder Gutachten"] },
  hauskaufberatung: {
    intro: ["Ein Hauskauf ist für die meisten die größte Investition ihres Lebens. Bei einer normalen Besichtigung bleiben viele Mängel unentdeckt, weil sie hinter frischer Farbe, Möbeln oder Verkleidungen liegen. Nach dem Notartermin tragen Sie das Risiko meist allein.", "Ich begleite Sie zur Besichtigung und sehe mir das Haus mit dem Blick eines Baumeisters an. Sie erfahren, welche Mängel es gibt, was in den nächsten Jahren auf Sie zukommt und welche Argumente Sie für die Preisverhandlung haben."],
    pruefe: [["Dach und Dachstuhl", "Eindeckung, Holz, Dämmung und Anschlüsse"], ["Fassade und Mauerwerk", "Risse, Fugen, Feuchte und Putzschäden"], ["Keller und Abdichtung", "Feuchte, Salze und Zustand der Abdichtung"], ["Fenster und Türen", "Alter, Anschlüsse und Dichtigkeit"], ["Feuchte und Schimmel", "Auffälligkeiten, bei Bedarf mit Messung überprüft"], ["Umbauten und Modernisierung", "Was erneuert wurde und wo Sanierungsbedarf besteht"]],
    kosten: "Der Preis richtet sich nach Art, Größe und Zustand der Immobilie und nach dem gewünschten Umfang der Dokumentation. Ich nenne Ihnen den Preis vorab.",
    eck: ["Begehung ca. 1,5–3 Std.", "Mängelliste mit Kostenschätzung"] },
  gutachten: {
    intro: ["Ob Versicherung, Bauträger oder Handwerker: Wenn es um Geld und Verantwortung geht, zählen belastbare Fakten. Ein Gutachten hält fest, was vorgefunden wurde, wodurch der Schaden entstanden ist und wie er technisch zu bewerten ist.", "Ich erstelle Kurzgutachten für schnelle Entscheidungen und ausführliche Gutachten, wenn ein Streit droht. Jede Aussage ist mit Fotos und Messwerten belegt und so geschrieben, dass auch Laien sie verstehen."],
    pruefe: [["Ortsbesichtigung", "Aufnahme des Befunds mit Fotos und Messungen"], ["Ursachenanalyse", "Bewertung nach den anerkannten Regeln der Technik"], ["Sanierungsempfehlung", "Wie der Schaden fachgerecht behoben wird"], ["Kostenschätzung", "Ein Rahmen für die Beseitigung"], ["Fotodokumentation", "Nachvollziehbar auch für Dritte"], ["Erläuterung", "Persönliche Besprechung des Ergebnisses"]],
    kosten: "Gutachten werden nach Aufwand abgerechnet. Den voraussichtlichen Umfang bespreche ich vorher mit Ihnen, damit es keine Überraschungen gibt.",
    eck: ["Umfang nach Absprache", "Kurzgutachten oder Gutachten"] },
  bauueberwachung: {
    intro: ["Beim Bauen entstehen die teuersten Mängel oft dort, wo man sie später nicht mehr sieht: in der Abdichtung, in der Dämmung oder an Anschlüssen. Sind diese Bauteile erst verputzt, wird jede Nachbesserung aufwendig und teuer.", "Ich kontrolliere Ihr Bauvorhaben in den entscheidenden Phasen und dokumentiere jeden Termin. Auf Wunsch übernehme ich die Bauleitung und koordiniere Gewerke und Termine, als Maurer- und Stahlbetonbauermeister mit eigener Praxis in der Bauleitung."],
    pruefe: [["Erdbau und Abdichtung", "Bevor Bauteile im Erdreich verschwinden"], ["Rohbau", "Mauerwerk, Beton, Stürze und Maße"], ["Anschlüsse", "Schnittstellen zwischen den Gewerken"], ["Fenster und Dach", "Einbau, Abdichtung und Luftdichtheit"], ["Dämmung", "Vollständig und lückenlos vor dem Verschließen"], ["Abnahme", "Erkennbare Mängel und ausstehende Arbeiten"]],
    kosten: "Abgerechnet wird je Kontrolltermin oder als Paket für das gesamte Bauvorhaben, je nach vereinbartem Leistungsumfang.",
    eck: ["je Termin ca. 1–2 Std.", "Protokoll nach jedem Termin"] },
  schlichtung: {
    intro: ["Wenn Bauherr und Handwerker sich über Mängel streiten, stehen schnell Rechnungen, Fristen und Anwälte im Raum. Ein Prozess dauert oft Jahre und kostet beide Seiten viel Geld und Nerven.", "Als unabhängiger Sachverständiger bewerte ich die strittigen Punkte technisch und neutral. Beide Seiten bekommen eine klare Einschätzung, auf deren Grundlage sie sich einigen können."],
    pruefe: [["Vereinbarte Leistung", "Was technisch geschuldet war"], ["Ausführung", "Was tatsächlich gebaut wurde"], ["Beanstandung", "Ob ein Mangel fachlich begründet ist und wie er wiegt"], ["Ursache", "Die technische Ursache des Problems"], ["Nachbesserung", "Technisch geeignete Lösungswege"], ["Umsetzung", "Kontrolle bei gesondert vereinbarten Folgeterminen"]],
    kosten: "In der Regel teilen sich beide Seiten die Kosten. Art und Umfang meiner Tätigkeit legen wir vorab gemeinsam und schriftlich fest, danach richtet sich auch der Preis.",
    eck: ["Gemeinsamer Ortstermin", "Neutrale Stellungnahme"] },
  energieberatung: {
    intro: ["Steigende Energiepreise und neue Vorgaben machen die energetische Sanierung für viele Hausbesitzer zum Thema. Doch welche Maßnahme lohnt sich zuerst, und in welcher Reihenfolge?", "Ich untersuche die Gebäudehülle, finde die größten Schwachstellen und zeige Ihnen einen sinnvollen Weg. So investieren Sie nicht in die falsche Maßnahme."],
    pruefe: [["Dach und oberste Decke", "Oft der größte Wärmeverlust"], ["Außenwände", "Aufbau, Dämmung und Feuchte"], ["Fenster und Türen", "Dichtigkeit und Anschlüsse"], ["Keller und Bodenplatte", "Wärmeverlust nach unten"], ["Wärmebrücken", "Sichtbar gemacht mit Thermografie"], ["Heizung", "Grobe Einschätzung der Anlagentechnik"]],
    kosten: "Der Preis hängt von Größe des Gebäudes und Umfang der Beratung ab, zum Beispiel ob ein Energieausweis oder ein iSFP dazugehört.",
    eck: ["Vor-Ort-Termin ca. 2 Std.", "Maßnahmenplan"] },
  leckageortung: {
    intro: ["Ein Wasserfleck an der Decke, ein feuchter Boden oder ein Wasserzähler, der ständig läuft: Undichte Leitungen richten oft lange unbemerkt Schaden an. Je früher die Stelle gefunden wird, desto kleiner bleibt der Schaden.", "Ich grenze die Leckage mit Messtechnik ein, damit nur dort geöffnet wird, wo es nötig ist. Den Befund dokumentiere ich so, dass Sie ihn direkt bei Ihrer Versicherung einreichen können."],
    pruefe: [["Trinkwasserleitungen", "Kalt- und Warmwasser"], ["Heizungsleitungen", "Bei Druckverlust in der Anlage"], ["Fußbodenheizung", "Verlauf und undichte Stellen"], ["Abwasser", "Undichte Rohre und Anschlüsse"], ["Dusche und Bad", "Fugen, Abdichtung und Abläufe"], ["Flachdach und Terrasse", "Eindringendes Wasser von oben"]],
    kosten: "Der Preis richtet sich nach Aufwand und eingesetzten Messverfahren. In vielen Fällen übernimmt die Leitungswasserversicherung die Kosten für die Suche.",
    eck: ["je nach Fall ca. 1–4 Std.", "Markierte Stelle und Bericht"] },
  thermografie: {
    intro: ["Wärme sucht sich ihren Weg nach draußen, und eine Wärmebildkamera macht diesen Weg sichtbar. Fehlende Dämmung, undichte Fenster oder Wärmebrücken werden auf einen Blick erkennbar.", "Ich erstelle die Aufnahmen bei passenden Bedingungen und werte sie fachlich aus. Denn nicht jede auffällige Farbe im Wärmebild ist ein Mangel. Entscheidend ist die richtige Deutung."],
    pruefe: [["Fassade und Dach", "Dämmlücken und Wärmeverluste"], ["Fenster und Rollladenkästen", "Typische Schwachstellen im Bestand"], ["Wärmebrücken", "Ecken, Stürze, Balkone und Sockel"], ["Feuchte", "Durchfeuchtete Bauteile"], ["Fußbodenheizung", "Verlauf der Heizrohre"], ["Undichtigkeiten", "Wo kalte Luft eindringt"]],
    kosten: "Der Preis hängt davon ab, ob nur außen oder auch innen aufgenommen wird und wie groß das Gebäude ist.",
    eck: ["Aufnahme ca. 1–2 Std.", "Wärmebilder mit Auswertung"] }
};

/* Gegliederte Texte für einzelne Leistungen (Andrés Fassung) */
MEHR.gebaeudeschaeden.sections = [
  ["Schäden an Gebäuden – Ursachen klären, Lösungen entwickeln", ["Risse im Mauerwerk, Feuchtigkeit, Setzungen oder Korrosion können unterschiedliche Ursachen haben. Auch Undichtigkeiten an der Gebäudehülle und Ausführungsmängel können die Funktion und den Zustand eines Gebäudes beeinträchtigen. Für Eigentümer stellt sich dann die Frage: Wie schwerwiegend ist der Schaden, besteht Handlungsbedarf und welche Maßnahmen sind sinnvoll?", "Als Sachverständiger für Schäden an Gebäuden untersuche ich Schäden und Mängel systematisch, dokumentiere die Befunde und bewerte sie anhand der anerkannten Regeln der Technik. Dabei gehe ich den Ursachen auf den Grund und ordne Ausmaß sowie Dringlichkeit ein. Sie erhalten eine nachvollziehbare Grundlage für Ihre weiteren Entscheidungen."]],
  ["Individuelle Sanierungskonzepte – technisch fundiert und wirtschaftlich sinnvoll", ["Auf Grundlage der Untersuchung entwickle ich ein auf Ihren Schadensfall abgestimmtes Sanierungskonzept. Dabei berücksichtige ich die technischen Anforderungen, die Wirtschaftlichkeit und die Dauerhaftigkeit der vorgesehenen Maßnahmen.", "Das Konzept beschreibt, welche Arbeiten erforderlich sind, in welcher Reihenfolge sie erfolgen sollten und worauf bei der fachgerechten Umsetzung zu achten ist. Eine darauf abgestimmte Kostenschätzung unterstützt Sie bei der finanziellen Planung."]],
  ["Auf Wunsch: Begleitung der Sanierung", ["Auch bei der Umsetzung des Sanierungskonzepts stehe ich Ihnen zur Seite. Im Rahmen der vereinbarten Bauüberwachung prüfe ich die Ausführung auf Übereinstimmung mit der Planung und den anerkannten Regeln der Technik. So lassen sich Abweichungen frühzeitig erkennen und fachgerecht korrigieren."]]
];
MEHR.gebaeudeschaeden.eck = ["Ortstermin ca. 1–3 Std.", "Einschätzung, Bericht oder Gutachten. Optional: Sanierungskonzept und Begleitung der Sanierung"];
MEHR.hauskaufberatung.sections = [
  ["Haus- und Wohnungskaufberatung vom Sachverständigen", ["Ob bestehendes Haus, Eigentumswohnung oder Neubau: Wer eine Immobilie kauft oder bauen lässt, übernimmt langfristige Verantwortung, häufig mit einer Finanzierung über Jahrzehnte. Eine unabhängige fachliche Einschätzung hilft Ihnen, Risiken frühzeitig zu erkennen und mögliche Folgekosten besser einzuschätzen.", "Als Sachverständiger mit langjähriger Baupraxis begleite ich Sie zur Besichtigung und beurteile den erkennbaren baulichen Zustand. Ich erläutere Ihnen festgestellte Mängel, möglichen Sanierungsbedarf und deren Bedeutung für Ihre Kaufentscheidung. So wissen Sie, worauf Sie achten sollten, und erhalten sachliche Argumente für die Preisverhandlung."]],
  ["Begleitung beim Neubau", ["Auch während der Bauphase sowie bei Teilabnahmen und der abschließenden Bauabnahme stehe ich Ihnen fachkundig zur Seite. Sie erhalten verständliche Antworten und klare Empfehlungen für die nächsten Schritte, damit Sie Ihre Entscheidungen gut informiert und mit mehr Sicherheit treffen."]]
];
MEHR.hauskaufberatung.tagline = "Fachkundig begleitet. Fundiert entscheiden.";
MEHR.hauskaufberatung.eck = ["ca. 1,5–3 Std., abhängig von Größe und Zustand der Immobilie", "Übersichtliche Dokumentation der festgestellten Mängel mit fachlicher Einschätzung und Empfehlungen zum weiteren Vorgehen"];

/* Andrés Texte für die Leistungsseiten (Abschnitte: [Überschrift oder null, [Absatz | [Liste]]]) */
MEHR.gutachten.tagline = "Ursachen klären. Schäden bewerten. Entscheidungen absichern.";
MEHR.gutachten.sections = [
  [null, ["Risse im Mauerwerk, Feuchtigkeit im Keller oder Zweifel an der Bauausführung: Wer Auffälligkeiten an einem Gebäude feststellt, braucht klare Antworten. Was steckt dahinter? Wie schwerwiegend ist das Problem? Und besteht Handlungsbedarf?", "Als Sachverständiger für Schäden an Gebäuden untersuche ich Schäden und vermutete Baumängel, analysiere mögliche Ursachen und bewerte ihre bautechnische Bedeutung. Dabei verbinde ich fundiertes Fachwissen mit langjähriger Erfahrung aus Handwerk und Bauleitung. So entsteht ein unabhängiges Gutachten, das technische Zusammenhänge nachvollziehbar erklärt und Ihnen eine belastbare Grundlage für das weitere Vorgehen bietet."]],
  ["Genau untersuchen. Nachvollziehbar beurteilen.", ["Jedes Gutachten wird auf die konkrete Fragestellung abgestimmt. Ich erfasse den Zustand der betroffenen Bauteile, dokumentiere die Befunde und bewerte diese unter Berücksichtigung der maßgeblichen technischen Anforderungen und der anerkannten Regeln der Technik. Dabei unterscheide ich klar zwischen festgestellten Tatsachen, möglichen Ursachen und fachlichen Schlussfolgerungen.", "Je nach Auftrag und Untersuchungsumfang umfasst das Gutachten:", [
    "<b>Schadens- und Mängelerfassung:</b> Untersuchung und Dokumentation der betroffenen Bauteile",
    "<b>Ursachenanalyse:</b> Betrachtung von Konstruktion, Material, Ausführung und relevanten äußeren Einflüssen",
    "<b>Technische Bewertung:</b> Einordnung von Schadensumfang, möglichen Folgen und Handlungsbedarf",
    "<b>Nachvollziehbare Dokumentation:</b> verständliche Erläuterungen, ergänzt durch aussagekräftige Fotos und gegebenenfalls Messergebnisse",
    "<b>Empfehlungen zum weiteren Vorgehen:</b> erforderliche Maßnahmen oder weiterführende Untersuchungen",
    "<b>Optional:</b> ein auf den Befund abgestimmtes Sanierungskonzept nach gesonderter Vereinbarung"]]],
  ["Klarheit für Ihre nächsten Schritte", ["Ob zur Vorbereitung einer Sanierung, zur technischen Klärung bei unterschiedlichen Auffassungen über eine Bauleistung oder zur Unterstützung bei Versicherungsfragen und Immobilienkaufentscheidungen: Ein Baugutachten schafft eine sachliche Grundlage.", "Sie erfahren, was festgestellt wurde, wie der Befund fachlich einzuordnen ist und welche nächsten Schritte sinnvoll sind, unabhängig beurteilt und verständlich erläutert."]]
];

MEHR.bauueberwachung.tagline = "Qualität prüfen. Risiken frühzeitig erkennen.";
MEHR.bauueberwachung.sections = [
  [null, ["Ob Neubau, Umbau oder Modernisierung: Die Qualität eines Gebäudes entscheidet sich in der Ausführung. Fehlerhafte Abdichtungen, ungeeignete Materialien oder unzureichend abgestimmte Gewerke können Schäden verursachen, die erst nach der Fertigstellung sichtbar werden. Eine unabhängige fachliche Begleitung hilft, solche Schwachstellen rechtzeitig zu erkennen und notwendige Korrekturen anzustoßen.", "Als Sachverständiger für Schäden an Gebäuden verbinde ich langjährige Erfahrung aus Handwerk und Bauleitung mit einem geschulten Blick für schadensanfällige Details. Ich prüfe die Bauausführung zu vereinbarten Bauabschnitten, bewerte Auffälligkeiten und dokumentiere die Ergebnisse nachvollziehbar. Maßgeblich sind dabei die vereinbarte Beschaffenheit, die relevanten technischen Anforderungen und die anerkannten Regeln der Technik."]],
  ["Neubau: die entscheidenden Bauphasen im Blick", ["Vom Erdbau über den Rohbau bis zum Ausbau begleite ich die wesentlichen Bauabschnitte im vereinbarten Umfang. Besonderes Augenmerk gilt Bauteilen und Anschlüssen, die durch nachfolgende Arbeiten verdeckt werden und später nur mit erheblichem Aufwand überprüft oder nachgebessert werden können.", "Die Kontrolltermine werden auf den Baufortschritt abgestimmt. So lassen sich Abweichungen frühzeitig feststellen, fachlich einordnen und mit den verantwortlichen Beteiligten klären."]],
  ["Umbau und Modernisierung: Bestand und neue Bauleistung zusammen betrachten", ["Beim Bauen im Bestand müssen neue Maßnahmen zur vorhandenen Bausubstanz passen. Gerade an Anschlüssen, Übergängen und bei Änderungen bestehender Konstruktionen ist eine sorgfältige Beurteilung erforderlich.", "Ich prüfe die erkennbaren baulichen Gegebenheiten und die Ausführung der vereinbarten Maßnahmen. Dabei berücksichtige ich insbesondere Risiken durch Feuchtigkeit, Wärmebrücken und das Zusammenwirken alter und neuer Bauteile. Werden zusätzliche Fachplanungen oder Untersuchungen erforderlich, weise ich darauf hin."]],
  ["Abnahmebegleitung: genau hinsehen, bevor Leistungen abgenommen werden", ["Ob Rohbauabnahme, Abnahme einzelner Bauabschnitte oder Fertigstellungs- und Schlussabnahme: Ich unterstütze Sie bei der fachlichen Prüfung der ausgeführten Leistungen. Dabei erfasse ich erkennbare Mängel und noch ausstehende Arbeiten, erläutere deren Bedeutung und unterstütze Sie bei der nachvollziehbaren Aufnahme in das Abnahmeprotokoll.", "Auch vor dem Verdecken wichtiger Bauteile sind rechtzeitige Zustandskontrollen sinnvoll. Bei vereinbarten Folgeterminen prüfe ich zudem die Umsetzung erforderlicher Nachbesserungen.", "So lassen sich offene Punkte frühzeitig dokumentieren und klären, um späteren Überraschungen, vermeidbaren Folgekosten und Auseinandersetzungen vorzubeugen."]],
  ["Bauherrenbegleitung: fachlich unabhängig, persönlich an Ihrer Seite", ["Ich helfe Ihnen, technische Fragen zu klären und Entscheidungen fundiert zu treffen, unabhängig von ausführenden Unternehmen und Planern. Meine Bewertungen bleiben sachlich und fachlich begründet.", "Je nach vereinbartem Leistungsumfang umfasst meine Begleitung:", [
    "Prüfung von Baubeschreibungen, Angeboten und relevanten Planungsunterlagen auf technische Unklarheiten und erkennbare Widersprüche",
    "Baustellenbegehungen zur Kontrolle der zugänglichen Bauleistungen und eingesetzten Materialien",
    "Prüfung schadensanfälliger Ausführungsdetails und Schnittstellen zwischen den Gewerken",
    "Dokumentation von Auffälligkeiten mit Fotos und verständlicher fachlicher Einordnung",
    "Besprechung erforderlicher Korrekturen und Kontrolle ihrer Umsetzung bei vereinbarten Folgeterminen",
    "Begleitung wichtiger Baustellentermine und fachliche Unterstützung bei Abnahmen"],
    "Art, Umfang und Häufigkeit der Kontrollen stimmen wir auf Ihr Bauvorhaben ab. Die baubegleitende Qualitätskontrolle erfolgt durch gezielte Begehungen; eine umfassende Bauleitung oder Objektüberwachung wird gesondert vereinbart."]],
  ["Eine klare Grundlage für Ihre Entscheidungen", ["Sie erfahren, wie die kontrollierten Bauleistungen fachlich einzuschätzen sind, wo Handlungsbedarf besteht und welche nächsten Schritte sinnvoll sind. Das schafft Transparenz, unterstützt die Qualitätssicherung und hilft, vermeidbare Folgekosten zu reduzieren.", "<b>Mein Anspruch:</b> Ausführungsfehler frühzeitig erkennen, technische Zusammenhänge verständlich machen und Sie mit praktischer Erfahrung durch Ihr Bauvorhaben begleiten."]]
];

MEHR.schlichtung.tagline = "Sachverhalte klären. Lösungen ermöglichen.";
MEHR.schlichtung.quote = ["Kommst du mit deinem Nächsten in Uneinigkeit, vergleiche dich mit ihm in der Billigkeit. Kannst du dich mit ihm allein vertragen, so wirst du dir und anderen viel Mühe ersparen.", "Inschrift auf der Wappentafel der münsterschen Gesamtgilde, 1598 · Stadtarchiv Münster"];
MEHR.schlichtung.sections = [
  [null, ["Ob Uneinigkeit über die Ausführungsqualität, strittige Baumängel oder unterschiedliche Auffassungen zu Schadensursachen: Wenn Bauprojekte zum Konflikt werden, braucht es eine sachliche Grundlage und einen unabhängigen Blick.", "Als Sachverständiger für Schäden an Gebäuden unterstütze ich die Beteiligten dabei, technische Streitfragen zu klären und nachvollziehbare Lösungswege zu entwickeln. Dafür verbinde ich fundiertes Fachwissen mit langjähriger Erfahrung aus Handwerk und Bauleitung."]],
  ["Unabhängig prüfen. Sachlich vermitteln.", ["Im Mittelpunkt stehen die bautechnischen Tatsachen. Ich untersuche die betroffenen Bauteile, dokumentiere die Feststellungen und bewerte, ob die beanstandete Ausführung fachlich begründet zu bemängeln ist. Ursachen, Auswirkungen und mögliche Maßnahmen werden nachvollziehbar eingeordnet.", "Wenn die Beteiligten eine gemeinsame Klärung wünschen, erläutere ich die Ergebnisse in einem moderierten Gespräch. Ziel ist es, unterschiedliche Standpunkte auf eine überprüfbare fachliche Grundlage zurückzuführen und Möglichkeiten für eine außergerichtliche Einigung aufzuzeigen.", "Je nach Fragestellung umfasst meine Unterstützung:", [
    "Erfassung der strittigen Punkte und Sichtung relevanter Bauunterlagen",
    "Gemeinsame Ortsbesichtigung und Dokumentation des baulichen Zustands",
    "Fachliche Bewertung beanstandeter Leistungen und möglicher Schadensursachen",
    "Erläuterung der Befunde gegenüber den Beteiligten",
    "Entwicklung technisch geeigneter Lösungs- und Nachbesserungsvorschläge",
    "Schriftliche Dokumentation der technischen Ergebnisse und vereinbarten Maßnahmen",
    "Kontrolle der Umsetzung bei gesondert vereinbarten Folgeterminen"],
    "Meine Tätigkeit dient der technischen Klärung und sachverständigen Vermittlung. Eine rechtliche Beratung oder verbindliche Entscheidung über Ansprüche ist damit nicht verbunden."]],
  ["Ergänzende Fachkompetenz bei Bedarf", ["Erfordert die Klärung zusätzliche Spezialkenntnisse, können nach Abstimmung geeignete Fachplaner oder weitere unabhängige Sachverständige aus meinem Netzwerk eingebunden werden. Für die Umsetzung notwendiger Maßnahmen können qualifizierte Handwerksbetriebe hinzugezogen werden.", "Die technische Bewertung bleibt dabei unabhängig von einer späteren Auftragsvergabe. Art und Umfang einer ergänzenden Koordination oder Umsetzungskontrolle werden gesondert vereinbart."]],
  ["Eine tragfähige Grundlage für die Einigung", ["Eine verständliche und fachlich begründete Bewertung hilft, Missverständnisse abzubauen, Streitpunkte einzugrenzen und das weitere Vorgehen zu konkretisieren. Sie kann dazu beitragen, langwierige Auseinandersetzungen und zusätzliche Kosten zu vermeiden.", "<b>Mein Anspruch:</b> technische Klarheit schaffen, den sachlichen Austausch fördern und Lösungen ermöglichen, die fachlich begründet und praktisch umsetzbar sind."]]
];

MEHR.energieberatung.tagline = "Gebäude verstehen. Sinnvoll modernisieren.";
MEHR.energieberatung.sections = [
  [null, ["Welche energetischen Maßnahmen lohnen sich für Ihre Immobilie? Ich untersuche den Gebäudezustand und zeige Ihnen, wie sich Energiebedarf und Wohnkomfort gezielt verbessern lassen, abgestimmt auf Ihre Ziele und Ihr Budget.", "<b>Mein Anspruch:</b> klare Empfehlungen und ein durchdachtes Konzept, das zu Ihrer Immobilie passt."]],
  ["Energieberatung", ["Bei einem Vor-Ort-Termin betrachte ich Gebäudehülle und Anlagentechnik und entwickle passende Verbesserungsvorschläge. Dabei berücksichtige ich Einsparpotenziale, Wirtschaftlichkeit und das Zusammenspiel von Wärmeschutz, Feuchteschutz, Lüftung und Heizung."]],
  ["Energieausweise", ["Ich erstelle Bedarfs- und Verbrauchsausweise entsprechend den Anforderungen Ihres Gebäudes. Welche Ausweisart infrage kommt und wie die Kennwerte einzuordnen sind, erläutere ich Ihnen verständlich."]],
  ["Fördermittelberatung", ["Ich unterstütze Sie dabei, passende Fördermöglichkeiten zu erkennen und frühzeitig in Ihre Sanierungsplanung einzubeziehen. Dabei berücksichtige ich die jeweiligen Voraussetzungen, Fristen und erforderlichen Nachweise."]],
  ["Individueller Sanierungsfahrplan (iSFP)", ["Der individuelle Sanierungsfahrplan (iSFP) zeigt, wie sich Ihr Wohngebäude energetisch weiterentwickeln lässt, in aufeinander abgestimmten Schritten oder im Rahmen einer umfassenden Sanierung.", "Ausgehend vom Gebäudezustand werden geeignete Maßnahmenpakete zusammengestellt und in eine sinnvolle Reihenfolge gebracht. Der Fahrplan erläutert deren voraussichtliche Auswirkungen auf Energiebedarf und Wohnkomfort sowie die zu erwartenden Investitionen und mögliche Förderungen.", "So können Sie einzelne Maßnahmen gezielt vorbereiten und spätere Sanierungsschritte bereits mitdenken. Zusätzliche Fördervorteile können sich ergeben, wenn die jeweiligen Programmvoraussetzungen erfüllt sind.", "<b>Mein Anspruch:</b> energetische Zusammenhänge verständlich machen und eine Sanierungsstrategie entwickeln, die zu Ihrem Gebäude, Ihren Zielen und Ihrem Budget passt."]]
];

MEHR.leckageortung.keepIntro = true;
MEHR.leckageortung.sections = [
  ["Leckageortung: die Ursache von Wasserschäden gezielt eingrenzen", ["Feuchte Wände, Wasserflecken an der Decke oder Druckverlust in der Heizung sind mögliche Hinweise auf eine Undichtigkeit. Wo Feuchtigkeit sichtbar wird, muss sie jedoch nicht eingetreten sein. Wasser kann sich entlang von Leitungen, in Bodenaufbauten oder hinter Verkleidungen ausbreiten und erst an anderer Stelle sichtbar werden."]],
  ["Wie ich bei der Leckageortung vorgehe", ["Vor Ort erfasse ich das Schadensbild und prüfe, welche Leitungen, Anschlüsse oder Bauteile als Ursache infrage kommen. Je nach Befund setze ich geeignete Messverfahren ein, um die Feuchtigkeitsverteilung zu erfassen und die mögliche Leckstelle einzugrenzen. Falls eine Öffnung erforderlich ist, kann sie auf den betroffenen Bereich beschränkt werden.", "Typische Einsatzbereiche sind:", [
    "Undichtigkeiten an Trinkwasser-, Abwasser- und Heizungsleitungen",
    "Leckagen an Rohrverbindungen und Anschlüssen",
    "Feuchtigkeit in Wänden, Decken und Bodenaufbauten",
    "Wassereintritt über schadhafte Abdichtungen, etwa im Bad oder am Flachdach"]]],
  ["Klarheit über die nächsten Schritte", ["Ich dokumentiere die Befunde und erläutere verständlich, wo die Schadensquelle liegt oder welche weiteren Prüfungen zur Klärung nötig sind. So lässt sich gezielt entscheiden, wo repariert werden muss und welche Bereiche auf Durchfeuchtung geprüft oder getrocknet werden sollten.", "Eine frühzeitige Leckageortung hilft, unnötige Bauteilöffnungen zu vermeiden und das Risiko von Folgeschäden zu begrenzen."]]
];

MEHR.thermografie.keepIntro = true;
MEHR.thermografie.sections = [
  ["Bau-Thermografie: energetische Schwachstellen sichtbar machen", ["Kalte Wandflächen, Zugluft oder ungleichmäßig beheizte Räume können auf Schwachstellen in der Gebäudehülle hinweisen. Mit einer Wärmebildkamera mache ich Temperaturunterschiede an den Oberflächen von Wänden, Decken und Bauteilanschlüssen sichtbar. So lassen sich verdächtige Bereiche gezielt eingrenzen, zerstörungsfrei und ohne Eingriff in die Bausubstanz."]],
  ["Wann ist Bau-Thermografie sinnvoll?", [[
    "Wärmebrücken erkennen, etwa an Fensteranschlüssen, Gebäudeecken oder Deckenrändern",
    "Auffälligkeiten in der Dämmung eingrenzen, beispielsweise an Außenwänden oder im Dachbereich",
    "Hinweise auf Luftundichtigkeiten oder Feuchtigkeit untersuchen und bei Bedarf durch weitere Messungen überprüfen",
    "Energetische Sanierungen vorbereiten und ausgeführte Maßnahmen gezielt überprüfen"]]],
  ["Vom Wärmebild zur fachlichen Einschätzung", ["Für aussagekräftige Aufnahmen müssen die Messbedingungen stimmen. Dazu gehört insbesondere ein ausreichender Temperaturunterschied zwischen innen und außen. Bei der Auswertung berücksichtige ich die Bauweise, die Nutzung des Gebäudes und die Bedingungen zum Zeitpunkt der Messung.", "Ich erläutere Ihnen, was auf den Wärmebildern zu erkennen ist, welche Ursachen infrage kommen und wo sich eine genauere Prüfung lohnt. So können Sie gezielt entscheiden, welche Maßnahmen für Ihr Gebäude sinnvoll sind."]]
];

MEHR.gebaeudeschaeden.tagline = "Ursachen klären. Lösungen entwickeln.";
MEHR.leckageortung.tagline = "Undichtigkeiten eingrenzen. Folgeschäden begrenzen.";
MEHR.thermografie.tagline = "Schwachstellen sichtbar machen. Gezielt entscheiden.";

/* Suchmaschinen: Seitentitel, Beschreibung und Überschrift je Seite (in WordPress im SEO-Plugin gepflegt) */
const SEO = {
  start: ["Bausachverständiger in Borken | Münsterland & Ruhrgebiet", "TÜV-zertifizierter Bausachverständiger aus Borken für Münsterland und Ruhrgebiet: Gutachten bei Bauschäden, Haus- und Wohnungskaufberatung, Baubegleitung."],
  leistungen: ["Leistungen | Bausachverständiger Münsterland & Ruhrgebiet", "Gebäudeschäden, Haus- und Wohnungskaufberatung, Baugutachten, Baubegleitung, Schlichtung, Energieberatung, Leckageortung und Thermografie."],
  "ueber-mich": ["André Niewerth – TÜV-zertifizierter Bausachverständiger", "Maurer- und Stahlbetonbauermeister und persCert-zertifizierter Sachverständiger für Schäden an Gebäuden. Ihr unabhängiger Gutachter im Münsterland."],
  kontakt: ["Kontakt | Bausachverständiger Münsterland & Ruhrgebiet", "Rufen Sie an unter 0179 6933684 oder senden Sie Ihre Anfrage. Kurzfristige Ortstermine im Münsterland und Ruhrgebiet."],
  impressum: ["Impressum | BSV Niewerth", "Impressum des Bau-Sachverständigenbüros BSV Niewerth, Borken."],
  datenschutz: ["Datenschutz | BSV Niewerth", "Datenschutzerklärung des Bau-Sachverständigenbüros BSV Niewerth, Borken."],
  gebaeudeschaeden: ["Gutachter für Bauschäden & Schimmel | Münsterland", "Risse, nasser Keller oder Schimmel? TÜV-zertifizierter Gutachter für Gebäudeschäden im Münsterland und Ruhrgebiet. Ursachen klären, Lösungen finden.", "Gebäude­schäden"],
  hauskaufberatung: ["Hauskaufberatung Borken & Münsterland | Gutachter", "Haus oder Eigentumswohnung, Bestand oder Neubau: Ein Bausachverständiger begleitet Ihre Besichtigung und beurteilt den baulichen Zustand vor dem Kauf.", "Haus- und Wohnungs­kauf­beratung"],
  gutachten: ["Baugutachten & Bauschadensgutachten | Münsterland", "Unabhängige Baugutachten im Münsterland und Ruhrgebiet: Ursachen klären, Schäden bewerten, Entscheidungen absichern. TÜV-zertifiziert.", "Gutachten­erstellung"],
  bauueberwachung: ["Baubegleitung Neubau NRW | Münsterland & Ruhrgebiet", "Unabhängige Baubegleitung für Neubau, Umbau und Modernisierung: Kontrolle der Bauabschnitte, Abnahmebegleitung und auf Wunsch Bauleitung.", "Bau­begleitung und Bau­überwachung"],
  schlichtung: ["Schlichtung bei Baustreit | Münsterland & Ruhrgebiet", "Streit über Baumängel? Ein unabhängiger Bausachverständiger klärt die technischen Fragen und zeigt Wege zu einer außergerichtlichen Einigung.", "Schlichtung bei Bau­streitigkeiten"],
  energieberatung: ["Energieberatung & iSFP | Münsterland & Ruhrgebiet", "Energieberatung, Energieausweise, Fördermittelberatung und individueller Sanierungsfahrplan (iSFP) für Ihr Wohngebäude.", "Energie­beratung für Ihr Haus"],
  leckageortung: ["Leckageortung & Wasserschaden | Münsterland & Ruhrgebiet", "Wasserfleck oder Druckverlust? Gezielte Leckageortung mit Bericht für die Versicherung. Kurzfristige Ortstermine.", "Leckage­ortung bei Wasser­schäden"],
  thermografie: ["Bau-Thermografie | Münsterland & Ruhrgebiet", "Wärmebilder zeigen Wärmebrücken, Dämmlücken und Hinweise auf Feuchte, zerstörungsfrei aufgenommen und fachlich ausgewertet.", "Bau-Thermo­grafie und Wärme­bilder"]
};

/* Einsatzgebiet: Karte rund um Borken (ungefähre Lage nach Koordinaten, Luftlinie) */
const ORTE_MS = [["Bocholt", 51.838, 6.615], ["Rhede", 51.836, 6.697], ["Raesfeld", 51.767, 6.844], ["Heiden", 51.826, 6.935], ["Reken", 51.795, 7.045], ["Velen", 51.894, 6.99], ["Gescher", 51.954, 7.006], ["Stadtlohn", 51.993, 6.917], ["Südlohn", 51.944, 6.864], ["Vreden", 52.035, 6.828], ["Ahaus", 52.076, 7.008], ["Legden", 52.032, 7.101], ["Gronau", 52.212, 7.025], ["Coesfeld", 51.946, 7.168], ["Dülmen", 51.831, 7.28], ["Münster", 51.962, 7.626], ["Isselburg", 51.832, 6.463]];
const ORTE_RUHR = [["Dorsten", 51.661, 6.965], ["Haltern am See", 51.743, 7.184], ["Marl", 51.656, 7.09], ["Gladbeck", 51.571, 6.987], ["Bottrop", 51.524, 6.929], ["Gelsenkirchen", 51.517, 7.1], ["Recklinghausen", 51.614, 7.198], ["Oberhausen", 51.47, 6.852], ["Essen", 51.455, 7.012], ["Bochum", 51.482, 7.216], ["Wesel", 51.658, 6.618], ["Hamminkeln", 51.73, 6.59]];
const LABEL = { Bocholt: "b", Ahaus: "r", Gronau: "r", Coesfeld: "r", "Münster": "l", Dorsten: "l", "Haltern am See": "r", Bottrop: "l", Gelsenkirchen: "r", Essen: "r", Recklinghausen: "r", Wesel: "l", Stadtlohn: "l", "Dülmen": "r" };
(function () {
  const map = $id("map"); if (!map) return;
  const B = [51.844, 6.858], kx = 68.9, ky = 111.2;
  const pos = ([, la, lo]) => [(lo - B[1]) * kx, -(la - B[0]) * ky];
  let h = `<circle class="m-ring" pathLength="1" r="60" style="--d:.1s"/><circle class="m-ring" pathLength="1" r="40" style="--d:.25s"/><circle class="m-ring" pathLength="1" r="20" style="--d:.4s"/>`;
  h += [20, 40, 60].map(r => { const c = (-r * .707 - 1).toFixed(1); return `<text class="m-km" x="${c}" y="${c}" transform="rotate(-45 ${c} ${c})">${r} km</text>`; }).join("");
  h += `<text class="m-reg" x="36" y="-50">MÜNSTERLAND</text><text class="m-reg" x="-34" y="58">RUHRGEBIET</text>`;
  const dot = (o, cls, i) => { const [x, y] = pos(o), side = LABEL[o[0]];
    return `<g class="m-dot ${cls}" style="--i:${i}"><circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${side ? 1.6 : 1.1}"/>${side ? `<text x="${(x + (side === "r" ? 2.8 : side === "l" ? -2.8 : 0)).toFixed(1)}" y="${(y + (side === "b" ? 4.6 : 1.1)).toFixed(1)}" text-anchor="${side === "r" ? "start" : side === "l" ? "end" : "middle"}">${o[0]}</text>` : ""}</g>`; };
  h += ORTE_MS.map((o, i) => dot(o, "ms", i)).join("") + ORTE_RUHR.map((o, i) => dot(o, "ruhr", i + ORTE_MS.length)).join("");
  h += `<g class="m-home"><circle class="m-pulse" r="4"/><circle r="2.6"/><text x="0" y="-5" text-anchor="middle">Borken</text></g>`;
  map.innerHTML = h;
  $id("list-ms").innerHTML = ["Borken", ...ORTE_MS.map(o => o[0])].map(t => `<li>${t}</li>`).join("");
  $id("list-ruhr").innerHTML = ORTE_RUHR.map(o => `<li>${o[0]}</li>`).join("");
})();
const TOWNS = ["Borken", ...ORTE_MS.map(o => o[0]), ...ORTE_RUHR.map(o => o[0])];
const PIN = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-7-6.2-7-11.5A7 7 0 0119 9.5C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/></svg>';

/* ---------- Regionen: eigene Seiten mit regionalem Bezug (keine austauschbaren Städte-Seiten) ---------- */
const REGIONEN = [
  { slug: "bausachverstaendiger-borken", name: "Borken",
    seo: ["Bausachverständiger Borken | Kreis Borken & Westmünsterland", "TÜV-zertifizierter Bausachverständiger mit Sitz in Borken: Bauschäden, Feuchte und Schimmel, Hauskaufberatung und Baubegleitung im ganzen Kreis Borken."],
    h1: "Bausachverständiger in Borken und im Kreis Borken",
    tag: "Mein Büro ist in Borken. Kurze Wege zu Ihnen.",
    lead: "Ob Bocholt, Ahaus, Gronau oder Reken: Im Kreis Borken bin ich schnell vor Ort. Ich untersuche Bauschäden, begleite Hauskäufe und prüfe Neubauten, unabhängig und mit moderner Messtechnik.",
    secs: [
      ["Vor Ort im Westmünsterland", ["Mein Büro liegt in der Propst-Pricking-Straße in Borken. Von hier aus erreiche ich die Städte und Gemeinden im Kreis Borken meist in kurzer Zeit. Das macht kurzfristige Ortstermine möglich, auch wenn ein Schaden schnell beurteilt werden muss.", "Als Maurer- und Stahlbetonbauermeister mit langjähriger Praxis als Bauleiter kenne ich die Bauweisen, die hier im Münsterland üblich sind. Das hilft, Schäden richtig einzuordnen und realistische Lösungen vorzuschlagen."]],
      ["Was im Kreis Borken häufig Thema ist", ["Viele Häuser im Westmünsterland haben eine Fassade aus Klinker, oft als zweischaliges Mauerwerk mit Luftschicht oder Dämmung dahinter. Das ist robust, aber nicht unverwundbar: Feuchte in der Vormauerschale, Ausblühungen, schadhafte Fugen oder verstopfte Entwässerungsöffnungen sind typische Themen.", "Dazu kommen Siedlungs- und Einfamilienhäuser aus den 1950er bis 1980er Jahren. Hier geht es oft um feuchte Keller, Wärmebrücken mit Schimmel oder die Frage, was eine Sanierung vor dem Kauf wirklich kostet.", "Und natürlich umgebaute Hofstellen und Kotten. Bei alten Gebäuden mit neuer Nutzung lohnt sich ein genauer Blick auf Feuchte, Holz und Anschlüsse."]]
    ],
    orte: ["Borken mit Gemen, Weseke, Burlo und Marbeck", "Bocholt", "Rhede", "Isselburg", "Raesfeld", "Heiden", "Reken", "Velen", "Gescher", "Stadtlohn", "Südlohn", "Vreden", "Ahaus", "Legden", "Heek", "Schöppingen", "Gronau"],
    faq: [["Kommen Sie auch nach Bocholt, Ahaus oder Gronau?", "Ja. Ich bin im ganzen Kreis Borken unterwegs und darüber hinaus im Münsterland und im nördlichen Ruhrgebiet."], ["Wie schnell ist ein Ortstermin möglich?", "In der Regel kurzfristig. Den Termin stimmen wir direkt am Telefon miteinander ab."], ["Fallen Anfahrtskosten an?", "Das hängt vom Ort und vom Auftrag ab. Ich nenne Ihnen die Kosten vorab, damit Sie nicht überrascht werden."], ["Kann ich vorab Fotos schicken?", "Gerne. Fotos helfen mir bei der ersten Einschätzung und bei der Vorbereitung des Ortstermins."]] },
  { slug: "bausachverstaendiger-muensterland", name: "Münsterland",
    seo: ["Baugutachter Münsterland | Bausachverständiger aus Borken", "Bausachverständiger für das Münsterland: Gutachten bei Bauschäden, Feuchte und Schimmel, Hauskaufberatung und Baubegleitung von Coesfeld bis Münster."],
    h1: "Baugutachter und Bausachverständiger im Münsterland",
    tag: "Von Borken aus im ganzen Münsterland unterwegs.",
    lead: "Coesfeld, Dülmen, Gescher oder Münster: Ich komme zu Ihnen, untersuche den Schaden vor Ort und erkläre Ihnen verständlich, was dahintersteckt und was jetzt sinnvoll ist.",
    secs: [
      ["Bauen im Münsterland", ["Das Münsterland ist geprägt von Klinker, Backstein und soliden Einfamilienhäusern. In den Ortskernen stehen Fachwerk- und Backsteinhäuser, auf dem Land Hofanlagen, die oft mehrfach umgebaut wurden. Jede dieser Bauweisen hat ihre eigenen Schwachstellen.", "Häufig geht es um Feuchte: im Keller, in der Außenwand oder an den Anschlüssen von Fenstern und Dächern. Bei älteren Häusern kommen Wärmebrücken und Schimmel dazu, bei Neubauten Ausführungsfehler, die man früh erkennen sollte."]],
      ["Hauskauf im Münsterland", ["Wer im Münsterland ein gebrauchtes Haus kauft, kauft oft ein Haus aus den 1960er bis 1990er Jahren. Der Zustand von Dach, Keller, Fenstern und Heizung entscheidet, was nach dem Kauf noch auf Sie zukommt. Bei der Besichtigung zeige ich Ihnen, worauf es ankommt, und schätze den Sanierungsbedarf ein."]],
      ["Unabhängig und nachvollziehbar", ["Ich bin persCert-zertifizierter Sachverständiger für Schäden an Gebäuden (TÜV Rheinland) und arbeite unabhängig von Baufirmen, Maklern und Handwerkern. Meine Befunde dokumentiere ich mit Fotos und Messwerten, damit Sie und alle Beteiligten sie nachvollziehen können."]]
    ],
    orte: ["Kreis Borken", "Coesfeld", "Dülmen", "Billerbeck", "Nottuln", "Lüdinghausen", "Gescher", "Münster", "Gronau", "Ahaus"],
    faq: [["Fahren Sie auch nach Münster?", "Ja. Münster und der Kreis Coesfeld gehören zu meinem Einsatzgebiet. Rufen Sie an, dann stimmen wir einen Termin ab."], ["Woran erkenne ich einen qualifizierten Bausachverständigen?", "Die Bezeichnung Bausachverständiger ist nicht geschützt. Achten Sie auf eine nachgewiesene Qualifikation. Meine Zertifizierung bei persCert TÜV Rheinland setzt eine geprüfte Fachkunde voraus, ist befristet und muss regelmäßig erneuert werden. Sie können sie online beim TÜV prüfen."], ["Wie läuft eine Hauskaufberatung ab?", "Wir besichtigen die Immobilie gemeinsam vom Keller bis zum Dach. Ich erkläre Ihnen vor Ort, was ich sehe, und fasse die Ergebnisse anschließend zusammen."]] },
  { slug: "bausachverstaendiger-ruhrgebiet", name: "Ruhrgebiet",
    seo: ["Bausachverständiger Ruhrgebiet | Dorsten, Bottrop, Essen", "Bausachverständiger für das nördliche Ruhrgebiet: Risse, Feuchte und Schimmel, Hauskaufberatung und Baubegleitung. Von Dorsten und Bottrop bis Essen."],
    h1: "Bausachverständiger im Ruhrgebiet",
    tag: "Vom Westmünsterland schnell im nördlichen Ruhrgebiet.",
    lead: "Dorsten, Gladbeck, Bottrop, Gelsenkirchen oder Essen: Ich untersuche Schäden an Wohngebäuden, begleite Hauskäufe und prüfe Bauvorhaben, unabhängig und verständlich erklärt.",
    secs: [
      ["Typische Gebäude im Revier", ["Im Ruhrgebiet stehen viele Zechen- und Arbeitersiedlungen, Mehrfamilienhäuser aus der Nachkriegszeit und Reihenhäuser aus den 1950er bis 1970er Jahren. Viele davon wurden über die Jahre mehrfach umgebaut und modernisiert, nicht immer fachgerecht.", "Häufige Themen sind feuchte Keller und Wände, Schimmel nach einem Fenstertausch ohne passendes Lüftungskonzept, Risse im Mauerwerk und Schäden an alten Leitungen."]],
      ["Risse und Schieflagen: auch an Bergbaufolgen denken", ["In Teilen des Ruhrgebiets hat der Bergbau den Untergrund verändert. Risse im Mauerwerk oder Türen, die plötzlich klemmen, können viele Ursachen haben, vom Schwinden der Baustoffe über Setzungen bis zu Bodenbewegungen.", "Ich dokumentiere Risse und Verformungen nachvollziehbar, beobachte ihre Entwicklung und ordne ein, welche Ursachen in Frage kommen. Für die Regulierung möglicher Bergschäden sind die Bergbauunternehmen zuständig, bei Streit gibt es in NRW die Schlichtungsstelle Bergschaden. Eine saubere Dokumentation ist dafür eine gute Grundlage."]],
      ["Kurze Wege über die A31", ["Über die A31 ist das nördliche Ruhrgebiet von Borken aus gut erreichbar. Dorsten, Gladbeck und Bottrop liegen nah, Gelsenkirchen, Oberhausen und Essen sind ebenfalls gut zu erreichen."]]
    ],
    orte: ["Dorsten", "Haltern am See", "Marl", "Gladbeck", "Bottrop", "Gelsenkirchen", "Recklinghausen", "Oberhausen", "Essen", "Bochum", "Wesel", "Hamminkeln"],
    faq: [["Kommen Sie auch nach Essen oder Bochum?", "Ja. Rufen Sie an, dann stimmen wir einen Termin ab, der für beide Seiten passt."], ["Können Sie Bergschäden beurteilen?", "Ich dokumentiere Risse und Verformungen, messe und beobachte sie und ordne ein, welche Ursachen in Frage kommen. Ob ein Bergschaden vorliegt, wird im Regulierungsverfahren geklärt. Meine Dokumentation unterstützt Sie dabei."], ["Seit dem Fenstertausch habe ich Schimmel. Woran liegt das?", "Neue Fenster sind dichter. Dadurch bleibt mehr Feuchte im Raum, während die Wände so kühl sind wie vorher. Ich finde heraus, ob Lüftung, eine Wärmebrücke oder der Fensteranschluss die Ursache ist."]] }
];

/* ---------- Ratgeber: Fachartikel zu typischen Bauschäden (Überschriften nach echten Suchanfragen) ---------- */
const RATGEBER_STAND = "18.11.2026";
const RATGEBER = [
  { slug: "ratgeber-feuchter-keller", to: "gebaeudeschaeden", min: 8, tool: ["Feuchter Keller im Sommer: Fenster auf oder zu?", "lueften"],
    seo: ["Feuchter Keller: Was tun? Ursachen, Selbsttest, Lösungen", "Feuchte Kellerwand, nasser Boden, muffiger Geruch? Ursachen erkennen, richtig lüften (Fenster auf oder zu?) und wann sich ein Gutachter lohnt."],
    h1: "Feuchter Keller: Was tun?",
    lead: "Ein feuchter Keller ist ärgerlich und kann teuer werden, wenn an der falschen Stelle saniert wird. Woher die Feuchte kommt, lässt sich oft schon mit einfachen Mitteln eingrenzen.",
    kurz: "Erst die Ursache klären, dann sanieren. Feuchte im Keller kommt meist von außen durch eine fehlende oder alte Abdichtung, von unten als aufsteigende Feuchte, aus der Luft als Kondensat im Sommer oder aus einer undichten Leitung. Ein einfacher Folientest grenzt das ein, eine fachgerechte Messung bringt Gewissheit.",
    secs: [
      ["Woran Sie Feuchtigkeit im Keller erkennen", [["Dunkle oder fleckige Stellen an Wand und Boden", "Weiße, kristalline Beläge (Salzausblühungen)", "Abplatzender Putz oder abblätternde Farbe", "Muffiger Geruch, Schimmel an Wänden oder gelagerten Gegenständen", "Feuchte Kartons, rostende Regale, beschlagene Rohre"]]],
      ["Die vier häufigsten Ursachen", ["Feuchte im Keller hat fast immer eine dieser Ursachen. Oft wirken auch zwei zusammen.", ["<b>Seitlich eindringende Feuchte:</b> Die Abdichtung der Außenwand fehlt, ist gealtert oder beschädigt. Wasser aus dem Erdreich dringt durch die Wand.", "<b>Aufsteigende Feuchte:</b> Ohne funktionierende Horizontalsperre zieht Feuchte aus dem Fundament in der Wand nach oben.", "<b>Kondensat:</b> Warme, feuchte Sommerluft trifft auf kühle Kellerwände. Die Feuchte schlägt sich nieder, obwohl die Wand selbst dicht ist.", "<b>Leckage:</b> Eine undichte Wasser- oder Abwasserleitung, ein defekter Anschluss oder eine schadhafte Grundleitung."]]],
      ["Feuchter Keller im Sommer: Fenster auf oder zu?", ["Im Sommer meist zu, jedenfalls tagsüber. Warme Luft kann viel Wasser tragen. Luft mit 25 °C und 60 Prozent relativer Luftfeuchte enthält rund 14 Gramm Wasser pro Kubikmeter. Kühlt sie an einer Kellerwand unter etwa 16 °C ab, kann sie das Wasser nicht mehr halten, und es schlägt sich an der Wand nieder.", "Lüften Sie den Keller im Sommer deshalb in den kühlen Nacht- und frühen Morgenstunden. Entscheidend ist, dass die Außenluft weniger Wasser enthält als die Kellerluft. Im Winter ist Lüften meist unproblematisch. Wer es genau wissen will, misst innen und außen mit einem Hygrometer oder nutzt einen Taupunktlüfter, der nur bei passender Witterung lüftet."]],
      ["Ein einfacher Selbsttest: die Folienprobe", ["Kleben Sie ein Stück Alufolie, etwa 30 mal 30 Zentimeter, mit Klebeband rundum dicht auf die feuchte Wand und warten Sie zwei bis drei Tage.", ["Ist die Folie auf der <b>Raumseite</b> feucht, kommt die Feuchte aus der Raumluft, meist also Kondensat.", "Ist die <b>Wandseite</b> feucht, kommt die Feuchte aus der Wand: von außen, von unten oder aus einer Leitung."], "Der Test ersetzt keine Messung, gibt aber einen ersten Hinweis. Was Feuchtemessgeräte aus dem Baumarkt leisten und wo ihre Grenzen liegen, lesen Sie im Ratgeber <a href=\"#ratgeber-feuchtigkeit-messen\">Feuchtigkeit in der Wand messen</a>."]],
      ["Feuchter Keller im Altbau: Ist das normal?", ["Viele ältere Häuser haben keine Abdichtung, wie sie heute üblich ist. Ein leicht feuchter Keller, der nur als Lager dient, kann deshalb unkritisch sein. Wichtig ist, dass sich der Zustand nicht verschlechtert: Wachsen die feuchten Flächen, bröckelt der Putz oder entsteht Schimmel, sollte die Ursache geklärt werden.", "Soll der Keller zu Wohnraum oder Hobbyraum werden, gelten andere Maßstäbe. Dann braucht es eine trockene Wand, und die Sanierung sollte gut geplant sein."]],
      ["Was kostet es, Feuchtigkeit im Keller zu beseitigen?", ["Das hängt ganz von der Ursache ab. Ist es Kondensat, reichen oft ein angepasstes Lüften, ein Entfeuchter oder kleine Maßnahmen wie eine funktionierende Dachrinne und ein Gefälle vom Haus weg. Muss dagegen die Außenwand freigelegt und neu abgedichtet werden, wird es schnell deutlich teurer.", "Genau deshalb lohnt sich die Ursachenklärung vorher: Sie verhindert, dass viel Geld in eine Maßnahme fließt, die das eigentliche Problem nicht löst."]],
      ["Warum Sanieren ohne Ursache selten hilft", ["Sanierputz, Farbe oder ein Luftentfeuchter bekämpfen Symptome. Kommt das Wasser von außen oder aus einem Leck, kehrt der Schaden zurück. Umgekehrt ist eine teure Außenabdichtung überflüssig, wenn das Problem Kondensat ist."]],
      ["Typisch im Münsterland und im Ruhrgebiet", ["Viele Häuser hier stammen aus den 1950er bis 1970er Jahren. Ihre Kellerabdichtung bestand oft nur aus einem Bitumenanstrich, der nach Jahrzehnten nachlässt. In Niederungen kann zudem das Grundwasser hoch stehen. Nach Starkregen sind Lichtschächte, Kellerabgänge und eine fehlende oder defekte Rückstausicherung häufige Schwachstellen."]],
      ["Wann ein Sachverständiger sinnvoll ist", [["Die Feuchte kommt immer wieder, obwohl schon saniert wurde", "Sie wollen ein Haus kaufen und sehen Hinweise auf Feuchte", "Handwerker schlagen sehr unterschiedliche oder teure Lösungen vor", "Es gibt Streit mit Verkäufer, Vermieter oder Baufirma"], "Ich messe die Feuchte in Wand und Luft, prüfe Abdichtung, Sockel und Leitungen und erkläre Ihnen, woher das Wasser kommt. Sie bekommen eine nachvollziehbare Empfehlung, unabhängig von Firmen, die Ihnen etwas verkaufen möchten."]]
    ],
    faq: [["Ist ein feuchter Keller gefährlich?", "Dauerhafte Feuchte kann Putz, Mauerwerk und Holz schädigen. Bildet sich Schimmel, kann das die Gesundheit belasten, vor allem wenn sich der Keller mit Wohnräumen die Luft teilt. Deshalb sollte die Ursache geklärt werden, bevor sich der Schaden ausbreitet."], ["Hilft ein Luftentfeuchter?", "Bei Kondensat kann ein Entfeuchter helfen. Kommt die Feuchte aus der Wand, verschiebt er das Problem nur und verbraucht dauerhaft Strom."], ["Feuchter Keller in der Mietwohnung: Was tun?", "Melden Sie den Schaden dem Vermieter schriftlich, am besten mit Fotos und Datum. Ob eine Mietminderung in Frage kommt, hängt vom Einzelfall und von der vereinbarten Nutzung des Kellers ab. Dazu berät Sie der Mieterverein oder ein Anwalt."], ["Was kostet die Klärung der Ursache?", "Das hängt vom Umfang ab. Nach einem kurzen Gespräch nenne ich Ihnen einen Preis oder einen klaren Kostenrahmen."]] },

  { slug: "ratgeber-schimmel-wohnung", to: "gebaeudeschaeden", min: 8,
    seo: ["Schimmel in der Wohnung: Ursachen, was tun, wer zahlt?", "Schimmel in der Ecke, am Fenster oder hinter dem Schrank? Ursachen erkennen, richtig handeln und klären, wer verantwortlich ist."],
    h1: "Schimmel in der Wohnung: Ursache finden, richtig handeln",
    lead: "Schimmel entsteht, wo es dauerhaft feucht ist. Wegwischen hilft nur kurz. Wer die Ursache kennt, wird ihn dauerhaft los und vermeidet Streit darüber, wer verantwortlich ist.",
    kurz: "Schimmel wächst dort, wo eine Oberfläche dauerhaft feucht ist, meist an kühlen Stellen wie Außenecken oder Fensterlaibungen. Ursache ist eine Wärmebrücke, zu hohe Luftfeuchte, eindringende Feuchte oder eine Kombination davon. Kleine Flächen können Sie selbst entfernen, wichtiger ist aber, die Ursache zu klären.",
    secs: [
      ["Wo Schimmel typischerweise auftritt", [["In Außenecken, besonders in Schlafzimmern", "Hinter Schränken an Außenwänden", "An Fensterlaibungen und unter Fensterbänken", "An Decken unter ungedämmten Dachbereichen oder Balkonen", "In Bädern ohne ausreichende Lüftung"], "Diese Stellen haben eines gemeinsam: Die Oberfläche ist kühler als der Rest des Raums. Dort schlägt sich Feuchte aus der Raumluft zuerst nieder."]],
      ["Schimmel in der Ecke: Warum gerade dort?", ["Eine Außenecke gibt über eine große Außenfläche Wärme ab, wird von innen aber nur über eine kleine Fläche erwärmt. Sie ist deshalb oft mehrere Grad kühler als die Wandmitte. Im Schlafzimmer kommt einiges zusammen: Es wird oft wenig geheizt, nachts entsteht durch Atmen viel Feuchte, und Möbel vor der Außenwand verhindern, dass warme Luft die Wand erreicht."]],
      ["Die drei Hauptursachen", [["<b>Wärmebrücken:</b> Bauteile, über die besonders viel Wärme verloren geht, etwa Ecken, Betondecken, Rollladenkästen oder schlecht angeschlossene Fenster.", "<b>Zu hohe Luftfeuchte:</b> Kochen, Duschen, Wäschetrocknen und Atmen bringen viel Wasser in die Raumluft. Wird nicht genug gelüftet, steigt die Feuchte.", "<b>Eindringende Feuchte:</b> Undichte Dächer, Fassaden, Anschlüsse oder Leitungen bringen Wasser von außen oder aus dem Gebäude selbst."], "Oft wirken mehrere Ursachen zusammen. Ein typisches Beispiel: Nach dem Einbau neuer, dichter Fenster entweicht weniger Feuchte. Die Wände sind aber so kühl wie vorher. Wo früher das alte Fenster beschlagen ist, schimmelt jetzt die Wand."]],
      ["Was Sie jetzt tun sollten", [["Fotografieren Sie den Befall mit Datum, bevor Sie etwas entfernen", "Messen Sie die Luftfeuchte mit einem Hygrometer. Dauerhaft über 60 Prozent ist zu viel", "Lüften Sie mehrmals täglich kurz und kräftig, statt Fenster dauerhaft zu kippen", "Heizen Sie alle Räume gleichmäßig, auch wenig genutzte", "Rücken Sie Möbel einige Zentimeter von der Außenwand ab", "Entfernen Sie kleine Flächen vorsichtig feucht, nicht trocken abbürsten"], "Das Umweltbundesamt empfiehlt, größere Schimmelflächen von Fachleuten entfernen zu lassen. Als Richtwert nennt es etwa einen halben Quadratmeter."]],
      ["Schimmel in der Mietwohnung: Wer ist verantwortlich, wer zahlt?", ["Entscheidend ist die Ursache. Liegt ein baulicher Mangel vor, etwa eine Wärmebrücke oder eindringende Feuchte, ist in der Regel der Vermieter für die Beseitigung zuständig. Liegt es am Heiz- und Lüftverhalten, kann der Mieter verantwortlich sein. Oft wirkt beides zusammen, und genau darüber wird gestritten.", "Mieter sollten Schimmel dem Vermieter unverzüglich melden. Ein Sachverständiger klärt die technischen Fragen: Wie warm ist die Wand an der befallenen Stelle? Gibt es eine Wärmebrücke? Dringt Feuchte ein? Diese Fakten helfen beiden Seiten, eine sachliche Lösung zu finden. Rechtliche Fragen klärt im Zweifel der Mieterverein, der Eigentümerverband oder ein Anwalt."]],
      ["Schimmel und Gesundheit", ["Schimmel kann die Atemwege und Augen reizen und Allergien auslösen. Wie stark, hängt von Art und Menge des Schimmels und von der einzelnen Person ab. Kinder, ältere Menschen und Menschen mit Vorerkrankungen sind empfindlicher. Bei Beschwerden sollten Sie ärztlichen Rat einholen."]],
      ["Typisch im Münsterland und im Ruhrgebiet", ["Viele Siedlungs- und Mehrfamilienhäuser aus den 1950er bis 1970er Jahren haben inzwischen neue, dichte Fenster bekommen, die Außenwände sind aber ungedämmt geblieben. Das ist eine der häufigsten Ursachen für Schimmel in Außenecken und an Fensterlaibungen."]],
      ["So gehe ich bei einer Schimmeluntersuchung vor", ["Ich messe Oberflächentemperaturen und Materialfeuchte, nehme bei Bedarf Wärmebilder auf und sehe mir Lüftung, Heizung und Bauteilanschlüsse an. So lässt sich unterscheiden, ob eine Wärmebrücke, die Nutzung oder eindringende Feuchte den Schimmel verursacht. Sie erhalten eine verständliche Erklärung und eine Empfehlung, was zu tun ist."]]
    ],
    faq: [["Womit entferne ich kleine Schimmelflächen?", "Für kleine Flächen auf glatten Oberflächen nennt das Umweltbundesamt zum Beispiel 70- bis 80-prozentigen Alkohol. Wichtiger ist aber, die Ursache zu beheben, sonst kommt der Schimmel wieder."], ["Hilft Anti-Schimmel-Farbe?", "Sie kann das Wachstum eine Zeit lang bremsen. Bleibt die Wand feucht, kommt der Schimmel trotzdem zurück. Zuerst muss die Ursache behoben werden."], ["Muss ich Schimmel dem Vermieter melden?", "Ja. Mieter sind verpflichtet, Mängel wie Schimmel unverzüglich anzuzeigen. Am besten schriftlich, mit Fotos und Datum."], ["Wer zahlt ein Schimmelgutachten?", "Das hängt vom Einzelfall ab. Oft ist das Ergebnis die Grundlage, um zu klären, wer für die Sanierung und die Kosten aufkommt."]] },

  { slug: "ratgeber-risse-wand", to: "gebaeudeschaeden", min: 7, tool: ["So beobachten Sie einen Riss", "risse"],
    seo: ["Risse in der Wand: Wann gefährlich? Setzungsriss erkennen", "Haarriss oder Setzungsriss? Woran Sie gefährliche Risse innen und außen erkennen, wie Sie sie beobachten und wann ein Gutachter kommen sollte."],
    h1: "Risse in der Wand: Wann sind sie gefährlich?",
    lead: "Fast jedes Haus hat Risse. Die meisten sind harmlos. Einige weisen aber auf Bewegungen im Gebäude hin, die man ernst nehmen sollte. Diese Hinweise helfen bei der ersten Einschätzung.",
    kurz: "Die meisten Risse sind harmlose Putz- oder Schwindrisse. Ernst nehmen sollten Sie Risse, die wachsen, schräg oder treppenförmig verlaufen, von Fenster- und Türecken ausgehen oder innen und außen an derselben Stelle zu sehen sind. Dann sollte ein Fachmann die Ursache klären, bevor repariert wird.",
    secs: [
      ["Meist harmlos: Haar-, Putz- und Schwindrisse", ["Feine, netzartige oder kurze Risse im Putz entstehen oft beim Trocknen oder durch Temperaturwechsel. Typisch sind auch Risse an Übergängen zwischen verschiedenen Baustoffen, etwa zwischen Mauerwerk und Betondecke oder an Trockenbauwänden. Solche Risse sind meist ein optisches Problem."]],
      ["Setzungsrisse am Haus erkennen", ["Setzungsrisse entstehen, wenn sich Teile eines Gebäudes unterschiedlich stark setzen. Typische Merkmale:", ["Sie verlaufen schräg, oft etwa im Winkel von 45 Grad", "Im Mauerwerk folgen sie treppenförmig den Fugen", "Sie gehen von den Ecken von Fenstern und Türen aus", "Sie sind an einem Ende deutlich breiter als am anderen", "Sie treten an Anbauten auf, die ein eigenes Fundament haben"], "In den ersten Jahren nach dem Bau setzt sich jedes Gebäude etwas. Risse daraus kommen oft zur Ruhe, sollten aber beobachtet werden."]],
      ["Riss innen und außen an derselben Stelle", ["Ist ein Riss innen und außen an derselben Stelle zu sehen, geht er wahrscheinlich durch die ganze Wand. Dann ist nicht nur der Putz betroffen, sondern das Bauteil selbst. Das sollte ein Fachmann ansehen."]],
      ["Warnzeichen auf einen Blick", [["Der Riss wird breiter oder länger", "Die Rissränder sind gegeneinander versetzt", "Türen und Fenster klemmen plötzlich", "Fliesen springen oder Böden senken sich", "Es kommen schnell neue Risse dazu"]]],
      ["So beobachten Sie einen Riss", [["Markieren Sie die Enden des Risses mit Bleistift und Datum", "Fotografieren Sie den Riss mit einem Lineal daneben, immer aus derselben Position", "Messen Sie die Breite, zum Beispiel mit einer Rissbreitenkarte aus dem Baumarkt", "Wiederholen Sie das alle paar Wochen und notieren Sie die Werte"], "So sehen Sie, ob sich ein Riss bewegt. Diese Notizen sind auch für einen Sachverständigen wertvoll."]],
      ["Typische Ursachen", ["Unterschiedliche Setzungen, etwa bei Anbauten mit eigenem Fundament. Veränderungen im Baugrund durch Trockenheit, Wasser oder Bäume nah am Haus. Fehlende Bewegungsfugen. Zusätzliche Lasten durch spätere Umbauten. Im Ruhrgebiet kommen in manchen Bereichen auch Bodenbewegungen durch den früheren Bergbau in Betracht."]],
      ["Risse reparieren: erst die Ursache, dann der Riss", ["Ruhende Putzrisse lassen sich verspachteln, bei größeren Flächen mit einem Armierungsgewebe. Bewegt sich der Riss noch, reißt er nach kurzer Zeit wieder auf. Dann muss zuerst die Ursache behoben werden. Bei Rissen im tragenden Mauerwerk gehört die Instandsetzung in fachkundige Hände und sollte geplant werden."]],
      ["Wann ein Sachverständiger kommen sollte", ["Wenn ein Riss wächst, eines der Warnzeichen zeigt oder Sie vor einem Kauf Klarheit brauchen. Ich bewerte Verlauf, Breite und Ursache, beobachte den Riss bei Bedarf über einen längeren Zeitraum und sage Ihnen, ob Handlungsbedarf besteht und welche Maßnahmen sinnvoll sind."]]
    ],
    faq: [["Ab welcher Breite ist ein Riss bedenklich?", "Eine feste Grenze gibt es nicht. Wichtiger als die Breite sind Verlauf, Lage und ob sich der Riss verändert. Ein breiter, ruhender Riss kann harmloser sein als ein feiner, der wächst."], ["Kann ich Risse einfach zuspachteln?", "Bei ruhenden Putzrissen ja. Bewegt sich der Riss noch, reißt er wieder auf. Klären Sie deshalb vorher, ob er zur Ruhe gekommen ist."], ["Sind Risse im Neubau normal?", "Feine Risse durch Trocknen und erste Setzungen sind in den ersten Jahren häufig. Breite, schräge oder wachsende Risse sollten Sie dagegen ansehen lassen, solange noch Gewährleistung besteht."], ["Zahlt die Versicherung?", "Das hängt von Ursache und Vertrag ab. Viele Verträge schließen Setzungsschäden aus. Eine fachliche Dokumentation hilft bei der Klärung."]] },

  { slug: "ratgeber-hauskauf-besichtigung", to: "hauskaufberatung", min: 8, print: true, pdf: "BSV-Niewerth-Checkliste-Hausbesichtigung.pdf",
    seo: ["Hauskauf Besichtigung: Checkliste – worauf achten?", "Checkliste für die Hausbesichtigung: Keller, Dach, Fassade, Heizung, Unterlagen, die richtigen Fragen an den Verkäufer und wann ein Gutachter sinnvoll ist."],
    h1: "Hauskauf: Checkliste für die Besichtigung",
    lead: "Bei der Besichtigung zählt der erste Eindruck. Für Ihre Entscheidung zählt aber, was hinter Tapete, Laminat und frischer Farbe steckt. Mit dieser Checkliste gehen Sie gezielter durchs Haus.",
    kurz: "Gehen Sie das Haus systematisch vom Keller bis zum Dach durch, fragen Sie nach Baujahr, Modernisierungen und Unterlagen und schreiben Sie auf, was Ihnen auffällt. Bei Altbauten oder sichtbaren Schäden nehmen Sie spätestens zur zweiten Besichtigung einen Sachverständigen mit, und zwar vor dem Notartermin.",
    secs: [
      ["Keller und Sockel", [["Feuchte Flecken, Ausblühungen, abplatzender Putz", "Muffiger Geruch, auch wenn frisch gestrichen wurde", "Risse in Wänden und Bodenplatte", "Zustand der Außenwand im Sockelbereich, Lichtschächte, Kellerabgang"]]],
      ["Dach und Dachboden", [["Alter und Zustand der Eindeckung, verrutschte oder gebrochene Ziegel", "Wasserflecken am Holz oder an der Dämmung", "Zustand des Dachstuhls, Hinweise auf Schädlinge", "Ist das Dach oder die oberste Geschossdecke gedämmt?"]]],
      ["Fassade, Fenster und Anschlüsse", [["Risse in der Fassade, besonders schräg von Fensterecken aus", "Alter und Dichtheit der Fenster", "Schimmel oder Verfärbungen an Laibungen und in Außenecken", "Zustand von Balkon, Terrasse und Regenrinnen"]]],
      ["Heizung, Leitungen und Elektrik", [["Alter und Art der Heizung", "Alter der Wasser- und Abwasserleitungen", "Zustand der Elektroinstallation und des Sicherungskastens"], "Bei sehr alten Heizkesseln kann nach dem Kauf eine Austauschpflicht bestehen. Fragen Sie nach dem Baujahr und lassen Sie sich die Unterlagen zeigen."]],
      ["Diese Fragen sollten Sie dem Verkäufer stellen", [["Wann wurde das Haus gebaut, und was wurde wann modernisiert?", "Gab es Wasserschäden, Feuchte, Schimmel oder Risse? Wurden sie behoben?", "Gab es Versicherungsschäden?", "Wie alt sind Dach, Fenster, Heizung und Leitungen?", "Wie hoch sind die laufenden Kosten für Heizung und Nebenkosten?", "Warum wird das Haus verkauft?"]]],
      ["Unterlagen, nach denen Sie fragen sollten", [["Energieausweis, er muss spätestens bei der Besichtigung vorgelegt werden", "Grundrisse, Baubeschreibung, Baugenehmigung", "Belege über Modernisierungen", "Protokolle von Schornsteinfeger und Heizungswartung", "Bei Eigentumswohnungen: Protokolle der Eigentümerversammlungen und Höhe der Erhaltungsrücklage"]]],
      ["Altbau kaufen: worauf besonders achten?", ["Jedes Baujahr hat seine typischen Themen. Bei Häusern aus den 1950er bis 1970er Jahren sind es oft fehlende Dämmung, Wärmebrücken, alte Leitungen und eine nachlassende Kellerabdichtung. In Gebäuden, die vor 1993 gebaut oder saniert wurden, können asbesthaltige Baustoffe verbaut sein, etwa in Fassadenplatten, Bodenbelägen oder Dacheindeckungen. Das ist kein Grund zur Panik, sollte aber vor einem Umbau geklärt werden."]],
      ["Was Sie zur Besichtigung mitbringen", [["Diese Checkliste, ausgedruckt", "Taschenlampe für Keller und Dachboden", "Zollstock", "Handy für Fotos von allem, was Ihnen auffällt", "Notizblock und Stift", "Genug Zeit, mindestens eine Stunde"]]],
      ["Hauskauf mit Gutachter: Ist das sinnvoll?", ["Bei einem Altbau, bei sichtbaren Schäden oder wenn Sie unsicher sind: ja. Bei einer Besichtigung sind Sie aufgeregt, gezeigt werden vor allem die schönen Seiten und die Zeit ist knapp. Als Sachverständiger gehe ich mit Ihnen vom Keller bis zum Dach, erkläre, was ich sehe, und schätze ein, welcher Sanierungsbedarf auf Sie zukommt.", "Das gibt Ihnen Sicherheit für die Entscheidung und sachliche Argumente für die Preisverhandlung. Im Verhältnis zum Kaufpreis und zu möglichen Sanierungskosten ist eine Begleitung meist gut investiert."]]
    ],
    faq: [["Wann sollte ich einen Gutachter mitnehmen?", "Am besten zur zweiten Besichtigung, bevor Sie einen Notartermin vereinbaren."], ["Wie lange dauert eine Begleitung?", "Meist 1,5 bis 3 Stunden, abhängig von Größe und Zustand der Immobilie."], ["Gutachter oder Architekt?", "Wichtig ist Erfahrung mit Schäden an bestehenden Gebäuden. Ein Sachverständiger für Schäden an Gebäuden ist genau darauf spezialisiert."], ["Ersetzt die Begleitung ein Wertgutachten?", "Nein. Ich beurteile den baulichen Zustand und den Sanierungsbedarf. Den Verkehrswert ermittelt ein Sachverständiger für Immobilienbewertung."]] },

  { slug: "ratgeber-baubegleitung-neubau", to: "bauueberwachung", min: 6,
    seo: ["Baubegleitung beim Neubau: Kosten, Ablauf, Prüftermine", "Unabhängige Baubegleitung beim Neubau: welche Bauabschnitte geprüft werden sollten, wie die Abnahme abläuft und wovon die Kosten abhängen."],
    h1: "Baubegleitung beim Neubau: die wichtigen Prüftermine",
    lead: "Viele Baumängel entstehen in wenigen Stunden und bleiben dann für Jahre unsichtbar. Wer an den richtigen Stellen prüfen lässt, findet sie, solange sie sich noch günstig beheben lassen.",
    kurz: "Eine unabhängige Baubegleitung prüft den Bau zu den Zeitpunkten, an denen wichtige Bauteile noch sichtbar sind: Abdichtung und Bodenplatte, Rohbau, Dach, vor Putz und Estrich und bei der Abnahme. So werden Mängel gefunden, solange sie sich noch günstig beheben lassen.",
    secs: [
      ["Warum Prüfen während des Baus so viel bringt", ["Ist die Abdichtung erst verfüllt, der Estrich eingebracht und die Wand verputzt, lassen sich Fehler nur noch mit großem Aufwand finden und beheben. Eine unabhängige Baubegleitung prüft deshalb zu den Zeitpunkten, an denen wichtige Bauteile noch sichtbar sind."]],
      ["Die wichtigsten Prüftermine", [["<b>Bodenplatte und Abdichtung:</b> vor dem Betonieren und bevor die Baugrube verfüllt wird", "<b>Rohbau:</b> Mauerwerk, Stürze, Decken und Anschlüsse", "<b>Dach:</b> Dachstuhl, Unterdeckung und Anschlüsse, bevor gedämmt und verkleidet wird", "<b>Vor dem Verputzen:</b> Fenstereinbau, Installationen, Luftdichtheit und Dämmung", "<b>Vor dem Estrich:</b> Trittschalldämmung, Randdämmstreifen und Leitungsführung", "<b>Abnahme:</b> gemeinsame Begehung und Protokoll aller Mängel"]]],
      ["Die Abnahme: ein besonders wichtiger Termin", ["Mit der Abnahme bestätigen Sie, dass die Bauleistung im Wesentlichen vertragsgemäß ist. Damit ändern sich wichtige Rechtsfolgen, etwa bei der Gewährleistung und bei der Frage, wer Mängel beweisen muss. Wie Sie sich darauf vorbereiten, lesen Sie im Ratgeber <a href=\"#ratgeber-bauabnahme\">Bauabnahme</a>."]],
      ["Baubegleitung bei Sanierung und Modernisierung", ["Auch bei Umbauten gibt es Bauteile, die später verdeckt sind, etwa Abdichtungen im Bad, die Dämmung im Dach oder neue Fensteranschlüsse. Bei geförderten energetischen Sanierungen gelten zudem eigene Anforderungen an die Baubegleitung. Klären Sie das frühzeitig mit Ihrem Energieberater."]],
      ["Was kostet eine Baubegleitung?", ["Die Kosten hängen von der Größe des Bauvorhabens, der Bauweise und der Zahl der Prüftermine ab. Abgerechnet wird meist nach Termin oder als Paket. Im Verhältnis zu den Kosten eines verdeckten Mangels ist eine Baubegleitung meist gut investiert. Ich mache Ihnen vorab einen klaren Vorschlag, welche Termine in Ihrem Fall sinnvoll sind."]],
      ["Eine zweite, unabhängige Sicht", ["Die Bauleitung des Bauunternehmens arbeitet für das Unternehmen. Eine unabhängige Baubegleitung arbeitet für Sie. Das ist kein Misstrauen gegenüber der Baufirma, sondern eine zweite fachliche Sicht, die Fehler früh erkennt und hilft, Streit zu vermeiden."]]
    ],
    faq: [["Wann sollte ich die Baubegleitung beauftragen?", "Am besten vor Baubeginn. Dann lassen sich die Prüftermine sinnvoll in den Bauablauf einplanen."], ["Darf ich einen Gutachter auf die Baustelle mitbringen?", "In der Regel ja. Regeln Sie den Zugang zur Baustelle und die Termine am besten schon im Bauvertrag."], ["Gilt das auch für Umbau und Sanierung?", "Ja. Auch bei Modernisierungen gibt es Bauteile, die später verdeckt sind, etwa Abdichtungen im Bad oder die Dämmung im Dach."], ["Kann ich Mängel auch selbst rügen?", "Ja. Wichtig ist, Mängel schriftlich und konkret zu benennen. Fotos und ein Protokoll des Sachverständigen helfen dabei."]] },

  { slug: "ratgeber-bauabnahme", to: "bauueberwachung", min: 7, print: true, pdf: "BSV-Niewerth-Checkliste-Bauabnahme.pdf",
    seo: ["Bauabnahme: Ablauf, Checkliste und Tipps vom Gutachter", "Was bei der Bauabnahme passiert, warum sie so wichtig ist, wie Sie sich vorbereiten und weshalb ein Sachverständiger dabei sein sollte."],
    h1: "Bauabnahme: So bereiten Sie sich richtig vor",
    lead: "Die Abnahme ist einer der wichtigsten Termine beim Bauen. Sie entscheidet mit darüber, wie gut Sie bei späteren Mängeln dastehen. Mit guter Vorbereitung gehen Sie entspannt hinein.",
    kurz: "Mit der Abnahme erklären Sie, dass die Bauleistung im Wesentlichen vertragsgemäß ist. Danach beginnt in der Regel die Gewährleistung, und Mängel müssen meist Sie beweisen. Gehen Sie deshalb vorbereitet, mit Zeit und am besten mit einem Sachverständigen in den Termin und lassen Sie alle Mängel ins Protokoll aufnehmen.",
    secs: [
      ["Was bedeutet die Abnahme?", ["Mit der Abnahme erkennen Sie die Bauleistung als im Wesentlichen vertragsgemäß an. Das hat Folgen:", ["Die Frist für Mängelansprüche beginnt, bei Bauwerken in der Regel fünf Jahre", "Wer einen Mangel geltend macht, muss ihn danach in der Regel beweisen", "Die Schlusszahlung wird fällig", "Bekannte Mängel und eine vereinbarte Vertragsstrafe müssen Sie sich ausdrücklich vorbehalten, sonst können Sie Rechte verlieren"], "Diese Hinweise ersetzen keine Rechtsberatung. Bei Fragen zum Vertrag hilft ein Fachanwalt für Bau- und Architektenrecht."]],
      ["Wann Sie die Abnahme verweigern können", ["Bei wesentlichen Mängeln können Sie die Abnahme verweigern. Kleinere Mängel sind dagegen kein Grund, sie gehören aber vollständig ins Protokoll, mit einer Frist zur Beseitigung. Ob ein Mangel wesentlich ist, lässt sich vor Ort oft nur mit fachlicher Erfahrung sicher beurteilen."]],
      ["So bereiten Sie sich vor", [["Bauvertrag, Baubeschreibung und Pläne bereitlegen", "Eine eigene Liste mit allem führen, was Ihnen in den letzten Wochen aufgefallen ist", "Den Termin bei Tageslicht legen und genug Zeit einplanen, beim Einfamilienhaus mehrere Stunden", "Taschenlampe, Zollstock, Wasserwaage und Handy für Fotos mitnehmen", "Den Sachverständigen rechtzeitig einplanen"]]],
      ["Checkliste: Worauf achten bei der Abnahme?", [["Fenster und Türen: schließen sie leicht und dicht, sind Beschläge eingestellt?", "Fliesen: Fugen, Hohlstellen, Kanten, Gefälle in Dusche und auf dem Balkon", "Silikonfugen an Bad, Küche und Fensterbänken", "Wände und Decken: Risse, Unebenheiten, Putzschäden", "Böden und Estrich: Risse, Absätze, Randfugen", "Elektro: alle Schalter, Steckdosen und Leuchten ausprobieren", "Heizung und Lüftung: läuft alles, gibt es Einweisung und Unterlagen?", "Außen: Sockel, Abdichtung, Regenrinnen, Gefälle vom Haus weg, Dachanschlüsse"]]],
      ["Das Abnahmeprotokoll", ["Alles, was Ihnen auffällt, gehört ins Protokoll: möglichst genau beschrieben, mit Ort und Foto, und mit einer Frist zur Beseitigung. Unterschreiben Sie nichts, was Sie nicht verstanden haben, und lassen Sie sich eine Kopie geben."]],
      ["Warum ein Sachverständiger dabei sein sollte", ["Viele Mängel sind für Laien nicht zu erkennen: ein fehlendes Gefälle, eine unzureichende Abdichtung oder eine falsch eingebaute Dämmung. Als Sachverständiger kenne ich die Regeln der Technik, prüfe gezielt und formuliere Mängel so, dass sie im Protokoll eindeutig sind. Das gibt Ihnen Sicherheit für einen Termin, der rechtlich viel bewirkt."]],
      ["Sonderfall Eigentumswohnung vom Bauträger", ["Beim Kauf einer neuen Eigentumswohnung wird zwischen Sondereigentum, also Ihrer Wohnung, und Gemeinschaftseigentum wie Dach, Fassade und Treppenhaus unterschieden. Beides wird abgenommen, oft in getrennten Terminen. Achten Sie darauf, wie die Abnahme des Gemeinschaftseigentums im Vertrag geregelt ist."]]
    ],
    faq: [["Muss ich abnehmen, wenn noch Mängel da sind?", "Bei wesentlichen Mängeln können Sie die Abnahme verweigern. Kleinere Mängel werden ins Protokoll aufgenommen und mit Frist beseitigt."], ["Wie lange dauert eine Bauabnahme?", "Beim Einfamilienhaus meist mehrere Stunden. Planen Sie lieber großzügig, unter Zeitdruck wird leicht etwas übersehen."], ["Was ist, wenn ich nach der Abnahme Mängel finde?", "Dann haben Sie in der Regel weiterhin Ansprüche, bei Bauwerken meist fünf Jahre ab Abnahme. Melden Sie Mängel schriftlich und so früh wie möglich."], ["Was kostet ein Sachverständiger bei der Abnahme?", "Das hängt von Größe und Umfang ab. Ich nenne Ihnen vorab einen festen Preis oder einen klaren Kostenrahmen."]] },

  { slug: "ratgeber-feuchtigkeit-messen", to: "gebaeudeschaeden", min: 6,
    seo: ["Feuchtigkeit in der Wand messen: Was Messgeräte zeigen", "Feuchtemessgerät aus dem Baumarkt: was die Anzeige wirklich bedeutet, wo die Grenzen liegen und wie ein Sachverständiger Feuchte zuverlässig misst."],
    h1: "Feuchtigkeit in der Wand messen: Was die Geräte wirklich zeigen",
    lead: "Feuchtemessgeräte gibt es günstig im Baumarkt. Die Anzeige wirkt genau, sagt aber oft weniger aus, als man denkt. So nutzen Sie ein Gerät sinnvoll, und so misst ein Sachverständiger.",
    kurz: "Einfache Feuchtemessgeräte zeigen Unterschiede gut an, aber keine verlässlichen Feuchtegehalte: Salze, Baustoff und Oberfläche verfälschen das Ergebnis. Für eine belastbare Aussage braucht es mehrere Messverfahren, ein Messraster und die Erfahrung, die Werte richtig einzuordnen.",
    secs: [
      ["Wie Baumarkt-Messgeräte arbeiten", ["Die meisten Geräte messen entweder den elektrischen Widerstand zwischen zwei Spitzen oder kapazitiv über eine Messfläche. Feuchte verändert beide Werte. Viele Geräte sind aber für Holz kalibriert oder zeigen nur Skalenwerte an, keine echten Prozent Feuchte im Mauerwerk."]],
      ["Warum die Anzeige oft täuscht", [["<b>Salze</b> im Mauerwerk erhöhen die Leitfähigkeit und lassen eine Wand feuchter erscheinen, als sie ist", "<b>Baustoffe</b> wie Ziegel, Kalksandstein, Beton und Putz reagieren unterschiedlich", "<b>Oberfläche oder Tiefe:</b> Gemessen wird meist nur die oberste Schicht", "<b>Metall</b> wie Leitungen oder Bewehrung in der Wand verfälscht die Messung", "<b>Temperatur</b> und Kondensat auf der Oberfläche beeinflussen das Ergebnis"]]],
      ["So nutzen Sie ein Messgerät sinnvoll", [["Vergleichen statt absolut lesen: trockene und feuchte Stellen derselben Wand", "In einem Raster messen, zum Beispiel alle 20 Zentimeter von unten nach oben", "Dieselben Stellen nach einigen Wochen wiederholen und notieren", "Zusätzlich Raumtemperatur und Luftfeuchte mit einem Hygrometer festhalten"], "So erkennen Sie, wo die Feuchte am höchsten ist und ob sie zu- oder abnimmt. Das sind wertvolle Hinweise, auch für ein späteres Gutachten."]],
      ["Wie ich Feuchte messe", ["Ich kombiniere mehrere Verfahren, messe in einem Raster und in verschiedenen Tiefen und vergleiche mit trockenen Referenzstellen. Oberflächentemperaturen und Wärmebilder zeigen, ob Kondensat im Spiel ist. Wo es auf genaue Werte ankommt, etwa beim Estrich vor dem Verlegen eines Bodenbelags, bestimme ich den Feuchtegehalt mit der CM-Messung an einer entnommenen Probe.", "Erst das Zusammenspiel der Messwerte mit dem Befund vor Ort ergibt ein belastbares Bild: Woher kommt die Feuchte, wie weit reicht sie, und was ist zu tun?"]],
      ["Wann eine professionelle Messung sinnvoll ist", [["Vor einer teuren Sanierung oder Abdichtung", "Vor dem Kauf eines Hauses mit Hinweisen auf Feuchte", "Wenn Estrich belegt werden soll", "Bei Streit über die Ursache, etwa zwischen Mieter und Vermieter oder mit einer Baufirma", "Nach einem Wasserschaden, um die Trocknung zu kontrollieren"]]]
    ],
    faq: [["Wie genau sind Feuchtemessgeräte aus dem Baumarkt?", "Für Vergleiche an derselben Wand sind sie brauchbar. Einen verlässlichen Feuchtegehalt im Mauerwerk liefern sie nicht, weil Salze und Baustoff das Ergebnis stark beeinflussen."], ["Ab welchem Wert ist eine Wand zu feucht?", "Eine feste Zahl gibt es nicht. Was normal ist, hängt vom Baustoff, von der Nutzung des Raums und vom Messverfahren ab. Wichtiger ist, ob die Feuchte schadet und woher sie kommt."], ["Was ist eine CM-Messung?", "Bei der CM-Messung wird eine Materialprobe mit einem Reagenz in einem Druckbehälter gemessen. Sie gilt als bewährtes Verfahren, um zum Beispiel die Belegreife von Estrich zu bestimmen."], ["Kann man Feuchte mit einer Wärmebildkamera sehen?", "Indirekt. Feuchte Stellen sind oft kühler und zeichnen sich im Wärmebild ab. Eine Feuchtemessung ersetzt das aber nicht, beides ergänzt sich."]] }
];

REGIONEN.forEach(r => { SEO[r.slug] = r.seo; });
RATGEBER.forEach(a => { SEO[a.slug] = a.seo; });
RATGEBER.find(a => a.slug === "ratgeber-bauabnahme").pub = RATGEBER.find(a => a.slug === "ratgeber-feuchtigkeit-messen").pub = "2026-11-18";
SEO.ratgeber = ["Ratgeber Bauschäden | Bausachverständiger Münsterland", "Feuchter Keller, Schimmel, Risse, Feuchtemessung, Hauskauf, Neubau und Bauabnahme: Fachartikel vom Bausachverständigen aus Borken."];

const para = x => Array.isArray(x) ? `<ul class="checks">${x.map(i => `<li>${use("i-check")}<span>${i}</span></li>`).join("")}</ul>` : `<p>${x}</p>`;
const faqHtml = f => `<div class="faq">${f.map(([q, a], i) => `<details${i === 0 ? " open" : ""}><summary>${q}</summary><p>${a}</p></details>`).join("")}</div>`;
const artCard = a => `<a class="acard" href="#${a.slug}"><span class="acard-k">Ratgeber · ${a.min} Min. Lesezeit</span><h3>${a.h1}</h3><p>${a.lead}</p><span class="go">Weiterlesen <span class="arrow">→</span></span></a>`;

function regionPage(r) {
  const themen = NEEDS.map(n => { const l = LEISTUNGEN.find(x => x.slug === n.to); return `<article class="need">${ic(n.icon)}<h3>${n.h}</h3><p>${n.t}</p><div class="need-act"><a class="btn btn--primary" href="#kontakt" data-thema="${n.to}" data-label="${n.cta}" data-hint="${n.hint}">${n.cta} <span class="arrow">→</span></a><a class="need-more" href="#${n.to}">Mehr zu ${l.title} →</a></div></article>`; }).join("");
  const andere = REGIONEN.filter(x => x !== r).map(x => `<a href="#${x.slug}">${PIN}${x.name}</a>`).join("");
  return `
  <section class="page-hero page-hero--plain">
    <svg class="bgroof" viewBox="0 0 600 260" aria-hidden="true"><path d="M10 250 L300 20 L590 250"/></svg>
    <div class="wrap"><div class="page-hero-copy">
      <div class="crumbs"><a href="#start">Start</a><span>/</span><span>Einsatzgebiet ${r.name}</span></div>
      <h1>${r.h1}</h1>
      <p class="tagline">${r.tag}</p>
      <p>${r.lead}</p>
      <div class="hero-actions"><a class="btn btn--primary" href="#kontakt">Ortstermin anfragen <span class="arrow">→</span></a><a class="btn btn--outline-light" href="tel:+491796933684">${use("i-phone")}0179 6933684</a></div>
    </div></div>
  </section>
  <section class="section"><div class="wrap intro-grid">
    <div class="intro-text">${r.secs.map(([h, ps]) => `<div class="isec"><h2>${h}</h2>${ps.map(para).join("")}</div>`).join("")}</div>
    <aside class="facts-box" aria-label="Auf einen Blick">
      <h3>Auf einen Blick</h3>
      <dl>
        <dt>Büro</dt><dd>Propst-Pricking-Str. 16, 46325 Borken</dd>
        <dt>Ortstermin</dt><dd>kurzfristig nach Absprache</dd>
        <dt>Erreichbar</dt><dd>Mo–Fr 8–18 Uhr, 0179 6933684</dd>
        <dt>Qualifikation</dt><dd>Sachverständiger für Schäden an Gebäuden (persCert TÜV Rheinland)</dd>
      </dl>
      <a class="btn btn--primary" href="#kontakt">Anfrage senden</a>
    </aside>
  </div></section>
  <section class="section section--soft"><div class="wrap">
    <div class="head"><span class="kicker">Wobei ich helfe</span><h2>Typische Anliegen in der Region ${r.name}</h2></div>
    <div class="needs">${themen}</div>
  </div></section>
  <section class="section"><div class="wrap more-grid">
    <div><h3>Hier bin ich für Sie unterwegs</h3><p class="area-line">${r.orte.join(" · ")}</p></div>
    <div><h3>Weitere Regionen</h3><div class="other">${andere}</div></div>
  </div></section>
  <section class="section section--soft"><div class="wrap faq-grid">
    <div class="head" style="margin:0;align-content:start"><span class="kicker">Häufige Fragen</span><h2>Gut zu wissen</h2><p>Ihre Frage ist nicht dabei? Rufen Sie mich einfach an.</p></div>
    ${faqHtml(r.faq)}
  </div></section>`;
}

/* Kleine Rechner im Ratgeber */
const TOOLS = {
  lueften: `<div class="tool" data-tool="lueften"><span class="kurz-k">Lüftungsrechner</span><h3>Keller jetzt lüften oder nicht?</h3><p>Tragen Sie Temperatur und Luftfeuchte im Keller und draußen ein. Die Kellerwerte zeigt ein einfaches Hygrometer, die Außenwerte jede Wetter-App.</p>
  <div class="tool-grid"><fieldset><legend>Im Keller</legend><label>Temperatur in °C<input type="number" inputmode="decimal" name="ti" value="15" step="0.5"></label><label>Luftfeuchte in %<input type="number" inputmode="numeric" name="hi" value="70" min="1" max="100"></label></fieldset>
  <fieldset><legend>Draußen</legend><label>Temperatur in °C<input type="number" inputmode="decimal" name="ta" value="24" step="0.5"></label><label>Luftfeuchte in %<input type="number" inputmode="numeric" name="ha" value="60" min="1" max="100"></label></fieldset></div>
  <output class="tool-out" aria-live="polite"></output><small class="tool-note">Grobe Orientierung nach der absoluten Luftfeuchte. Sie ersetzt keine Messung vor Ort.</small></div>`
};
TOOLS.risse = `<div class="tool" data-tool="risse"><span class="kurz-k">Riss-Tagebuch</span><h3>Risse beobachten und festhalten</h3><p>Tragen Sie bei jeder Messung Datum, Stelle und Rissbreite ein. Das Tagebuch zeigt, ob sich ein Riss verändert. Ihre Einträge bleiben nur auf diesem Gerät gespeichert.</p>
  <div class="rt-form"><label>Datum<input type="date" name="d"></label><label>Stelle<input name="o" placeholder="z. B. Wohnzimmer, über dem Fenster" list="rt-orte" autocomplete="off"></label><label>Breite in mm<input type="number" name="b" step="0.05" min="0" inputmode="decimal" placeholder="0,2"></label><button type="button" class="btn btn--primary" data-rt="add">Eintragen</button></div><datalist id="rt-orte"></datalist>
  <div class="rt-list" aria-live="polite"></div>
  <div class="rt-actions"><a class="btn btn--primary" href="#kontakt" data-thema="gebaeudeschaeden" data-label="Riss beurteilen lassen" data-rt="send">An André schicken</a><button type="button" class="btn btn--outline-light" data-rt="print">Drucken</button><button type="button" class="rt-clear" data-rt="clear">Alle Einträge löschen</button></div></div>`;
const slugId = h => h.replace(/<[^>]+>/g, "").toLowerCase().replace(/ä/g, "ae").replace(/ö/g, "oe").replace(/ü/g, "ue").replace(/ß/g, "ss").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
function artikelPage(a) {
  const l = LEISTUNGEN.find(x => x.slug === a.to), c = CTA[a.to];
  const mehr = RATGEBER.filter(x => x !== a).slice(0, 3).map(artCard).join("");
  return `
  <section class="page-hero page-hero--plain">
    <svg class="bgroof" viewBox="0 0 600 260" aria-hidden="true"><path d="M10 250 L300 20 L590 250"/></svg>
    <div class="wrap"><div class="page-hero-copy">
      <div class="crumbs"><a href="#start">Start</a><span>/</span><a href="#ratgeber">Ratgeber</a><span>/</span><span>${a.h1.split(":")[0]}</span></div>
      <h1>${a.h1}</h1>
      <p>${a.lead}</p>
      <p class="byline">Von <a href="#ueber-mich">André Niewerth</a>, Sachverständiger für Schäden an Gebäuden · Aktualisiert am ${RATGEBER_STAND} · ${a.min} Min. Lesezeit</p>
    </div></div>
  </section>
  <section class="section"><div class="wrap intro-grid">
    <article class="intro-text article">
      <div class="kurz"><span class="kurz-k">Kurz gesagt</span><p>${a.kurz}</p></div>
      ${(a.print || clFor("art", a.slug).length) ? `<div class="art-actions">${clFor("art", a.slug).map(c => clLink(c)).join("")}${a.print ? `<button type="button" class="btn btn--outline print-btn" data-print>Seite drucken</button>` : ""}</div>` : ""}
      <nav class="toc" aria-label="Inhalt"><b>Inhalt</b><ol>${a.secs.map(([h]) => `<li><a href="#${slugId(h)}" data-toc>${h}</a></li>`).join("")}</ol></nav>
      ${a.secs.map(([h, ps]) => `<div class="isec" id="${slugId(h)}"><h2>${h}</h2>${ps.map(para).join("")}</div>` + (a.tool && a.tool[0] === h ? TOOLS[a.tool[1]] : "")).join("")}
      <aside class="author" aria-label="Über den Autor"><span class="author-k">Über den Autor</span><b>André Niewerth</b><p>Sachverständiger für Schäden an Gebäuden (persCert TÜV Rheinland), Maurer- und Stahlbetonbauermeister und Geprüfter Betriebswirt (HwO). Seit seiner Maurerlehre 1997 am Bau, heute mit eigenem Sachverständigenbüro in Borken.</p><div class="author-links"><a href="#ueber-mich">Mehr über mich →</a><a href="https://www.certipedia.com/quality_marks/0217466933?locale=de" target="_blank" rel="noopener">Zertifikat beim TÜV prüfen →</a></div></aside>
    </article>
    <aside class="facts-box" aria-label="Hilfe vom Sachverständigen">
      <h3>${c[1]}</h3>
      <p style="color:#d4deea">${c[2]}</p>
      <a class="btn btn--primary" href="#kontakt" data-thema="${a.to}">${c[0]}</a>
      <a class="fb-link" href="#${l.slug}">Mehr zu ${l.title} →</a>
      <p class="fb-regions">Vor Ort im <a href="#bausachverstaendiger-borken">Kreis Borken</a>, im <a href="#bausachverstaendiger-muensterland">Münsterland</a> und im <a href="#bausachverstaendiger-ruhrgebiet">Ruhrgebiet</a>.</p>
    </aside>
  </div></section>
  <section class="section section--soft"><div class="wrap faq-grid">
    <div class="head" style="margin:0;align-content:start"><span class="kicker">Häufige Fragen</span><h2>Kurz beantwortet</h2></div>
    ${faqHtml(a.faq)}
  </div></section>
  <section class="section"><div class="wrap">
    <div class="head"><span class="kicker">Ratgeber</span><h2>Das könnte Sie auch interessieren</h2></div>
    <div class="acards">${mehr}</div>
  </div></section>`;
}

/* ---------- Kostenlose Checklisten (PDF) ---------- */
const PDF_URL = "https://bsv-niewerth.de/wp-content/themes/bsv-niewerth/assets/pdf/";
const rgLists = (slug, re) => RATGEBER.find(a => a.slug === slug).secs.filter(([h, it]) => it.some(Array.isArray) && (!re || re.test(h))).map(([h, it]) => [h, it.filter(Array.isArray).flat()]);
const CHECKLISTEN = [
  { file: "BSV-Niewerth-Checkliste-Hausbesichtigung.pdf", art: "ratgeber-hauskauf-besichtigung", to: "hauskaufberatung", btn: "Checkliste als PDF", pages: 2, extra: "notes",
    title: "Checkliste Hausbesichtigung", text: "Keller, Dach, Fassade, Heizung, Unterlagen und die richtigen Fragen an den Verkäufer: zum Abhaken bei der Besichtigung.",
    fields: ["Objekt / Adresse", "Datum der Besichtigung", "Baujahr"], secs: () => rgLists("ratgeber-hauskauf-besichtigung") },
  { file: "BSV-Niewerth-Checkliste-Bauabnahme.pdf", art: "ratgeber-bauabnahme", to: "bauueberwachung", btn: "Checkliste als PDF", pages: 1, extra: "maengel",
    title: "Checkliste Bauabnahme", text: "Vorbereitung, die wichtigsten Prüfpunkte bei der Begehung und eine Mängeltabelle für das Abnahmeprotokoll.",
    fields: ["Bauvorhaben", "Datum der Abnahme", "Teilnehmer"], secs: () => rgLists("ratgeber-bauabnahme", /^(So bereiten|Checkliste)/) },
  { file: "BSV-Niewerth-Checkliste-Neubau-Prueftermine.pdf", art: "ratgeber-baubegleitung-neubau", to: "bauueberwachung", btn: "Prüftermine als PDF", pages: 1, extra: "neubau",
    title: "Prüftermine beim Neubau", text: "Die Bauabschnitte, die Sie prüfen lassen sollten, bevor sie verdeckt werden, mit Tabelle zum Eintragen der Termine.",
    fields: ["Bauvorhaben", "Bauunternehmen", "Baubeginn"], secs: () => rgLists("ratgeber-baubegleitung-neubau") },
  { file: "BSV-Niewerth-Rissprotokoll.pdf", art: "ratgeber-risse-wand", to: "gebaeudeschaeden", btn: "Rissprotokoll als PDF", pages: 1, extra: "riss",
    title: "Rissprotokoll zum Ausdrucken", text: "Risse richtig beobachten: Anleitung, Warnzeichen und eine Tabelle für Datum, Stelle und Rissbreite.",
    fields: ["Gebäude / Adresse", "Begonnen am", "Messmittel (z. B. Rissbreitenkarte)"], secs: () => rgLists("ratgeber-risse-wand", /^(So beobachten|Warnzeichen)/) },
  { file: "BSV-Niewerth-Lueftungsprotokoll-Schimmel.pdf", art: "ratgeber-schimmel-wohnung", to: "gebaeudeschaeden", btn: "Lüftungsprotokoll als PDF", pages: 2, extra: "klima",
    title: "Lüftungs- und Raumklima-Protokoll", text: "Bei Schimmel zwei bis vier Wochen Temperatur, Luftfeuchte und Lüften notieren: eine sachliche Grundlage für Vermieter, Mieter und Sachverständige.",
    fields: ["Wohnung / Raum", "Begonnen am", "Hygrometer (Modell)"],
    secs: () => [["So messen Sie richtig", ["Hygrometer in Raummitte aufstellen, nicht direkt an der Außenwand oder an der Heizung", "Möglichst morgens und abends zur gleichen Uhrzeit ablesen", "Vor dem Lüften messen und notieren, wie lange gelüftet wurde", "Besondere Ereignisse festhalten, zum Beispiel Wäschetrocknen, Kochen oder Duschen", "Den Schimmelbefall zu Beginn und am Ende mit Datum fotografieren"]],
                 ["Sofortmaßnahmen bei Schimmel", ["Mehrmals täglich kurz und kräftig lüften statt Fenster dauerhaft zu kippen", "Alle Räume gleichmäßig heizen, auch wenig genutzte", "Möbel einige Zentimeter von Außenwänden abrücken", "Kleine Flächen feucht entfernen, größere fachgerecht sanieren lassen", "Als Mieter: Schimmel dem Vermieter unverzüglich schriftlich melden"]]] },
  { file: "BSV-Niewerth-Checkliste-Wasserschaden.pdf", art: null, to: "leckageortung", btn: "Checkliste als PDF", pages: 1, extra: "wasser",
    title: "Wasserschaden: Checkliste für die ersten Stunden", text: "Was nach einem Wasserschaden zu tun ist: Sicherheit, Dokumentation für die Versicherung, Meldung und Trocknung.",
    fields: ["Gebäude / Adresse", "Schaden entdeckt am", "Betroffene Räume"],
    secs: () => [["Sofort: Sicherheit", ["Bei Wasser in der Nähe von Steckdosen oder Geräten die Sicherung des Bereichs ausschalten", "Haupthahn oder den betroffenen Absperrhahn schließen", "Stehendes Wasser aufnehmen, Möbel und Wertsachen in Sicherheit bringen", "Bei Gefahr für das Gebäude oder Personen Hilfe holen"]],
                 ["Dokumentieren", ["Fotos und Videos vom Schaden machen, bevor aufgeräumt wird", "Beschädigte Gegenstände auflisten und nicht vorschnell entsorgen", "Rechnungen und Belege von Notmaßnahmen aufbewahren"]],
                 ["Melden", ["Versicherung unverzüglich informieren (Wohngebäude- oder Hausratversicherung)", "Als Mieter: Vermieter oder Hausverwaltung benachrichtigen", "Im Mehrfamilienhaus die Nachbarn darunter informieren"]],
                 ["Ursache finden und richtig trocknen", ["Die Leckstelle orten lassen, bevor großflächig geöffnet wird", "Trocknung mit Feuchtemessungen begleiten lassen", "Erst nach nachgewiesener Trocknung Boden, Putz oder Tapete erneuern"]]] }
];
SEO.checklisten = ["Kostenlose Checklisten zum Bauen und Kaufen (PDF)", "Checklisten zum Ausdrucken vom Bausachverständigen: Hausbesichtigung, Bauabnahme, Neubau, Rissprotokoll, Lüftungsprotokoll und Wasserschaden."];
SEO["schadens-check"] = ["Schadens-Check: Feuchte, Riss oder Schimmel einordnen", "Drei Fragen, eine erste Einordnung: Was hinter Feuchte, Rissen, Schimmel oder Wasserflecken stecken kann und was jetzt sinnvoll ist."];
const clFor = (key, val) => CHECKLISTEN.filter(c => c[key] === val);
const clLink = (c, cls = "btn btn--primary") => `<a class="${cls}" href="${PDF_URL}${c.file}" download>${use("i-doc")}${c.btn}</a>`;
function renderChecklisten() {
  const el = $id("cl-list"); if (!el || el.children.length) return;
  el.innerHTML = CHECKLISTEN.map(c => {
    const a = c.art && RATGEBER.find(x => x.slug === c.art), l = LEISTUNGEN.find(x => x.slug === c.to);
    return `<article class="clcard"><span class="acard-k">PDF · ${c.pages} ${c.pages > 1 ? "Seiten" : "Seite"} · kostenlos</span><h3>${c.title}</h3><p>${c.text}</p><div class="clcard-act">${clLink(c)}${a ? `<a class="need-more" href="#${a.slug}">Zum Ratgeber →</a>` : `<a class="need-more" href="#${l.slug}">Mehr zu ${l.title} →</a>`}</div></article>`;
  }).join("");
}

/* ---------- Schadens-Check: drei Fragen, erste Einordnung ---------- */
const CHECK_Q = [
  ["Wo zeigt sich der Schaden?", [["keller", "Im Keller"], ["innen", "Wand oder Decke innen"], ["aussen", "Fassade oder Außenwand"], ["fenster", "Am Fenster"], ["dach", "Dach oder Dachboden"], ["bad", "Bad, Küche oder Leitungen"], ["boden", "Am Boden"]]],
  ["Was sehen oder bemerken Sie?", [["feucht", "Feuchte Stelle oder Wasserfleck"], ["wasser", "Wasser tropft oder läuft"], ["schimmel", "Schimmel"], ["riss", "Riss"], ["salz", "Weiße Beläge oder bröckelnder Putz"], ["geruch", "Muffiger Geruch"], ["kalt", "Kalte Stellen oder Zugluft"]]],
  ["Wie entwickelt es sich?", [["neu", "Gerade erst entdeckt"], ["schlimmer", "Seit Wochen, es wird schlimmer"], ["gleich", "Schon länger, unverändert"], ["wieder", "Kommt immer wieder, z. B. nach Regen oder im Winter"]]]
];
function checkResult([wo, was, wie]) {
  let r;
  if (was === "wasser" || (wo === "bad" && was === "feucht") || (wo === "boden" && was === "feucht"))
    r = { t: "Möglicher Leitungs- oder Wasserschaden", x: "Läuft oder tropft Wasser, oder zeigt sich ein Fleck in der Nähe von Leitungen, steckt oft eine Undichtigkeit dahinter. Je früher sie gefunden wird, desto kleiner bleibt der Schaden.", to: "leckageortung", art: null, urgent: true,
      tun: ["Betroffenen Absperrhahn schließen, bei Wasser nahe Strom die Sicherung ausschalten", "Alles fotografieren und die Versicherung informieren", "Leckstelle orten lassen, bevor großflächig geöffnet wird"] };
  else if (was === "riss")
    r = { t: wie === "schlimmer" ? "Ein Riss, der sich bewegt" : "Riss im Bauteil", x: wie === "schlimmer" ? "Wird ein Riss breiter oder länger, arbeitet etwas im Gebäude. Das sollte fachlich beurteilt werden, bevor repariert wird." : "Viele Risse sind harmlose Putz- oder Schwindrisse. Ob Ihrer dazugehört, zeigen Verlauf, Lage und ob er sich verändert.", to: "gebaeudeschaeden", art: "ratgeber-risse-wand", urgent: wie === "schlimmer",
      tun: ["Rissenden mit Bleistift und Datum markieren", "Breite messen und den Riss mit Lineal fotografieren", "Messung nach einigen Wochen wiederholen, zum Beispiel mit dem Riss-Tagebuch"] };
  else if (was === "schimmel")
    r = { t: "Schimmel: Ursache klären", x: (wo === "fenster" || wo === "innen") ? "Schimmel an Fenstern, in Ecken oder hinter Möbeln entsteht oft an kühlen Stellen, an denen sich Raumfeuchte niederschlägt. Ob eine Wärmebrücke, das Lüften oder eindringende Feuchte die Ursache ist, lässt sich mit Messungen klären." : "Schimmel braucht dauerhafte Feuchte. Woher sie kommt, entscheidet über die richtige Sanierung.", to: "gebaeudeschaeden", art: "ratgeber-schimmel-wohnung", urgent: wie === "schlimmer",
      tun: ["Befall mit Datum fotografieren", "Luftfeuchte zwei bis vier Wochen protokollieren", "Kleine Flächen feucht entfernen, größere fachgerecht sanieren lassen"] };
  else if (wo === "keller" || was === "salz" || was === "geruch")
    r = { t: "Feuchte im Mauerwerk", x: "Feuchte Flecken, weiße Salzbeläge oder muffiger Geruch deuten auf Feuchte in der Wand hin. Typische Ursachen sind eine alte Abdichtung, aufsteigende Feuchte, Kondensat im Sommer oder eine Leckage.", to: "gebaeudeschaeden", art: "ratgeber-feuchter-keller", urgent: wie === "schlimmer",
      tun: ["Folientest machen: Alufolie zwei bis drei Tage auf die Wand kleben", "Im Sommer nur in kühlen Stunden lüften (Lüftungsrechner im Ratgeber)", "Vor einer Sanierung die Ursache messen lassen"] };
  else if (wo === "dach")
    r = { t: "Feuchte unter dem Dach", x: "Feuchte unter dem Dach kann von einer undichten Eindeckung, schadhaften Anschlüssen oder von Kondensat durch fehlende Luftdichtheit kommen. Mit Drohne und Wärmebild lässt sich das oft ohne Gerüst eingrenzen.", to: "gebaeudeschaeden", art: null, urgent: wie === "schlimmer",
      tun: ["Feuchte Stellen nach Regen und bei Frost beobachten", "Fotos vom Dachboden machen", "Keine Dämmung erneuern, bevor die Ursache klar ist"] };
  else if (was === "kalt")
    r = { t: "Wärmebrücke oder Undichtigkeit", x: "Kalte Stellen und Zugluft zeigen, wo Wärme verloren geht. Ein Wärmebild macht Wärmebrücken, Dämmlücken und undichte Anschlüsse sichtbar, am besten in der Heizperiode.", to: "thermografie", art: null, urgent: false,
      tun: ["Stellen notieren, an denen es zieht oder kalt ist", "Auf Kondenswasser und Schimmel an diesen Stellen achten", "Wärmebild in der Heizperiode aufnehmen lassen"] };
  else
    r = { t: "Feuchte an der Gebäudehülle", x: "Feuchte Stellen an Fassade, Fenstern oder Wänden können viele Ursachen haben, von Schlagregen über undichte Anschlüsse bis zu Kondensat. Eine Untersuchung vor Ort schafft Klarheit.", to: "gebaeudeschaeden", art: null, urgent: wie === "schlimmer",
      tun: ["Fotos mit Datum machen", "Beobachten, ob es nach Regen schlimmer wird", "Ursache klären lassen, bevor saniert wird"] };
  r.badge = r.urgent ? ["hoch", "Bitte nicht lange warten"] : wie === "wieder" ? ["mittel", "Ursache klären lassen"] : wie === "neu" ? ["niedrig", "Beobachten und dokumentieren"] : ["mittel", "Zeitnah ansehen lassen"];
  return r;
}
function initCheck(t) {
  let step = 0, ans = [];
  const label = (i, v) => CHECK_Q[i][1].find(o => o[0] === v)[1];
  const render = () => {
    if (step < 3) {
      const [q, opts] = CHECK_Q[step];
      t.innerHTML = `<div class="chk-top"><span class="kurz-k">Frage ${step + 1} von 3</span><div class="chk-bar"><i style="width:${(step + 1) / 3 * 100}%"></i></div></div>
        <h2>${q}</h2><div class="chk-opts">${opts.map(([v, l]) => `<button type="button" class="chk-opt" data-v="${v}">${l}</button>`).join("")}</div>
        ${step ? '<button type="button" class="chk-back" data-back>← Zurück</button>' : ""}`;
    } else {
      const r = checkResult(ans), l = LEISTUNGEN.find(x => x.slug === r.to), a = r.art && RATGEBER.find(x => x.slug === r.art), c = CTA[r.to], cl = CHECKLISTEN.find(x => x.to === r.to && (!r.art || x.art === r.art)) || null;
      const msg = `Schadens-Check: ${label(0, ans[0])} · ${label(1, ans[1])} · ${label(2, ans[2])}.\n\n`;
      t.innerHTML = `<div class="chk-top"><span class="kurz-k">Ihre erste Einordnung</span><span class="chk-badge ${r.badge[0]}">${r.badge[1]}</span></div>
        <h2>${r.t}</h2><p class="chk-sum">${label(0, ans[0])} · ${label(1, ans[1])} · ${label(2, ans[2])}</p><p>${r.x}</p>
        <h3>Was Sie jetzt tun können</h3><ul class="checks">${r.tun.map(x => `<li>${use("i-check")}<span>${x}</span></li>`).join("")}</ul>
        <div class="chk-act"><a class="btn btn--primary" href="#kontakt" data-thema="${r.to}" data-label="${c[0]}" data-msg="${msg.replace(/"/g, "&quot;")}">${c[0]} <span class="arrow">→</span></a>
        ${a ? `<a class="btn btn--outline" href="#${a.slug}">Ratgeber lesen</a>` : `<a class="btn btn--outline" href="#${l.slug}">Mehr zu ${l.title}</a>`}${cl ? clLink(cl, "btn btn--outline") : ""}</div>
        <p class="chk-note">Eine erste Orientierung, keine Ferndiagnose. Sicher beurteilen lässt sich ein Schaden erst vor Ort. <button type="button" class="chk-back" data-restart>Neu starten</button></p>`;
    }
  };
  t.addEventListener("click", e => {
    const o = e.target.closest(".chk-opt");
    if (o) { ans[step] = o.dataset.v; step++; render(); t.scrollIntoView({ behavior: "smooth", block: "start" }); return; }
    if (e.target.closest("[data-back]")) { step--; render(); }
    if (e.target.closest("[data-restart]")) { step = 0; ans = []; render(); }
  });
  render();
}

function setMeta(key, l) {
  const d = SEO[key] || SEO.start;
  document.title = d[0];
  let m = document.querySelector('meta[name="description"]');
  if (!m) { m = document.createElement("meta"); m.name = "description"; document.head.appendChild(m); }
  m.content = d[1];
  let ld = $id("ld-page");
  if (!ld) { ld = document.createElement("script"); ld.type = "application/ld+json"; ld.id = "ld-page"; document.body.appendChild(ld); }
  const strip = h => h.replace(/<[^>]+>/g, "").replace(/­/g, "");
  ld.textContent = l ? JSON.stringify({ "@context": "https://schema.org", "@graph": [
    { "@type": "Service", "name": strip(l.title), "serviceType": strip(l.title), "areaServed": TOWNS, "provider": { "@id": "https://bsv-niewerth.de/#buero" }, "description": d[1] },
    { "@type": "FAQPage", "mainEntity": l.faq.map(([q, a]) => ({ "@type": "Question", "name": q, "acceptedAnswer": { "@type": "Answer", "text": strip(a) } })) },
    { "@type": "BreadcrumbList", "itemListElement": [{ "@type": "ListItem", "position": 1, "name": "Start", "item": "https://bsv-niewerth.de/" }, { "@type": "ListItem", "position": 2, "name": "Leistungen", "item": "https://bsv-niewerth.de/leistungen/" }, { "@type": "ListItem", "position": 3, "name": strip(l.title) }] }
  ] }) : extraLd(key, d, strip);
}
function extraLd(key, d, strip) {
  const base = "https://bsv-niewerth.de/", bc = (items) => ({ "@type": "BreadcrumbList", "itemListElement": items.map(([n, u], i) => ({ "@type": "ListItem", "position": i + 1, "name": n, "item": base + u })) });
  const r = REGIONEN.find(x => x.slug === key), a = RATGEBER.find(x => x.slug === key);
  if (r) return JSON.stringify({ "@context": "https://schema.org", "@graph": [
    { "@type": "Service", "name": "Bausachverständiger " + r.name, "serviceType": "Bausachverständiger", "areaServed": r.orte.map(o => ({ "@type": "Place", "name": o })), "provider": { "@id": base + "#buero" }, "description": d[1] },
    { "@type": "FAQPage", "mainEntity": r.faq.map(([q, t]) => ({ "@type": "Question", "name": q, "acceptedAnswer": { "@type": "Answer", "text": strip(t) } })) },
    bc([["Start", ""], [r.name, r.slug + "/"]]) ] });
  const author = { "@type": "Person", "@id": base + "#andre", "name": "André Niewerth", "url": base + "ueber-mich/", "jobTitle": "Sachverständiger für Schäden an Gebäuden", "sameAs": ["https://www.certipedia.com/quality_marks/0217466933?locale=de"], "hasCredential": [{ "@type": "EducationalOccupationalCredential", "name": "Sachverständiger für Schäden an Gebäuden (persCert TÜV Rheinland)" }, { "@type": "EducationalOccupationalCredential", "name": "Maurer- und Stahlbetonbauermeister" }, { "@type": "EducationalOccupationalCredential", "name": "Geprüfter Betriebswirt (HwO)" }], "worksFor": { "@id": base + "#buero" } };
  const aurl = x => base + "ratgeber/" + x.slug.replace("ratgeber-", "") + "/";
  const iso = d => d.split(".").reverse().join("-");
  if (a) { const l = LEISTUNGEN.find(x => x.slug === a.to); return JSON.stringify({ "@context": "https://schema.org", "@graph": [
    { "@type": "Article", "@id": aurl(a) + "#artikel", "headline": a.h1, "description": d[1], "inLanguage": "de", "datePublished": a.pub || "2026-11-16", "dateModified": iso(RATGEBER_STAND), "author": author, "publisher": { "@id": base + "#buero" }, "image": base + "wp-content/themes/bsv-niewerth/assets/og-image.jpg", "mainEntityOfPage": aurl(a), "about": strip(l.title), "articleSection": "Ratgeber" },
    { "@type": "FAQPage", "mainEntity": a.faq.map(([q, t]) => ({ "@type": "Question", "name": q, "acceptedAnswer": { "@type": "Answer", "text": strip(t) } })) },
    bc([["Start", ""], ["Ratgeber", "ratgeber/"], [a.h1, "ratgeber/" + a.slug.replace("ratgeber-", "") + "/"]]) ] }); }
  if (key === "checklisten") return JSON.stringify({ "@context": "https://schema.org", "@graph": [
    { "@type": "CollectionPage", "name": "Kostenlose Checklisten zum Ausdrucken", "url": base + "checklisten/", "author": author, "mainEntity": { "@type": "ItemList", "itemListElement": CHECKLISTEN.map((c, i) => ({ "@type": "ListItem", "position": i + 1, "item": { "@type": "DigitalDocument", "name": c.title, "description": c.text, "encodingFormat": "application/pdf", "url": PDF_URL + c.file, "author": { "@id": base + "#andre" }, "isAccessibleForFree": true } })) } },
    bc([["Start", ""], ["Ratgeber", "ratgeber/"], ["Checklisten", "checklisten/"]]) ] });
  if (key === "schadens-check") return JSON.stringify({ "@context": "https://schema.org", "@graph": [
    { "@type": "WebPage", "name": "Schadens-Check", "url": base + "schadens-check/", "description": d[1], "provider": { "@id": base + "#buero" } },
    bc([["Start", ""], ["Schadens-Check", "schadens-check/"]]) ] });
  if (key === "ratgeber") return JSON.stringify({ "@context": "https://schema.org", "@graph": [
    { "@type": "CollectionPage", "name": "Ratgeber rund um Bauschäden", "url": base + "ratgeber/", "author": author, "mainEntity": { "@type": "ItemList", "itemListElement": RATGEBER.map((x, i) => ({ "@type": "ListItem", "position": i + 1, "url": aurl(x), "name": x.h1 })) } },
    bc([["Start", ""], ["Ratgeber", "ratgeber/"]]) ] });
  return "{}";
}

const tile = l => `<a class="tile" href="#${l.slug}">${ROOF}${ic(l.icon)}<h3>${l.title}</h3><p>${l.short}</p><span class="go">Mehr erfahren <span class="arrow">→</span></span></a>`;

function leistungPage(l) {
  const x = MEHR[l.slug];
  const others = LEISTUNGEN.filter(o => o !== l).map(o => `<a href="#${o.slug}">${ic(o.icon)}${o.title}</a>`).join("");
  return `
  <section class="page-hero">
    <svg class="bgroof" viewBox="0 0 600 260" aria-hidden="true"><path d="M10 250 L300 20 L590 250"/></svg>
    <div class="wrap">
      <div class="page-hero-copy">
        <div class="crumbs"><a href="#start">Start</a><span>/</span><a href="#leistungen">Leistungen</a><span>/</span><span>${l.title}</span></div>
        <h1>${SEO[l.slug][2]}</h1>
        ${x.tagline ? `<p class="tagline">${x.tagline}</p>` : ""}
        <p class="reach">${PIN}Kreis Borken, Münsterland und Ruhrgebiet</p>
        <p>${l.lead}</p>
        <div class="hero-actions"><a class="btn btn--primary" href="#kontakt" data-thema="${l.slug}">${CTA[l.slug][0]} <span class="arrow">→</span></a><a class="btn btn--outline-light" href="tel:+491796933684">${use("i-phone")}0179 6933684</a></div>
      </div>
      <div class="zmedia">
        <div class="dim"><i></i><span>${l.title}</span><i></i></div>
        <div class="photo photo--dark" data-photo="${l.slug}"><div class="cap">${use("i-photo")}${l.foto}</div></div>
      </div>
    </div>
  </section>
  ${x.quote ? `<section class="saying"><div class="wrap"><figure><blockquote>${x.quote[0]}</blockquote><figcaption>${x.quote[1]}</figcaption></figure></div></section>` : ""}
  <section class="section"><div class="wrap intro-grid">
    <div class="intro-text">${(!x.sections || x.keepIntro) ? `<div class="isec"><span class="kicker">Worum es geht</span>${x.intro.map((p, i) => i === 0 ? `<p class="first">${p}</p>` : `<p>${p}</p>`).join("")}</div>` : ""}${(x.sections || []).map(([h, ps]) => `<div class="isec">${h ? `<h2>${h}</h2>` : ""}${ps.map(p => Array.isArray(p) ? `<ul class="checks">${p.map(li => `<li>${use("i-check")}<span>${li}</span></li>`).join("")}</ul>` : `<p>${p}</p>`).join("")}</div>`).join("")}</div>
    <aside class="facts-box" aria-label="Auf einen Blick">
      <h3>Auf einen Blick</h3>
      <dl>
        <dt>Dauer</dt><dd>${x.eck[0]}</dd>
        <dt>Ergebnis</dt><dd>${x.eck[1]}</dd>
        <dt>Ortstermin</dt><dd>kurzfristig nach Absprache</dd>
        <dt>Einsatzgebiet</dt><dd>Kreis Borken, Münsterland und Ruhrgebiet</dd>
      </dl>
      <a class="btn btn--primary" href="#kontakt" data-thema="${l.slug}">${CTA[l.slug][0]}</a>
    </aside>
  </div></section>
  <section class="section section--soft"><div class="wrap proto-wrap">
    <div class="head proto-head"><span class="kicker">Was ich prüfe</span><h2>Darauf achte ich</h2><p>Bei jedem Ortstermin arbeite ich die wichtigen Punkte systematisch ab und halte sie im Protokoll fest. So geht nichts verloren, und Sie können jeden Befund nachvollziehen.</p></div>
    <div class="proto">
      <div class="proto-top"><span>Prüfprotokoll</span><b>${l.title}</b><small>BSV Niewerth · Bau-Sachverständigenbüro</small></div>
      <ol class="proto-list">${x.pruefe.map(([t, d], i) => `<li><span class="box">${use("i-check")}</span><div><b>${t}</b><span>${d}</span></div></li>`).join("")}</ol>
    </div>
  </div></section>
  <section class="section"><div class="wrap zig"><div class="zrow">
    <div class="zcopy"><span class="kicker">Typische Anlässe</span><h2>Wann Sie mich brauchen</h2>
      <ul class="checks">${l.anlaesse.map(a => `<li>${use("i-check")}<span>${a}</span></li>`).join("")}</ul></div>
    <div class="zmedia"><div class="dim"><i></i><span>Aus der Praxis</span><i></i></div><div class="photo" data-photo="${l.slug}-2"><div class="cap">${use("i-photo")}Zweites Foto aus der Praxis, z. B. eine Detailaufnahme</div></div></div>
  </div></div></section>
  <section class="section section--navy"><div class="wrap">
    <div class="head"><span class="kicker">Ablauf</span><h2>So gehe ich vor</h2></div>
    <ol class="tape">${l.vorgehen.map(([t, d], i) => `<li><span class="t">${String(i + 1).padStart(2, "0")}</span><h3>${t}</h3><p>${d}</p></li>`).join("")}</ol>
  </div></section>
  <section class="section section--soft"><div class="wrap">
    <div class="head"><span class="kicker">Ihr Ergebnis</span><h2>Was Sie bekommen</h2></div>
    <div class="results">${l.ergebnis.map(([i, t, d]) => `<div class="result">${use(i)}<h3>${t}</h3><p>${d}</p></div>`).join("")}</div>
  </div></section>
  <section class="section"><div class="wrap cost">
    <div><span class="kicker">Kosten</span><h2>Was kostet das?</h2></div>
    <div class="cost-text"><p>${x.kosten}</p><a class="btn btn--outline" href="#kontakt" data-thema="${l.slug}">Unverbindlich anfragen <span class="arrow">→</span></a></div>
  </div></section>
  <section class="section section--soft"><div class="wrap faq-grid">
    <div class="head" style="margin:0;align-content:start"><span class="kicker">Häufige Fragen</span><h2>Gut zu wissen</h2><p>Ihre Frage ist nicht dabei? Rufen Sie mich einfach an.</p></div>
    <div class="faq">${l.faq.map(([q, a], i) => `<details${i === 0 ? " open" : ""}><summary>${q}</summary><p>${a}</p></details>`).join("")}</div>
  </div></section>
  ${casesFor(l.slug).length ? `<section class="section"><div class="wrap"><div class="head"><span class="kicker">Aus der Praxis</span><h2>Ein Fall aus meiner Arbeit</h2></div><div class="cases">${casesHtml(casesFor(l.slug), false)}</div></div></section>` : ""}
  <section class="section" style="padding-block:64px"><div class="wrap more-grid">
    <div><h3>Einsatzgebiet</h3><p class="area-line">${TOWNS.join(" · ")}, das übrige Münsterland und das Ruhrgebiet</p><div class="other">${REGIONEN.map(r => `<a href="#${r.slug}">${PIN}${r.name}</a>`).join("")}</div>${RATGEBER.filter(a => a.to === l.slug).length ? `<h3 style="margin-top:12px">Passend dazu im Ratgeber</h3><ul class="rg-links">${RATGEBER.filter(a => a.to === l.slug).map(a => `<li><a href="#${a.slug}">${a.h1} →</a></li>`).join("")}</ul>` : ""}${clFor("to", l.slug).length ? `<h3 style="margin-top:12px">Kostenlose Checklisten</h3><ul class="rg-links">${clFor("to", l.slug).map(c => `<li><a href="${PDF_URL}${c.file}" download>${c.title} (PDF) →</a></li>`).join("")}</ul>` : ""}</div>
    <div><h3>Weitere Leistungen</h3><div class="other">${others}</div></div>
  </div></section>`;
}

function casesFor(slug) { return PRAXIS.filter(c => c.to === slug); }
function casesHtml(list, withLink = true) {
  return list.map(c => {
    const l = LEISTUNGEN.find(x => x.slug === c.to);
    return `<article class="case">${c.foto ? `<div class="case-photo" role="img" aria-label="${c.h}" style="background-image:url('${c.foto}')"></div>` : ""}<div class="case-body">
      <span class="case-meta">${l ? l.title : ""}${c.ort ? " · " + c.ort : ""}</span><h3>${c.h}</h3>
      <ol class="case-steps"><li><b>Ausgangslage</b><span>${c.aus}</span></li><li><b>Untersuchung</b><span>${c.unt}</span></li><li><b>Ergebnis</b><span>${c.erg}</span></li></ol>
      ${withLink && l ? `<a class="case-link" href="#${l.slug}">Mehr zu ${l.title} →</a>` : ""}</div></article>`;
  }).join("");
}
function renderPraxis() {
  const sec = $id("praxis");
  sec.hidden = !PRAXIS.length;
  $id("cases").innerHTML = casesHtml(PRAXIS.slice(0, 4));
}
renderPraxis();
if (!$id("rg-list").children.length) $id("rg-list").innerHTML = RATGEBER.map(artCard).join("");
renderChecklisten();
if (!$id("rg-home").children.length) $id("rg-home").innerHTML = RATGEBER.slice(0, 3).map(artCard).join("");
if (!$id("needs").children.length) $id("needs").innerHTML = NEEDS.map(n => {
  const l = LEISTUNGEN.find(x => x.slug === n.to);
  return `<article class="need">${ic(n.icon)}<h3>${n.h}</h3><p>${n.t}</p><div class="need-act"><a class="btn btn--primary" href="#kontakt" data-thema="${n.to}" data-label="${n.cta}" data-hint="${n.hint}">${n.cta} <span class="arrow">→</span></a><a class="need-more" href="#${n.to}">Mehr zu ${l.title} →</a></div></article>`;
}).join("");

const DOCS_TILE = `<div class="tile tile--docs">${ic("gutachten")}<h3>Benötigte Unterlagen</h3><p>Je mehr Informationen Sie mir zur Verfügung stellen, desto fundierter kann ich den Schaden einschätzen und beurteilen. Hierzu gehören:</p><ul class="docs-mini"><li>Grundrisse, Ansichten und Schnitte</li><li>Baubeschreibung</li><li>Energieausweis</li><li>Baugrundgutachten</li><li>Fotos</li></ul><p class="docs-note">Die Unterlagen sind keine Voraussetzung, können aber für eine genauere Analyse durchaus hilfreich sein.</p></div>`;
if (!$id("home-tiles").children.length) $id("home-tiles").innerHTML = LEISTUNGEN.map(tile).join("") + DOCS_TILE;
if (!$id("all-tiles").children.length) $id("all-tiles").innerHTML = LEISTUNGEN.map(tile).join("") + DOCS_TILE;
if (!$id("dd-list").children.length) $id("dd-list").innerHTML = LEISTUNGEN.map(l => `<a href="#${l.slug}">${ic(l.icon)}${l.title}</a>`).join("") + `<a class="all" href="#leistungen">Alle Leistungen im Überblick →</a>`;
if (!$id("m-list").children.length) $id("m-list").innerHTML = LEISTUNGEN.map(l => `<a href="#${l.slug}">${ic(l.icon)}${l.title}</a>`).join("") + `<a class="all" href="#leistungen">Alle Leistungen im Überblick</a>`;
if (!$id("f-list").children.length) $id("f-list").innerHTML = LEISTUNGEN.map(l => `<li><a href="#${l.slug}">${l.title}</a></li>`).join("");
if (!$id("f-chips").children.length) $id("f-chips").innerHTML = [...LEISTUNGEN.map(l => [l.title, l.slug]), ["Sonstiges", "sonstiges"]].map(([t, sl], i) => `<label><input type="radio" name="thema" id="f-t${i}" data-slug="${sl}" value="${t.replace(/\u00ad|­/g, "")}"${i === 0 ? " checked" : ""}><span>${t}</span></label>`).join("");

/* Menü */
const mnav = $id("mnav"), burger = $id("burger");
function closeMenu() { mnav.hidden = true; burger.setAttribute("aria-expanded", "false"); document.body.style.overflow = ""; }
burger.addEventListener("click", () => { mnav.hidden = false; burger.setAttribute("aria-expanded", "true"); document.body.style.overflow = "hidden"; });
$id("mclose").addEventListener("click", closeMenu);
mnav.addEventListener("click", e => { if (e.target.closest("a")) closeMenu(); });

/* Ratgeber: Inhaltsverzeichnis sanft anspringen (ohne Adresse zu ändern) und Checkliste drucken */
document.addEventListener("click", e => {
  const t = e.target.closest("a[data-toc]");
  if (t) { e.preventDefault(); e.stopPropagation(); const el = $id(t.getAttribute("href").slice(1)); if (el) el.scrollIntoView({ behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" }); return; }
  if (e.target.closest("[data-print]")) window.print();
}, true);

/* Vergrößerte Ansicht für Urkunden */
document.addEventListener("click", e => {
  const z = $id("zoom"), t = e.target.closest("[data-zoom]");
  if (t) { z.querySelector("img").src = t.dataset.zoom; z.hidden = false; return; }
  if (!z.hidden && (e.target === z || e.target.closest(".zoom-x"))) z.hidden = true;
});
addEventListener("keydown", e => { if (e.key === "Escape") $id("zoom").hidden = true; });

/* ---------- Bewegung ---------- */
const REDUCED = matchMedia("(prefers-reduced-motion: reduce)").matches;

/* Logo-Intro beenden, danach baut sich die Startseite auf */
(function () {
  const root = document.documentElement, intro = $id("bsv-intro");
  const go = () => root.classList.add("hero-go");
  if (!root.classList.contains("intro-on")) { requestAnimationFrame(() => requestAnimationFrame(go)); return; }
  let ended = false;
  const end = () => {
    if (ended) return; ended = true; intro.classList.add("done"); root.classList.remove("intro-on", "intro-play"); go();
    setTimeout(() => (window.requestIdleCallback || (f => setTimeout(f, 0)))(() => applyPhotos(document), { timeout: 1500 }), 1300);
  };
  intro.addEventListener("click", end);
  $id("bi-skip").addEventListener("click", end);
  intro.addEventListener("animationend", e => { if (e.target === intro && e.animationName === "bi-out") end(); });
  const play = () => { if (root.classList.contains("intro-play")) return; requestAnimationFrame(() => requestAnimationFrame(() => { root.classList.add("intro-play"); setTimeout(end, 3800); })); };
  (document.fonts && document.fonts.ready ? document.fonts.ready : Promise.resolve()).then(play);
  setTimeout(play, 900);
})();

/* Hauptüberschrift in Wörter zerlegen */
(function () {
  const h1 = document.querySelector(".hero h1"); if (!h1) return;
  let i = 0;
  h1.querySelectorAll(".hl, .blue").forEach(part => {
    part.innerHTML = part.textContent.trim().split(/\s+/).map(w => `<span class="w"><span style="--i:${i++}">${w}</span></span>`).join(" ");
  });
  [...document.querySelector(".hero .hero-copy").children].forEach((el, n) => { if (el.tagName !== "H1") el.style.setProperty("--i", n); });
})();

/* Abschnitte beim Scrollen einblenden */
const REVEAL = ".head, .tile, .zcopy, .tape > li, .result, .proto, .faq details, .checks li, .facts-box, .intro-text .isec, .intro-text > p, .statement blockquote, .statement-text, .statement .sig, .towns li, .area-copy, .regions, .qual, .ccard, .cost > div, .more-grid > div, .contact-band .wrap > *, .finder-copy > *, .prose > *";
const io = "IntersectionObserver" in window ? new IntersectionObserver(es => es.forEach(e => {
  if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); }
}), { rootMargin: "0px 0px -8% 0px", threshold: .08 }) : null;
function initTools(scope) {
  scope.querySelectorAll('[data-tool="lueften"]').forEach(t => {
    if (t.dataset.ready) return; t.dataset.ready = "1";
    const v = n => parseFloat(String(t.querySelector(`[name="${n}"]`).value).replace(",", "."));
    const sat = T => 6.112 * Math.exp(17.67 * T / (T + 243.5));          // Sättigungsdampfdruck in hPa
    const abs = (T, H) => sat(T) * H / 100 * 216.74 / (273.15 + T);     // absolute Feuchte in g/m³
    const dew = (T, H) => { const g = Math.log(H / 100) + 17.67 * T / (T + 243.5); return 243.5 * g / (17.67 - g); };
    const f = x => x.toFixed(1).replace(".", ",");
    const calc = () => {
      const ti = v("ti"), hi = v("hi"), ta = v("ta"), ha = v("ha"), o = t.querySelector(".tool-out");
      if ([ti, hi, ta, ha].some(isNaN) || hi <= 0 || ha <= 0 || hi > 100 || ha > 100) { o.className = "tool-out"; o.innerHTML = "Bitte alle vier Werte eintragen."; return; }
      const ai = abs(ti, hi), aa = abs(ta, ha), td = dew(ta, ha);
      let cls, msg;
      if (aa <= ai - 1) { cls = "ok"; msg = "<b>Jetzt lüften lohnt sich.</b> Die Außenluft enthält weniger Wasser als die Kellerluft und nimmt beim Lüften Feuchte mit hinaus."; }
      else if (aa < ai) { cls = "mid"; msg = "<b>Lüften bringt gerade nur wenig.</b> Innen und außen ist kaum ein Unterschied. Warten Sie lieber auf kühlere Stunden."; }
      else { cls = "no"; msg = "<b>Fenster lieber geschlossen lassen.</b> Die Außenluft würde mehr Feuchte hereinbringen, als sie hinausträgt." + (td > ti - 1 ? ` Ihr Taupunkt liegt bei ${f(td)} °C. An Kellerwänden, die kühler sind, schlägt sich Wasser nieder.` : ""); }
      o.className = "tool-out " + cls;
      o.innerHTML = `${msg}<span>Wasser in der Luft: draußen ${f(aa)} g/m³ · im Keller ${f(ai)} g/m³</span>`;
    };
    t.addEventListener("input", calc); calc();
  });
}
function initRisse(t) {
  const KEY = "bsvRisse", f = new Intl.DateTimeFormat("de-DE", { day: "2-digit", month: "2-digit", year: "numeric" });
  const load = () => { try { return JSON.parse(localStorage.getItem(KEY)) || []; } catch (_) { return []; } };
  const save = d => { try { localStorage.setItem(KEY, JSON.stringify(d)); } catch (_) {} };
  const mm = x => x.toFixed(2).replace(".", ",");
  const dt = d => f.format(new Date(d + "T12:00:00"));
  const esc = x => String(x).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
  let data = load();
  const q = n => t.querySelector(`[name="${n}"]`);
  q("d").value = new Date().toISOString().slice(0, 10);
  const render = () => {
    const by = {}; data.forEach((e, i) => (by[e.o] = by[e.o] || []).push({ ...e, i }));
    const list = t.querySelector(".rt-list"), send = t.querySelector('[data-rt="send"]');
    t.querySelector("#rt-orte").innerHTML = Object.keys(by).map(o => `<option value="${esc(o)}">`).join("");
    t.querySelector(".rt-actions").hidden = !data.length;
    if (!data.length) { list.innerHTML = '<p class="rt-empty">Noch keine Einträge. Tipp: Messen Sie immer an derselben markierten Stelle.</p>'; return; }
    let txt = "Mein Riss-Tagebuch:\n";
    list.innerHTML = Object.entries(by).map(([o, es]) => {
      es.sort((a, b) => a.d.localeCompare(b.d));
      const first = es[0], last = es[es.length - 1], delta = last.b - first.b;
      let cls = "", trend = "Erste Messung. Wiederholen Sie sie in einigen Wochen.";
      if (es.length > 1) {
        if (delta >= 0.05) { cls = "up"; trend = `Seit ${dt(first.d)} um ${mm(delta)} mm breiter geworden. Lassen Sie den Riss fachlich beurteilen.`; }
        else if (delta <= -0.05) { trend = `Seit ${dt(first.d)} um ${mm(-delta)} mm schmaler gemessen. Prüfen Sie, ob immer an derselben Stelle gemessen wurde.`; }
        else { cls = "ok"; trend = `Seit ${dt(first.d)} unverändert.`; }
      }
      txt += `\n${o}:\n` + es.map(e => `  ${dt(e.d)}: ${mm(e.b)} mm`).join("\n") + "\n";
      const max = Math.max(...es.map(e => e.b), 0.1), w = 220, h = 46;
      const pts = es.map((e, k) => `${es.length > 1 ? (k / (es.length - 1) * w).toFixed(1) : w / 2},${(h - 4 - e.b / max * (h - 10)).toFixed(1)}`).join(" ");
      return `<div class="rt-item ${cls}"><div class="rt-head"><b>${esc(o)}</b><svg viewBox="0 0 ${w} ${h}" aria-hidden="true"><polyline points="${pts}"/></svg></div><p class="rt-trend">${trend}</p><ul>${es.map(e => `<li><span>${dt(e.d)}</span><span>${mm(e.b)} mm</span><button type="button" data-rt="del" data-i="${e.i}" aria-label="Eintrag löschen">×</button></li>`).join("")}</ul></div>`;
    }).join("");
    send.dataset.msg = txt + "\nBitte um eine Einschätzung.";
  };
  t.addEventListener("click", e => {
    const b = e.target.closest("[data-rt]"); if (!b) return;
    const a = b.dataset.rt;
    if (a === "add") {
      const d = q("d").value, o = q("o").value.trim(), w = parseFloat(String(q("b").value).replace(",", "."));
      if (!d || !o || isNaN(w) || w < 0) { (!o ? q("o") : !d ? q("d") : q("b")).focus(); return; }
      data.push({ d, o, b: w }); save(data); q("b").value = ""; render();
    } else if (a === "del") { data.splice(+b.dataset.i, 1); save(data); render(); }
    else if (a === "clear") { if (confirm("Alle Einträge im Riss-Tagebuch löschen?")) { data = []; save(data); render(); } }
    else if (a === "print") { document.body.classList.add("print-tool"); window.print(); setTimeout(() => document.body.classList.remove("print-tool"), 500); }
  });
  render();
}
function applyReveal(scope) {
  initTools(scope);
  scope.querySelectorAll('[data-tool="risse"]').forEach(t => { if (!t.dataset.ready) { t.dataset.ready = "1"; initRisse(t); } });
  scope.querySelectorAll('[data-tool="check"]').forEach(t => { if (!t.dataset.ready) { t.dataset.ready = "1"; initCheck(t); } });
  if (REDUCED || !io) return;
  scope.querySelectorAll(REVEAL).forEach(el => {
    if (el.classList.contains("reveal")) return;
    const sib = el.parentElement ? [...el.parentElement.children].indexOf(el) : 0;
    el.style.setProperty("--d", (Math.min(sib, 6) * .08) + "s");
    el.classList.add("reveal"); io.observe(el);
  });
  scope.querySelectorAll(".zmedia .photo").forEach(el => { if (!el.classList.contains("reveal-img")) { el.classList.add("reveal-img"); io.observe(el.parentElement); } });
  scope.querySelectorAll(".finder, .map-wrap").forEach(el => io.observe(el));
}
if (REDUCED || !io) document.querySelectorAll(".finder, .map-wrap").forEach(el => el.classList.add("in"));

/* Kopfzeile beim Scrollen */
(function () {
  const h = document.querySelector(".site-header");
  const on = () => h.classList.toggle("scrolled", scrollY > 10);
  addEventListener("scroll", on, { passive: true }); on();
})();

/* Schadens-Finder */
(function () {
  const SPOTS = [
    { k: "Dach", cta: "Dach prüfen lassen", hint: "z. B. Feuchte Stellen unter der Dachschräge nach Starkregen", x: 50, y: 25, h: "Dach und Dachstuhl", t: "Feuchte unter dem Dach, Schäden an Eindeckung oder Holz und fehlende Dämmung. Mit der Drohne sehe ich mir das Dach von oben an, Wärmebilder zeigen, wo Wärme und Wasser ihren Weg finden.", to: "thermografie", l: "Zur Bau-Thermografie" },
    { k: "Fenster", cta: "Ursache klären lassen", hint: "z. B. Kondenswasser und Schimmel am Fensterrahmen im Kinderzimmer", x: 66.6, y: 41.3, h: "Fenster und Anschlüsse", t: "Kalte Laibungen, Kondenswasser und Schimmel am Rahmen entstehen oft an undichten Anschlüssen oder an Wärmebrücken.", to: "gebaeudeschaeden", l: "Zu Gebäudeschäden" },
    { k: "Bad", cta: "Leck orten lassen", hint: "z. B. Wasserfleck an der Decke unter dem Bad, Wasserzähler läuft", x: 39.5, y: 58, h: "Bad und Leitungen", t: "Ein Wasserfleck an der Decke darunter oder ein feuchter Boden deutet auf eine Leckage hin. Ich finde die Stelle, bevor großflächig geöffnet wird.", to: "leckageortung", l: "Zur Leckageortung" },
    { k: "Wände", cta: "Riss beurteilen lassen", hint: "z. B. Schräger Riss über dem Fenster, seit einem Jahr breiter geworden", x: 23.2, y: 55.5, h: "Risse in den Wänden", t: "Ob harmloser Putzriss oder Setzung: Ich bewerte Verlauf, Breite und Ursache und sage Ihnen, ob Handlungsbedarf besteht.", to: "gebaeudeschaeden", l: "Zu Gebäudeschäden", left: true },
    { k: "Keller", cta: "Feuchte einschätzen lassen", hint: "z. B. Feuchte Kellerwand mit weißen Ausblühungen, muffiger Geruch", x: 31, y: 84, h: "Feuchter Keller", t: "Muffiger Geruch, Salzausblühungen oder nasse Wände: Ich messe die Feuchte und finde heraus, ob Abdichtung, Kondensat oder aufsteigende Feuchte dahintersteckt.", to: "gebaeudeschaeden", l: "Zu Gebäudeschäden" }
  ];
  const box = $id("hotspots"), card = $id("finder-card");
  box.innerHTML = SPOTS.map((s, i) => `<button class="hs${s.left ? " hs--l" : ""}" type="button" aria-pressed="false" data-i="${i}" style="--x:${s.x}%;--y:${s.y}%;--i:${i}"><span class="pt"></span><span class="tx">${s.k}</span></button>`).join("");
  box.addEventListener("click", e => {
    const b = e.target.closest(".hs"); if (!b) return;
    const s = SPOTS[b.dataset.i];
    box.querySelectorAll(".hs").forEach(x => x.setAttribute("aria-pressed", String(x === b)));
    card.innerHTML = `<span class="fc-k">${s.k}</span><h3>${s.h}</h3><p>${s.t}</p><div class="fc-actions"><a class="btn btn--primary" href="#kontakt" data-thema="${s.to}" data-label="${s.cta}" data-hint="${s.hint}">${s.cta} <span class="arrow">→</span></a><a class="fc-more" href="#${s.to}">${s.l} →</a></div>`;
    card.classList.remove("swap"); void card.offsetWidth; card.classList.add("swap");
    // Handy/Tablet: Karte liegt unter dem Haus. Ist sie nicht ganz sichtbar, sanft hinscrollen.
    if (matchMedia("(max-width: 900px)").matches) {
      const r = card.getBoundingClientRect(), bar = document.querySelector(".callbar"), barH = bar && getComputedStyle(bar).display !== "none" ? bar.offsetHeight : 0;
      if (r.bottom > innerHeight - barH - 8) card.scrollIntoView({ behavior: "smooth", block: "end" });
    }
  });
})();

/* Beispielfotos von Unsplash (bis Andrés eigene Fotos fertig sind) */
const PHOTOS = {"hero": {"src": "/wp-content/themes/bsv-niewerth/assets/img/ad57e7bbd641.webp", "by": "Yanhao Fang", "link": "https://unsplash.com/@alamanga?utm_source=bsv_niewerth_entwurf&utm_medium=referral", "people": false, "alt": "A red brick building with windows and a clock"}, "z-ortstermin": {"src": "/wp-content/themes/bsv-niewerth/assets/img/dd884c04fc85.webp", "by": "Kacper G", "link": "https://unsplash.com/@aucoeurdumonstre?utm_source=bsv_niewerth_entwurf&utm_medium=referral", "people": false, "alt": "Old white building wall with windows and small white flowers"}, "z-ursache": {"src": "/wp-content/themes/bsv-niewerth/assets/img/34d3a5d9567c.webp", "by": "Jon Moore", "link": "https://unsplash.com/@thejmoore?utm_source=bsv_niewerth_entwurf&utm_medium=referral", "people": false, "alt": "brown and gray brick wall"}, "z-baustelle": {"src": "/wp-content/themes/bsv-niewerth/assets/img/30b1c2f12c89.webp", "by": "Flow Clark", "link": "https://unsplash.com/@flowclark?utm_source=bsv_niewerth_entwurf&utm_medium=referral", "people": false, "alt": "gray concrete wall during daytime"}, "z-mess": {"src": "/wp-content/themes/bsv-niewerth/assets/img/959ed172179e.webp", "by": "rawkkim", "link": "https://unsplash.com/@rawkkim?utm_source=bsv_niewerth_entwurf&utm_medium=referral", "people": false, "alt": "A camera is set up to take a picture of a house"}, "gebaeudeschaeden": {"src": "/wp-content/themes/bsv-niewerth/assets/img/37d9563c3d9b.webp", "by": "Krakograff Textures", "link": "https://unsplash.com/@krakograff?utm_source=bsv_niewerth_entwurf&utm_medium=referral", "people": false, "alt": "map"}, "gebaeudeschaeden-2": {"src": "/wp-content/themes/bsv-niewerth/assets/img/e3a9e8e6542a.webp", "by": "Hydra 4x", "link": "https://unsplash.com/@hydra4x?utm_source=bsv_niewerth_entwurf&utm_medium=referral", "people": false, "alt": "a wall that has some dirt on it"}, "hauskaufberatung": {"src": "/wp-content/themes/bsv-niewerth/assets/img/1599099f68d8.webp", "by": "Chris Weiher", "link": "https://unsplash.com/@chrisvomradio?utm_source=bsv_niewerth_entwurf&utm_medium=referral", "people": false, "alt": "a house with a large hedge in front of it"}, "hauskaufberatung-2": {"src": "/wp-content/themes/bsv-niewerth/assets/img/66efb4e2e9b6.webp", "by": "Ibrahim Rifath", "link": "https://unsplash.com/@ripey__?utm_source=bsv_niewerth_entwurf&utm_medium=referral", "people": false, "alt": "white Volkswagen Jetta parked beside house"}, "gutachten": {"src": "/wp-content/themes/bsv-niewerth/assets/img/855c015b2b5b.webp", "by": "2H Media", "link": "https://unsplash.com/@2hmedia?utm_source=bsv_niewerth_entwurf&utm_medium=referral", "people": false, "alt": "a pen sitting on top of a pile of papers"}, "gutachten-2": {"src": "/wp-content/themes/bsv-niewerth/assets/img/9032acd1a27f.webp", "by": "Tierra Mallorca", "link": "https://unsplash.com/@tierramallorca?utm_source=bsv_niewerth_entwurf&utm_medium=referral", "people": false, "alt": "white and red wooden house beside grey framed magnifying glass"}, "bauueberwachung": {"src": "/wp-content/themes/bsv-niewerth/assets/img/29572d8b29ae.webp", "by": "Troy Mortier", "link": "https://unsplash.com/@troyscanon?utm_source=bsv_niewerth_entwurf&utm_medium=referral", "people": false, "alt": "Wooden house frame under construction behind a fence"}, "bauueberwachung-2": {"src": "/wp-content/themes/bsv-niewerth/assets/img/3df24a8974e8.webp", "by": "Iain", "link": "https://unsplash.com/@photoken123?utm_source=bsv_niewerth_entwurf&utm_medium=referral", "people": false, "alt": "an aerial view of a building being constructed"}, "schlichtung": {"src": "/wp-content/themes/bsv-niewerth/assets/img/2f27fca757ad.webp", "by": "Brett Jordan", "link": "https://unsplash.com/@brett_jordan?utm_source=bsv_niewerth_entwurf&utm_medium=referral", "people": false, "alt": "brown brick building during daytime"}, "schlichtung-2": {"src": "/wp-content/themes/bsv-niewerth/assets/img/741b6ef6d20d.webp", "by": "Marek Studzinski", "link": "https://unsplash.com/@jccards?utm_source=bsv_niewerth_entwurf&utm_medium=referral", "people": false, "alt": "A ruler and a pencil laying on the floor"}, "energieberatung": {"src": "/wp-content/themes/bsv-niewerth/assets/img/5bcbfd9d4322.webp", "by": "Troy Mortier", "link": "https://unsplash.com/@troyscanon?utm_source=bsv_niewerth_entwurf&utm_medium=referral", "people": false, "alt": "Construction debris piled in front of a brick house"}, "energieberatung-2": {"src": "/wp-content/themes/bsv-niewerth/assets/img/dd884c04fc85.webp", "by": "Kacper G", "link": "https://unsplash.com/@aucoeurdumonstre?utm_source=bsv_niewerth_entwurf&utm_medium=referral", "people": false, "alt": "Old white building wall with windows and small white flowers"}, "leckageortung": {"src": "/wp-content/themes/bsv-niewerth/assets/img/fe15d994c9d2.webp", "by": "Brett Jordan", "link": "https://unsplash.com/@brett_jordan?utm_source=bsv_niewerth_entwurf&utm_medium=referral", "people": false, "alt": "A room with a ceiling that has been torn off"}, "leckageortung-2": {"src": "/wp-content/themes/bsv-niewerth/assets/img/07d289b6bffe.webp", "by": "Krakograff Textures", "link": "https://unsplash.com/@krakograff?utm_source=bsv_niewerth_entwurf&utm_medium=referral", "people": false, "alt": "A wall that has some paint on it"}, "thermografie": {"src": "/wp-content/themes/bsv-niewerth/assets/img/959ed172179e.webp", "by": "rawkkim", "link": "https://unsplash.com/@rawkkim?utm_source=bsv_niewerth_entwurf&utm_medium=referral", "people": false, "alt": "A camera is set up to take a picture of a house"}, "thermografie-2": {"src": "/wp-content/themes/bsv-niewerth/assets/img/fdb2bebe384c.webp", "by": "Maksym Diachenko", "link": "https://unsplash.com/@photofixation?utm_source=bsv_niewerth_entwurf&utm_medium=referral", "people": false, "alt": "man in black jacket walking on sidewalk during night time"}};
const UNSPLASH = "https://unsplash.com/?utm_source=bsv_niewerth_entwurf&utm_medium=referral";
const creditHtml = f => `Beispielfoto · <a href="${f.link}" target="_blank" rel="noopener">${f.by}</a> / <a href="${UNSPLASH}" target="_blank" rel="noopener">Unsplash</a>`;
function applyPhotos(scope, heroOnly) {
  scope.querySelectorAll(heroOnly ? ".hero-photo[data-photo]" : "[data-photo]").forEach(el => {
    const f = PHOTOS[el.dataset.photo]; if (!f || el.dataset.done) return;
    el.dataset.done = "1";
    el.style.backgroundImage = `url("${f.src}")`;
    if (el.classList.contains("hero-photo")) return;
    el.classList.add("has-img"); el.setAttribute("role", "img"); el.setAttribute("aria-label", "Beispielfoto: " + (f.alt || ""));
  });
}
applyPhotos(document, document.documentElement.classList.contains("intro-on"));

/* Situationsbezogene Schaltflächen: Anliegen ins Formular übernehmen */
let pendingAnliegen = null;
const MSG_DEFAULT = "z. B. Feuchter Fleck an der Kellerwand seit dem Frühjahr, Baujahr 1978";
function applyAnliegen() {
  const a = pendingAnliegen; pendingAnliegen = null;
  const h = $id("f-h"), anl = $id("f-anl"), msg = $id("f-msg");
  if (!a) { h.textContent = "Ihre Anfrage"; anl.classList.remove("on"); msg.placeholder = MSG_DEFAULT; return false; }
  const c = CTA[a.thema] || [];
  h.textContent = a.label || c[0] || "Ihre Anfrage";
  anl.classList.add("on");
  msg.placeholder = a.hint || c[3] || MSG_DEFAULT;
  if (a.msg) msg.value = a.msg;
  const r = document.querySelector(`#f-chips input[data-slug="${a.thema}"]`); if (r) r.checked = true;
  return true;
}
document.addEventListener("click", e => {
  const a = e.target.closest("a[data-thema]"); if (!a) { if (e.target.closest('a[href="#kontakt"], a[href$="/kontakt/"]')) { pendingAnliegen = null; try { sessionStorage.removeItem("bsvAnliegen"); } catch (_) {} } return; }
  pendingAnliegen = { thema: a.dataset.thema, label: a.dataset.label, hint: a.dataset.hint, msg: a.dataset.msg };
  try { sessionStorage.setItem("bsvAnliegen", JSON.stringify(pendingAnliegen)); } catch (_) {}
  if (BSV.route === "kontakt") { e.preventDefault(); e.stopPropagation(); applyAnliegen(); $id("kontaktformular").scrollIntoView({ behavior: REDUCED ? "auto" : "smooth" }); }
}, true);
/* Kontaktband passt sich der Leistungsseite an */
const KB = { h: "Klarheit beginnt mit einem Gespräch.", p: "Schildern Sie mir Ihr Anliegen. Ich freue mich auf Ihre Anfrage.", b: "Anfrage senden", s: "info@bsv-niewerth.de" };
function setKontaktband(slug) {
  const c = slug && CTA[slug], cta = $id("kb-cta");
  $id("kb-h").textContent = c ? c[1] : KB.h;
  $id("kb-p").textContent = c ? c[2] : KB.p;
  $id("kb-b").textContent = c ? c[0] : KB.b;
  $id("kb-s").textContent = c ? "Unverbindlich, gerne mit Fotos" : KB.s;
  if (c) cta.dataset.thema = slug; else delete cta.dataset.thema;
}
/* Seitenwechsel in WordPress: Vorhang, dann echte Seite laden */
(function () {
  const c = $id("curtain"), root = document.documentElement, U = BSV.urls;
  const fix = scope => scope.querySelectorAll && scope.querySelectorAll('a[href^="#"]').forEach(a => {
    const k = a.getAttribute("href").slice(1); if (U[k]) a.setAttribute("href", U[k]);
  });
  fix(document);
  new MutationObserver(ms => ms.forEach(m => fix(m.target))).observe(document.body, { childList: true, subtree: true });
  if (root.classList.contains("cu-arrive")) requestAnimationFrame(() => requestAnimationFrame(() => {
    root.classList.remove("cu-arrive"); c.classList.add("leave"); setTimeout(() => c.classList.remove("leave"), 1100);
  }));
  document.addEventListener("click", e => {
    if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    const a = e.target.closest("a[href]"); if (!a || a.target || a.hasAttribute("download")) return;
    const u = new URL(a.href, location.href);
    if (u.origin !== location.origin || /^\/wp-(admin|login|content|json)/.test(u.pathname)) return;
    if (u.pathname === location.pathname) {
      if (u.hash && u.hash.length > 1) return;
      e.preventDefault(); scrollTo({ top: 0, behavior: REDUCED ? "auto" : "smooth" }); return;
    }
    if (REDUCED) return;
    e.preventDefault();
    try { sessionStorage.setItem("bsvNav", "1"); } catch (_) {}
    c.classList.remove("leave"); c.classList.add("cover");
    setTimeout(() => { location.href = u.href; }, 950);
  });
  addEventListener("pageshow", e => { if (e.persisted) { c.classList.remove("cover", "leave"); root.classList.remove("cu-arrive"); } });
  document.querySelectorAll("[data-nav]").forEach(a => { if (a.dataset.nav === BSV.nav) a.setAttribute("aria-current", "page"); });
  if (BSV.route === "kontakt") {
    try {
      const s = sessionStorage.getItem("bsvAnliegen"); sessionStorage.removeItem("bsvAnliegen");
      if (s) { pendingAnliegen = JSON.parse(s); if (applyAnliegen()) setTimeout(() => $id("kontaktformular").scrollIntoView(), 60); }
    } catch (_) {}
  }
  applyReveal(document);
})();


$id("f-file").addEventListener("change", e => {
  const n = e.target.files.length;
  $id("f-file-txt").textContent = n ? (n === 1 ? "1 Foto ausgewählt" : n + " Fotos ausgewählt") : "Fotos auswählen";
});
(function () {
  const form = $id("kontaktformular"); if (!form) return;
  const ts = form.querySelector('[name="ts"]'); if (ts) ts.value = Math.floor(Date.now() / 1000);
  form.addEventListener("submit", async e => {
    e.preventDefault();
    const msg = $id("form-msg"), btn = form.querySelector('button[type="submit"]');
    msg.classList.remove("ok", "err");
    if (!form.reportValidity()) return;
    const old = btn.innerHTML; btn.disabled = true; btn.textContent = "Wird gesendet …";
    try {
      const r = await fetch(BSV.rest, { method: "POST", body: new FormData(form), credentials: "same-origin" });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(j.message || "");
      form.reset(); if (ts) ts.value = Math.floor(Date.now() / 1000);
      $id("f-file-txt").textContent = "Fotos auswählen";
      msg.textContent = "Vielen Dank, Ihre Anfrage ist angekommen. Ich melde mich kurzfristig bei Ihnen."; msg.classList.add("ok");
    } catch (err) {
      msg.textContent = (err.message ? err.message + " " : "Das hat leider nicht geklappt. ") + "Sie erreichen mich auch telefonisch unter 0179 6933684."; msg.classList.add("err");
    }
    btn.disabled = false; btn.innerHTML = old;
  });
})();

/* ---------- Hero: gezeichnete Abendlandschaft vom Münsterland bis ins Ruhrgebiet ----------
   Bis Andrés Video fertig ist. Danach ersetzt das Video die Szene. */
(function () {
  const svg = $id("scene"); if (!svg) return;
  const NS = "http://www.w3.org/2000/svg";
  let seed = 11; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  const stars = $id("stars");
  for (let i = 0; i < 70; i++) {
    const c = document.createElementNS(NS, "circle");
    c.setAttribute("cx", (rnd() * 1600).toFixed(1)); c.setAttribute("cy", (rnd() * 330).toFixed(1));
    c.setAttribute("r", (rnd() * 1.3 + .4).toFixed(2)); c.setAttribute("class", "star");
    c.style.animationDelay = (rnd() * 5).toFixed(2) + "s"; stars.appendChild(c);
  }
  let d = "", wins = "", x = -10, n = 0;
  while (x < 1610) {
    const w = 46 + Math.round(rnd() * 34), eave = 646 + Math.round(rnd() * 24), apex = eave - 34 - Math.round(rnd() * 22);
    d += `M${x} 720 V${eave} L${x + w / 2} ${apex} L${x + w} ${eave} V720 Z `;
    const cols = w > 64 ? 3 : 2, gap = w / (cols + 1);
    for (let r = 0; r < 2; r++) for (let k = 1; k <= cols; k++) {
      const lit = rnd() < .38;
      wins += `<rect x="${(x + gap * k - 4).toFixed(1)}" y="${eave + 12 + r * 24}" width="8" height="11" rx="1"${lit ? ` class="lit" style="--d:${(.6 + rnd() * 2.4).toFixed(2)}s"` : ""}/>`;
      n++;
    }
    if (rnd() < .5) { const wx = x + w / 2 - 4; wins += `<rect x="${wx}" y="${apex + 16}" width="8" height="10" rx="1"${rnd() < .4 ? ` class="lit" style="--d:${(1 + rnd() * 2).toFixed(2)}s"` : ""}/>`; }
    x += w + 2;
  }
  $id("front-row").setAttribute("d", d);
  $id("win").innerHTML = wins;
  /* leichte Tiefenwirkung mit der Maus */
  const hero = $id("hero"), lays = [[".lay-far", 6], [".lay-mid", 12], [".lay-front", 20]].map(([s, f]) => [svg.querySelector(s), f]);
  if (!matchMedia("(prefers-reduced-motion: reduce)").matches) hero.addEventListener("pointermove", e => {
    if (e.pointerType !== "mouse") return;
    const r = hero.getBoundingClientRect(), dx = (e.clientX - r.left) / r.width - .5;
    lays.forEach(([el, f]) => { if (el) el.style.transform = `translateX(${(-dx * f).toFixed(1)}px)`; });
  });
})();
