<?php defined('ABSPATH') || exit; $u = get_template_directory_uri() . '/assets/'; ?><!doctype html>
<html lang="de">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="robots" content="noindex, nofollow">
<meta name="theme-color" content="#0f1d2e">
<title>BSV Niewerth – Website im Aufbau</title>
<meta name="description" content="Die neue Website von BSV Niewerth – Bau-Sachverständigenbüro ist im Aufbau. Kontakt: 0179 6933684, info@bsv-niewerth.de">
<meta property="og:title" content="BSV Niewerth – Bau-Sachverständigenbüro">
<meta property="og:description" content="Die neue Website ist im Aufbau. Sie erreichen mich schon jetzt unter 0179 6933684.">
<meta property="og:image" content="<?php echo esc_url($u . 'og/start.jpg'); ?>"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630">
<link rel="icon" href="<?php echo esc_url($u . 'icons/favicon.ico'); ?>" sizes="48x48">
<link rel="icon" href="<?php echo esc_url($u . 'icons/favicon.svg'); ?>" type="image/svg+xml">
<link rel="apple-touch-icon" href="<?php echo esc_url($u . 'icons/apple-touch-icon.png'); ?>">
<link rel="stylesheet" href="<?php echo esc_url($u . 'site.css?ver=' . BSV_VERSION); ?>">
<style>
  html, body { background: var(--navy); }
  body { margin: 0; min-height: 100svh; display: grid; place-items: center; color: #fff; padding: max(28px, env(safe-area-inset-top)) 20px max(28px, env(safe-area-inset-bottom)); position: relative; overflow-x: hidden; }
  body::before { display: none; }
  .gate-roof { position: fixed; left: 50%; bottom: -12vh; width: min(1100px, 130vw); transform: translateX(-50%); opacity: .06; pointer-events: none; }
  .gate-roof path { fill: none; stroke: #fff; stroke-width: 14; }
  .gate { position: relative; width: 100%; max-width: 560px; display: grid; gap: 26px; justify-items: center; text-align: center; }
  .gate .brand { flex-direction: column; gap: 16px; pointer-events: none; }
  .gate .brand-mark { height: clamp(84px, 16vw, 120px); }
  .gate .brand-text { display: grid !important; border-left: 0; padding-left: 0; justify-items: center; }
  .gate .brand-name { font-size: clamp(1.15rem, 3vw, 1.5rem); }
  .gate .brand-sub { font-size: clamp(.62rem, 1.6vw, .78rem); }
  .gate-k { display: inline-flex; align-items: center; gap: 12px; font-family: var(--font-head); font-weight: 700; font-size: .78rem; letter-spacing: .2em; text-transform: uppercase; color: var(--blue-light); }
  .gate-k::before, .gate-k::after { content: ""; width: 28px; height: 2px; background: currentColor; }
  .gate h1 { font-size: clamp(1.6rem, 5vw, 2.3rem); line-height: 1.2; }
  .gate p { color: var(--on-navy-muted); font-size: 1.08rem; max-width: 30rem; }
  .gate-bar { width: min(260px, 70vw); height: 4px; border-radius: 2px; background: rgb(255 255 255 / .12); overflow: hidden; }
  .gate-bar i { display: block; width: 40%; height: 100%; background: var(--blue-light); border-radius: 2px; animation: gate-bar 2.4s cubic-bezier(.6,.1,.3,1) infinite; }
  @keyframes gate-bar { 0% { transform: translateX(-110%); } 100% { transform: translateX(260%); } }
  @media (prefers-reduced-motion: reduce) { .gate-bar i { animation: none; transform: translateX(75%); } }
  .gate-contact { display: flex; flex-wrap: wrap; justify-content: center; gap: 10px; }
  .gate-contact .btn { padding: .85em 1.3em; }
  .gate form { all: unset; width: 100%; max-width: 380px; display: grid; gap: 10px; margin-top: 8px; padding-top: 26px; border-top: 1px solid rgb(255 255 255 / .14); }
  .gate label { font-family: var(--font-head); font-weight: 600; font-size: .85rem; color: var(--on-navy-muted); }
  .gate .row { display: grid; grid-template-columns: minmax(0, 1fr) auto; gap: 8px; }
  .gate input { background: rgb(255 255 255 / .08); color: #fff; border: 1px solid rgb(255 255 255 / .2); border-radius: var(--r); padding: 12px 14px; font-size: 1rem; }
  .gate input:focus { outline: 2px solid var(--blue-light); outline-offset: 1px; background: rgb(255 255 255 / .12); }
  .gate .err { color: #ffb4a6; font-size: .92rem; font-weight: 600; }
  .gate small { color: #8fa2b8; font-size: .82rem; }
</style>
</head>
<body>
<svg class="gate-roof" viewBox="0 0 600 300" aria-hidden="true"><path d="M20 290 L300 40 L580 290"/></svg>
<main class="gate">
  <div><span class="brand" href="/" aria-label="BSV Niewerth, zur Startseite">
      <svg class="brand-mark" viewBox="-248.6 -299.78 615.81 305.78" aria-hidden="true"><mask id="hdr2378" maskUnits="userSpaceOnUse" x="-2000" y="-2000" width="4000" height="4000"><rect x="-2000" y="-2000" width="4000" height="4000" fill="#fff"></rect><circle cx="268.6" cy="-145.46" r="57" fill="#000"></circle></mask>
<g mask="url(#hdr2378)"><path d="M-242.6 -175.46 L0 -293.78 L0 -263.74 L-242.6 -145.42 Z" style="fill:var(--logo-accent)"></path><path d="M0 -293.78 L242.6 -175.46 L242.6 -145.42 L0 -263.74 Z" style="fill:var(--logo-accent-2)"></path></g>
<path d="M-208.60000000000002 0.0V-140.0H-137.0Q-109.40000000000002 -140.0 -95.80000000000001 -129.9Q-82.20000000000002 -119.80000000000001 -82.20000000000002 -103.4Q-82.20000000000002 -92.60000000000001 -87.90000000000002 -84.5Q-93.60000000000002 -76.4 -103.90000000000002 -71.7Q-114.20000000000002 -67.0 -128.40000000000003 -67.0L-124.40000000000002 -76.60000000000001Q-109.60000000000002 -76.60000000000001 -98.60000000000002 -72.10000000000001Q-87.60000000000002 -67.60000000000001 -81.50000000000001 -59.10000000000001Q-75.4 -50.6 -75.4 -38.400000000000006Q-75.4 -20.200000000000003 -90.10000000000001 -10.100000000000001Q-104.80000000000001 0.0 -133.0 0.0ZM-169.40000000000003 -28.6H-136.20000000000002Q-126.00000000000001 -28.6 -120.70000000000002 -32.1Q-115.40000000000002 -35.6 -115.40000000000002 -42.800000000000004Q-115.40000000000002 -50.0 -120.70000000000002 -53.5Q-126.00000000000001 -57.0 -136.20000000000002 -57.0H-172.20000000000002V-84.4H-142.20000000000002Q-132.20000000000002 -84.4 -127.20000000000002 -87.80000000000001Q-122.20000000000002 -91.2 -122.20000000000002 -98.0Q-122.20000000000002 -104.80000000000001 -127.20000000000002 -108.10000000000001Q-132.20000000000002 -111.4 -142.20000000000002 -111.4H-169.40000000000003ZM-9.600000000000009 2.8000000000000003Q-26.80000000000001 2.8000000000000003 -42.70000000000001 -1.5000000000000002Q-58.60000000000001 -5.800000000000001 -68.60000000000001 -12.600000000000001L-55.60000000000001 -41.800000000000004Q-46.20000000000001 -35.800000000000004 -33.900000000000006 -31.900000000000002Q-21.60000000000001 -28.0 -9.400000000000006 -28.0Q-1.2000000000000028 -28.0 3.799999999999997 -29.5Q8.799999999999997 -31.0 11.099999999999994 -33.5Q13.399999999999991 -36.0 13.399999999999991 -39.400000000000006Q13.399999999999991 -44.2 8.999999999999993 -47.0Q4.599999999999994 -49.800000000000004 -2.4000000000000057 -51.60000000000001Q-9.400000000000006 -53.400000000000006 -17.900000000000006 -55.2Q-26.400000000000006 -57.0 -34.900000000000006 -59.8Q-43.400000000000006 -62.6 -50.400000000000006 -67.10000000000001Q-57.40000000000001 -71.60000000000001 -61.80000000000001 -78.9Q-66.20000000000002 -86.2 -66.20000000000002 -97.4Q-66.20000000000002 -110.0 -59.30000000000001 -120.2Q-52.400000000000006 -130.4 -38.60000000000001 -136.60000000000002Q-24.80000000000001 -142.8 -4.200000000000003 -142.8Q9.599999999999994 -142.8 22.89999999999999 -139.7Q36.19999999999999 -136.6 46.599999999999994 -130.6L34.39999999999999 -101.2Q24.39999999999999 -106.60000000000001 14.599999999999994 -109.30000000000001Q4.799999999999997 -112.0 -4.400000000000006 -112.0Q-12.600000000000009 -112.0 -17.60000000000001 -110.30000000000001Q-22.60000000000001 -108.60000000000001 -24.800000000000008 -105.80000000000001Q-27.000000000000007 -103.0 -27.000000000000007 -99.4Q-27.000000000000007 -94.80000000000001 -22.700000000000006 -92.10000000000001Q-18.400000000000006 -89.4 -11.300000000000004 -87.7Q-4.200000000000003 -86.0 4.299999999999997 -84.2Q12.799999999999997 -82.4 21.299999999999997 -79.7Q29.799999999999997 -77.0 36.8 -72.5Q43.8 -68.0 48.099999999999994 -60.7Q52.39999999999999 -53.400000000000006 52.39999999999999 -42.400000000000006Q52.39999999999999 -30.200000000000003 45.49999999999999 -19.900000000000002Q38.599999999999994 -9.600000000000001 24.89999999999999 -3.4000000000000004Q11.199999999999989 2.8000000000000003 -9.600000000000009 2.8000000000000003ZM109.60000000000002 0.0 49.800000000000026 -140.0H92.60000000000002L143.00000000000003 -18.8H117.80000000000003L169.40000000000003 -140.0H208.60000000000002L148.60000000000002 0.0Z" style="fill:var(--logo-ink)"></path>
<circle cx="268.6" cy="-145.46" r="40.5" fill="none" style="stroke:var(--logo-ink)" stroke-width="15"></circle>
<path d="M251.6 -144.46 L263.6 -132.46 L286.6 -157.46" fill="none" style="stroke:var(--logo-accent)" stroke-width="10" stroke-linecap="round" stroke-linejoin="round"></path>
<path d="M301.13 -112.93 L309.61 -104.45" style="stroke:var(--logo-ink)" stroke-width="13"></path>
<path d="M309.61 -104.45 L340.72 -73.33" style="stroke:var(--logo-ink)" stroke-width="24" stroke-linecap="round"></path></svg>
      <span class="brand-text"><span class="brand-name">NIEWERTH</span><span class="brand-sub">Bau-Sach­verständigen­büro</span></span>
    </span></div>
  <span class="gate-k">Im Aufbau</span>
  <h1>Hier entsteht die neue Website</h1>
  <div class="gate-bar" aria-hidden="true"><i></i></div>
  <p>Die Website von BSV Niewerth – Bau-Sachverständigenbüro wird gerade fertiggestellt. Sie erreichen mich schon jetzt persönlich.</p>
  <div class="gate-contact">
    <a class="btn btn--primary" href="tel:+491796933684">0179 6933684</a>
    <a class="btn btn--outline-light" href="mailto:info@bsv-niewerth.de">info@bsv-niewerth.de</a>
  </div>
  <form method="post" action="">
    <label for="bsv-pw">Zugang zur Vorschau</label>
    <div class="row"><input id="bsv-pw" name="bsv_zugang_pw" type="password" autocomplete="current-password" required placeholder="Passwort"><button class="btn btn--light" type="submit">Öffnen</button></div>
    <?php if (!empty($fehler)) : ?><span class="err" role="alert"><?php echo esc_html($fehler); ?></span><?php endif; ?>
  </form>
  <small>André Niewerth · Propst-Pricking-Str. 16 · 46325 Borken</small>
</main>
</body>
</html>
